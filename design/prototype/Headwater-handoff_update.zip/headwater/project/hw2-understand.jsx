// Headwater 2 — Generate + Understand.
//
// Understand now does TWO jobs:
//   1. Narrate "what this data is" (ER + workflow + relevant slice).
//   2. PROPOSE QUESTIONS the data can credibly answer (and the ones it can't,
//      with the reason). The user curates: keep / edit / add / drop.

// ─── Generate ───────────────────────────────────────────────────────────────
function HW2Generate({ project, source, onDone }) {
  const steps = [
    { key: "ingest",   label: "Ingested",          detail: source.schemas.map(s => s.name).join(" · ") + " — profiles reused" },
    { key: "profile",  label: "Profiled",          detail: "columns · stats · keys · referential integrity" },
    { key: "type",     label: "Typed columns",     detail: "timestamps · durations · codes · identifiers" },
    { key: "relate",   label: "Found structure",   detail: "case → exams → events (event log)" },
    { key: "scope",    label: "Scoping to goal",   detail: "evaluating column relevance to goal" },
    { key: "propose",  label: "Proposing questions", detail: "checking what this data can credibly answer" },
  ];
  const [i, setI] = React.useState(0);
  React.useEffect(() => {
    if (i >= steps.length) { const t = setTimeout(onDone, 500); return () => clearTimeout(t); }
    const t = setTimeout(() => setI(i + 1), 600);
    return () => clearTimeout(t);
  }, [i]); // eslint-disable-line

  return (
    <div style={{ maxWidth: 720, margin: "0 auto", padding: "60px 32px" }}>
      <span style={{
        font: "600 11px 'DM Sans'", color: HW2_COLOR.blue,
        letterSpacing: "0.08em", textTransform: "uppercase",
      }}>Generating understanding</span>
      <h2 style={{
        font: "600 26px 'DM Sans'", letterSpacing: "-0.02em",
        color: HW2_COLOR.ink, lineHeight: 1.25, marginTop: 8, marginBottom: 6,
      }}>Reading the scope.</h2>
      <p style={{ font: "400 14px 'DM Sans'", color: HW2_COLOR.muted, marginBottom: 28 }}>
        This runs on its own — no input needed. We&rsquo;ll show you what the data is,
        then propose the questions it can credibly answer.
      </p>

      <HW2Card>
        {steps.map((s, idx) => {
          const done = idx < i, active = idx === i, wait = idx > i;
          return (
            <div key={s.key} style={{
              display: "flex", alignItems: "center", gap: 14, padding: "10px 0",
              borderBottom: idx < steps.length - 1 ? `1px solid ${HW2_COLOR.rule}` : "none",
            }}>
              <span style={{
                width: 22, height: 22, borderRadius: "50%",
                display: "inline-flex", alignItems: "center", justifyContent: "center",
                background: done ? HW2_COLOR.good : "#fff",
                border: active ? `2px solid ${HW2_COLOR.blue}` : done ? "none" : `1.5px solid ${HW2_COLOR.rule2}`,
                color: "#fff",
              }}>
                {done && <span style={{ font: "700 12px 'DM Sans'" }}>✓</span>}
                {active && <span style={{ width: 8, height: 8, borderRadius: "50%", background: HW2_COLOR.blue, animation: "hw2-pulse 1s ease-in-out infinite" }} />}
              </span>
              <div style={{ flex: 1, opacity: wait ? 0.45 : 1 }}>
                <div style={{ font: "600 14px 'DM Sans'", color: HW2_COLOR.ink }}>{s.label}</div>
                <div style={{ font: "400 12px 'DM Mono'", color: HW2_COLOR.muted, marginTop: 2 }}>{s.detail}</div>
              </div>
              {active && <span style={{ font: "500 11px 'DM Sans'", color: HW2_COLOR.blue }}>working…</span>}
            </div>
          );
        })}
      </HW2Card>

      <style>{`@keyframes hw2-pulse { 0%,100%{transform:scale(1)} 50%{transform:scale(1.4); opacity:0.4} }`}</style>
    </div>
  );
}

// ─── Understand ─────────────────────────────────────────────────────────────
function HW2Understand({ project, data, onConfirm, onProposedAcceptAll, onProposedCurate }) {
  // Local curated set of questions (id -> {keep, title})
  const [curated, setCurated] = React.useState(() =>
    Object.fromEntries(data.proposedQuestions.map(q => [q.id, { keep: q.answerable !== false, title: q.title }]))
  );
  const [draftQ, setDraftQ] = React.useState("");

  // Specific-correction inline editor for "Something's off"
  const [correctOpen, setCorrectOpen] = React.useState(false);
  const [correctChoice, setCorrectChoice] = React.useState(null);

  const keptCount = Object.values(curated).filter(c => c.keep).length;

  return (
    <div style={{ maxWidth: 980, margin: "0 auto", padding: "32px 32px 80px" }}>
      <span style={{
        font: "600 11px 'DM Sans'", color: HW2_COLOR.blue,
        letterSpacing: "0.08em", textTransform: "uppercase",
      }}>Step 2 of 5 · Understand</span>
      <h2 style={{
        font: "600 26px 'DM Sans'", letterSpacing: "-0.02em",
        color: HW2_COLOR.ink, lineHeight: 1.25, marginTop: 8, marginBottom: 4,
      }}>Here&rsquo;s what this data is.</h2>
      <p style={{ font: "400 14px 'DM Sans'", color: HW2_COLOR.muted, marginBottom: 24 }}>
        Skim the shape; then curate the questions Headwater is proposing.
      </p>

      {/* ER */}
      <HW2Card style={{ padding: "22px 28px", marginBottom: 16 }}>
        <SectionLabel>The shape of it</SectionLabel>
        <ErDiagram tables={data.sources[0].schemas[0].tables.filter(t => ["cases", "exams", "events"].includes(t.name))} />
      </HW2Card>

      {/* Workflow */}
      <HW2Card style={{ padding: "22px 28px", marginBottom: 16 }}>
        <div style={{ display: "flex", alignItems: "baseline", justifyContent: "space-between", marginBottom: 14 }}>
          <SectionLabel>Reconstructed workflow</SectionLabel>
          <span style={{ font: "400 11px 'DM Sans'", color: HW2_COLOR.faint }}>
            inferred from events.activity sequences
          </span>
        </div>
        <WorkflowLane steps={data.workflow} />
        <div style={{ marginTop: 14, font: "400 13px 'DM Sans'", color: HW2_COLOR.ink2, lineHeight: 1.55 }}>
          The shaded band is the <strong>registration zone</strong> — the steps that look like they
          define your wait window. The exact boundary becomes a Resolve item.
        </div>
      </HW2Card>

      {/* Relevant columns */}
      <HW2Card style={{ marginBottom: 22 }}>
        <RelevantCols data={data} />
      </HW2Card>

      {/* Proposed questions — the heart of inverted Frame */}
      <HW2Card padded={false} style={{ marginBottom: 22 }}>
        <div style={{
          padding: "16px 22px", borderBottom: `1px solid ${HW2_COLOR.rule}`,
          display: "flex", alignItems: "center", justifyContent: "space-between", gap: 12,
        }}>
          <div>
            <div style={{ font: "600 11px 'DM Sans'", color: HW2_COLOR.blue, letterSpacing: "0.07em", textTransform: "uppercase" }}>
              Proposed questions
            </div>
            <div style={{ font: "500 16px 'DM Sans'", color: HW2_COLOR.ink, marginTop: 4 }}>
              {keptCount} of {data.proposedQuestions.length} kept — curate or add your own.
            </div>
          </div>
          <HW2Btn size="sm" onClick={onProposedAcceptAll}>Accept all answerable</HW2Btn>
        </div>
        <div style={{ padding: "12px 22px 18px", display: "grid", gap: 8 }}>
          {data.proposedQuestions.map(q => (
            <ProposedQ key={q.id} q={q}
              kept={curated[q.id]?.keep}
              title={curated[q.id]?.title || q.title}
              onToggle={() => setCurated(p => ({ ...p, [q.id]: { ...p[q.id], keep: !p[q.id].keep } }))}
              onRename={(t) => setCurated(p => ({ ...p, [q.id]: { ...p[q.id], title: t } }))}
            />
          ))}
          {/* Add your own */}
          <div style={{
            display: "flex", alignItems: "center", gap: 10,
            padding: "10px 14px", borderRadius: 8,
            background: HW2_COLOR.chip, border: `1px dashed ${HW2_COLOR.rule2}`, marginTop: 4,
          }}>
            <span style={{ font: "500 11px 'DM Mono'", color: HW2_COLOR.faint, width: 20 }}>+</span>
            <input
              value={draftQ} onChange={(e) => setDraftQ(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter" && draftQ.trim()) {
                  const id = "qx_" + Date.now();
                  setCurated(p => ({ ...p, [id]: { keep: true, title: draftQ.trim() } }));
                  setDraftQ("");
                }
              }}
              placeholder="Add your own question — Headwater will evaluate it"
              style={{
                flex: 1, appearance: "none", background: "transparent", border: "none",
                padding: 0, font: "500 13px 'DM Sans'", color: HW2_COLOR.ink, outline: "none",
                fontFamily: "'DM Sans', sans-serif",
              }}
            />
          </div>
        </div>
      </HW2Card>

      {/* Confirm + granular escape hatch */}
      <div style={{
        display: "flex", alignItems: "center", justifyContent: "space-between",
        padding: "16px 20px", background: HW2_COLOR.surface,
        border: `1px solid ${HW2_COLOR.rule2}`, borderRadius: 12, gap: 14,
      }}>
        <div>
          <div style={{ font: "600 14px 'DM Sans'", color: HW2_COLOR.ink }}>Looks right?</div>
          <div style={{ font: "400 12px 'DM Sans'", color: HW2_COLOR.muted, marginTop: 2 }}>
            {correctOpen
              ? "Pick the specific item that&rsquo;s wrong — we&rsquo;ll drop you on it, not reset the flow."
              : "Confirm the broad picture; specifics are resolved one at a time in the next step."}
          </div>
        </div>
        <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
          <button onClick={() => setCorrectOpen(v => !v)} style={understandAnchorStyle}>
            {correctOpen ? "Cancel" : "Something’s off"}
          </button>
          <HW2Btn kind="accent" onClick={() => onProposedCurate(curated) || onConfirm()}>
            Yes, continue →
          </HW2Btn>
        </div>
      </div>

      {/* Granular "something's off" picker */}
      {correctOpen && (
        <div style={{
          marginTop: 12, padding: "14px 18px",
          background: HW2_COLOR.surface, border: `1px solid ${HW2_COLOR.rule2}`,
          borderRadius: 10,
        }}>
          <div style={{ font: "500 12px 'DM Sans'", color: HW2_COLOR.muted, marginBottom: 8 }}>
            Which thing is wrong?
          </div>
          <div style={{ display: "grid", gap: 4 }}>
            {[
              { id: "rel",  label: "A relationship between tables is wrong" },
              { id: "zone", label: "The workflow zone (registration) is wrong" },
              { id: "rel-col", label: "A column should/shouldn't be in the relevant slice" },
              { id: "q",    label: "A proposed question is misclassified (answerable vs not)" },
              { id: "scope", label: "The selected tables (scope) should change" },
            ].map(opt => (
              <button key={opt.id} onClick={() => { setCorrectChoice(opt.id); }} style={{
                appearance: "none", cursor: "pointer", textAlign: "left",
                background: correctChoice === opt.id ? HW2_COLOR.blueSoft : "transparent",
                border: `1px solid ${correctChoice === opt.id ? HW2_COLOR.blue : "transparent"}`,
                borderRadius: 7, padding: "8px 12px",
                font: "500 13px 'DM Sans'", color: correctChoice === opt.id ? HW2_COLOR.blue : HW2_COLOR.ink2,
                fontFamily: "'DM Sans', sans-serif",
              }}>{opt.label}</button>
            ))}
          </div>
          {correctChoice && (
            <div style={{
              marginTop: 12, padding: "10px 14px",
              background: HW2_COLOR.chip, borderRadius: 8,
              font: "400 12px 'DM Sans'", color: HW2_COLOR.ink2, lineHeight: 1.5,
              display: "flex", alignItems: "center", justifyContent: "space-between", gap: 8,
            }}>
              <span>
                In production, this opens an in-place editor for that specific item. The flow never resets.
              </span>
              <HW2Btn size="sm" kind="accent" onClick={() => { setCorrectOpen(false); setCorrectChoice(null); }}>
                Got it
              </HW2Btn>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

function SectionLabel({ children }) {
  return (
    <div style={{ font: "600 11px 'DM Sans'", color: HW2_COLOR.muted, textTransform: "uppercase", letterSpacing: "0.06em", marginBottom: 14 }}>
      {children}
    </div>
  );
}

// ─── Proposed Q row ─────────────────────────────────────────────────────────
function ProposedQ({ q, kept, title, onToggle, onRename }) {
  const tone = q.answerable === true ? { bg: HW2_COLOR.goodSoft, c: HW2_COLOR.good, icon: "✓", verdict: "Answerable" }
             : q.answerable === false ? { bg: HW2_COLOR.warnSoft, c: HW2_COLOR.warn, icon: "✗", verdict: "Can’t answer" }
             : { bg: HW2_COLOR.blueSoft, c: HW2_COLOR.blue, icon: "⚠", verdict: "Answerable, with caveat" };
  const dim = !kept;

  return (
    <div style={{
      display: "flex", alignItems: "flex-start", gap: 12,
      padding: "12px 14px", borderRadius: 10,
      background: kept ? HW2_COLOR.surface : HW2_COLOR.paper,
      border: `1px solid ${kept ? HW2_COLOR.rule2 : HW2_COLOR.rule}`,
      opacity: dim ? 0.65 : 1,
    }}>
      <input type="checkbox" checked={!!kept} onChange={onToggle}
        style={{ accentColor: HW2_COLOR.blue, marginTop: 4, cursor: "pointer" }} />
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 4, flexWrap: "wrap" }}>
          <span style={{
            display: "inline-flex", alignItems: "center", gap: 5,
            padding: "2px 8px", borderRadius: 4,
            background: tone.bg, color: tone.c,
            font: "700 10px 'DM Sans'", letterSpacing: "0.07em", textTransform: "uppercase",
          }}>
            <span style={{ font: "700 10px 'DM Sans'" }}>{tone.icon}</span>{tone.verdict}
          </span>
        </div>
        <input
          value={title} onChange={(e) => onRename(e.target.value)}
          style={{
            width: "100%", appearance: "none", background: "transparent", border: "none",
            padding: 0, font: "500 14px 'DM Sans'", color: HW2_COLOR.ink, outline: "none",
            fontFamily: "'DM Sans', sans-serif",
          }}
        />
        <div style={{ font: "400 12px 'DM Sans'", color: HW2_COLOR.muted, marginTop: 5, lineHeight: 1.5 }}>
          {tone.icon === "✗" ? <strong style={{ color: HW2_COLOR.warn }}>Why not: </strong> : <strong style={{ color: HW2_COLOR.ink2 }}>Why: </strong>}
          {q.reason}
        </div>
        {q.neededColumns && q.neededColumns.length > 0 && (
          <div style={{ display: "flex", flexWrap: "wrap", gap: 4, marginTop: 6 }}>
            {q.neededColumns.map((c, i) => (
              <span key={i} style={{
                font: "500 11px 'DM Mono'", color: HW2_COLOR.faint,
                padding: "1px 6px", background: HW2_COLOR.chip, borderRadius: 4,
              }}>{c}</span>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

// ─── Relevant columns subcomponent ──────────────────────────────────────────
function RelevantCols({ data }) {
  const [showIrr, setShowIrr] = React.useState(false);
  return (
    <>
      <div style={{ display: "flex", alignItems: "baseline", justifyContent: "space-between", marginBottom: 12 }}>
        <SectionLabel>Relevant to your goal</SectionLabel>
        <span style={{ font: "400 11px 'DM Sans'", color: HW2_COLOR.faint }}>
          {data.relevant.length} columns
        </span>
      </div>
      <div style={{ display: "flex", flexWrap: "wrap", gap: 8 }}>
        {data.relevant.map(c => (
          <span key={c.table + c.col} title={c.reason} style={{
            display: "inline-flex", alignItems: "center", gap: 6,
            padding: "5px 9px", borderRadius: 6,
            background: HW2_COLOR.blueSoft, color: HW2_COLOR.blue,
            font: "500 12px 'DM Mono'",
          }}>
            <span style={{ color: HW2_COLOR.muted }}>{c.table}.</span>{c.col}
          </span>
        ))}
      </div>
      <button onClick={() => setShowIrr(v => !v)} style={{
        appearance: "none", background: "none", border: "none", cursor: "pointer",
        padding: 0, marginTop: 12, color: HW2_COLOR.muted,
        font: "500 13px 'DM Sans'", display: "inline-flex", alignItems: "center", gap: 6,
      }}>
        <span style={{ font: "500 11px 'DM Mono'", color: HW2_COLOR.faint }}>{showIrr ? "▼" : "▶"}</span>
        {data.irrelevant.length} columns judged not relevant to this goal
      </button>
      {showIrr && (
        <div style={{ display: "flex", flexWrap: "wrap", gap: 6, marginTop: 10 }}>
          {data.irrelevant.map(c => (
            <span key={c.table + c.col} title={c.reason} style={{
              padding: "4px 8px", borderRadius: 6,
              background: HW2_COLOR.chip, color: HW2_COLOR.muted,
              font: "500 12px 'DM Mono'", textDecoration: "line-through", textDecorationColor: HW2_COLOR.faint,
            }}>
              <span style={{ color: HW2_COLOR.faint }}>{c.table}.</span>{c.col}
            </span>
          ))}
        </div>
      )}
    </>
  );
}

// ─── ER + workflow (inherited from prior build, lightly tightened) ──────────
function ErDiagram({ tables }) {
  return (
    <div style={{ display: "flex", alignItems: "center", justifyContent: "center", gap: 14, paddingTop: 6, flexWrap: "wrap" }}>
      {tables.map((t, i) => (
        <React.Fragment key={t.name}>
          <div style={{ minWidth: 170, padding: "12px 14px", background: "#fff", border: `1px solid ${HW2_COLOR.rule2}`, borderRadius: 10 }}>
            <div style={{ font: "600 13px 'DM Mono'", color: HW2_COLOR.ink }}>{t.name}</div>
            <div style={{ font: "400 11px 'DM Sans'", color: HW2_COLOR.muted, marginTop: 2 }}>
              {t.rows.toLocaleString()} rows · {t.cols} cols
            </div>
            <div style={{ font: "400 11px 'DM Mono'", color: HW2_COLOR.faint, marginTop: 6 }}>
              {t.pk && <>pk: {t.pk}<br /></>}
              {t.fk && <>fk: {t.fk}</>}
            </div>
          </div>
          {i < tables.length - 1 && (
            <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 2 }}>
              <span style={{ font: "500 11px 'DM Mono'", color: HW2_COLOR.faint }}>1 — many</span>
              <span style={{ width: 28, height: 1, background: HW2_COLOR.rule2 }} />
            </div>
          )}
        </React.Fragment>
      ))}
    </div>
  );
}

function WorkflowLane({ steps }) {
  const firstReg = steps.findIndex(s => s.zone === "registration");
  const lastReg  = steps.length - 1 - [...steps].reverse().findIndex(s => s.zone === "registration");
  return (
    <div style={{ position: "relative", padding: "12px 0 28px" }}>
      {firstReg !== -1 && (
        <div style={{
          position: "absolute", top: 4, bottom: 22,
          left: `calc(${(firstReg / steps.length) * 100}% + 4px)`,
          width: `calc(${((lastReg - firstReg + 1) / steps.length) * 100}% - 8px)`,
          background: HW2_COLOR.blueSoft, borderRadius: 8,
          border: `1px dashed ${HW2_COLOR.blue}`, zIndex: 0,
        }} />
      )}
      <div style={{ position: "relative", display: "grid", gridTemplateColumns: `repeat(${steps.length}, 1fr)`, zIndex: 1 }}>
        {steps.map((s, i) => (
          <div key={s.step} style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 6 }}>
            <span style={{
              padding: "5px 9px", borderRadius: 14, background: "#fff",
              border: `1px solid ${s.zone === "registration" ? HW2_COLOR.blue : HW2_COLOR.rule2}`,
              font: "500 12px 'DM Mono'",
              color: s.zone === "registration" ? HW2_COLOR.blue : HW2_COLOR.ink2,
              whiteSpace: "nowrap",
            }}>{s.step}</span>
          </div>
        ))}
      </div>
      {firstReg !== -1 && (
        <div style={{
          position: "absolute", bottom: -2,
          left: `${(firstReg / steps.length) * 100}%`,
          width: `${((lastReg - firstReg + 1) / steps.length) * 100}%`,
          textAlign: "center",
          font: "500 10px 'DM Sans'", color: HW2_COLOR.blue,
          letterSpacing: "0.08em", textTransform: "uppercase",
        }}>registration zone</div>
      )}
    </div>
  );
}

const understandAnchorStyle = {
  appearance: "none", background: "transparent", border: "none", cursor: "pointer",
  padding: "8px 12px", color: HW2_COLOR.muted, font: "500 13px 'DM Sans'",
  fontFamily: "'DM Sans', sans-serif",
};

Object.assign(window, { HW2Generate, HW2Understand });
