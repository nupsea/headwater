// Headwater 2 — shared primitives.
//
// Aesthetic: warm paper canvas, deep ink, one calm blue accent, hairline
// dividers, DM Sans + DM Mono.
//
// Key change vs the first build: there is NO single "trust" number.
// • HW2ReadinessRing is a per-thing readout of "% of blocking evidence cleared."
//   When mounted on a project it shows the project-level READOUT computed from
//   per-question contracts. When mounted on a question it shows that question's.
// • Certification is derived from contracts, NEVER from a points threshold.

const HW2_COLOR = {
  paper:    "#faf9f6",
  surface:  "#ffffff",
  ink:      "#15161a",
  ink2:     "#3a3c43",
  muted:    "#74757b",
  faint:    "#9c9da3",
  rule:     "#ebe9e3",
  rule2:    "#dfdcd2",
  chip:     "#f1efe8",
  blue:     "#2b5fd9",
  blueSoft: "#e7eefc",
  good:     "#0e7a55",
  goodSoft: "#e1efe7",
  warn:     "#a26108",
  warnSoft: "#f5ecd9",
  bad:      "#b4351c",
  badSoft:  "#f7e3dc",
};

// ─── Readiness Ring ──────────────────────────────────────────────────────────
// A *readout* of evidence cleared. Never the cause of certification.
function HW2ReadinessRing({ value, certified = false, demoted = false, size = 56, stroke = 4, showLabel = true, animate = true }) {
  const r = (size - stroke) / 2;
  const c = Math.PI * 2 * r;
  const v = Math.max(0, Math.min(100, value || 0));
  const tone = ringTone({ value: v, certified, demoted });
  const [drawn, setDrawn] = React.useState(animate ? 0 : v);
  React.useEffect(() => {
    if (!animate) { setDrawn(v); return; }
    let raf, t0;
    const from = drawn;
    const dur = 600;
    const step = (t) => {
      if (!t0) t0 = t;
      const p = Math.min(1, (t - t0) / dur);
      const eased = 1 - Math.pow(1 - p, 3);
      setDrawn(from + (v - from) * eased);
      if (p < 1) raf = requestAnimationFrame(step);
    };
    raf = requestAnimationFrame(step);
    return () => cancelAnimationFrame(raf);
  }, [v]); // eslint-disable-line
  const fillNow = c * (drawn / 100);
  return (
    <div style={{ display: "inline-flex", alignItems: "center", gap: 10 }}>
      <svg width={size} height={size} style={{ display: "block" }}>
        <circle cx={size/2} cy={size/2} r={r} stroke={HW2_COLOR.rule2} strokeWidth={stroke} fill="none" />
        <circle cx={size/2} cy={size/2} r={r}
          stroke={tone.color} strokeWidth={stroke} fill="none"
          strokeLinecap="round"
          strokeDasharray={`${fillNow} ${c}`}
          transform={`rotate(-90 ${size/2} ${size/2})`} />
        {certified && (
          // The "sacred" badge — only when certified is TRUE (from contracts)
          <text x="50%" y="52%" textAnchor="middle" dominantBaseline="central"
            style={{ font: `700 ${size * 0.32}px 'DM Sans'`, fill: tone.color }}>✓</text>
        )}
        {!certified && demoted && (
          <text x="50%" y="52%" textAnchor="middle" dominantBaseline="central"
            style={{ font: `700 ${size * 0.28}px 'DM Sans'`, fill: tone.color }}>!</text>
        )}
        {!certified && !demoted && (
          <text x="50%" y="52%" textAnchor="middle" dominantBaseline="central"
            style={{ font: `600 ${size * 0.24}px 'DM Sans'`, fill: HW2_COLOR.ink, letterSpacing: "-0.02em" }}>
            {Math.round(drawn)}
          </text>
        )}
      </svg>
      {showLabel && (
        <div style={{ display: "flex", flexDirection: "column", lineHeight: 1.15 }}>
          <span style={{ font: "600 11px 'DM Sans'", color: HW2_COLOR.muted, letterSpacing: "0.04em", textTransform: "uppercase" }}>Readiness</span>
          <span style={{ font: "600 14px 'DM Sans'", color: tone.color, letterSpacing: "-0.01em" }}>{tone.label}</span>
        </div>
      )}
    </div>
  );
}

function ringTone({ value, certified, demoted }) {
  if (certified) return { color: HW2_COLOR.good, label: "Certified" };
  if (demoted)   return { color: HW2_COLOR.bad,  label: "Re-verify" };
  if (value >= 80) return { color: HW2_COLOR.good, label: "Evidence high" };
  if (value >= 50) return { color: HW2_COLOR.blue, label: "Evidence forming" };
  if (value >= 20) return { color: HW2_COLOR.warn, label: "Evidence low" };
  if (value > 0)   return { color: HW2_COLOR.warn, label: "Starting" };
  return { color: HW2_COLOR.faint, label: "Not started" };
}

// ─── Stage stepper ───────────────────────────────────────────────────────────
const HW2_STAGES = [
  { key: "frame",      label: "Frame" },
  { key: "understand", label: "Understand" },
  { key: "resolve",    label: "Resolve" },
  { key: "readiness",  label: "Readiness" },
  { key: "answer",     label: "Answer" },
];

function HW2Stepper({ current, onJump, badges }) {
  const idx = HW2_STAGES.findIndex((s) => s.key === current);
  return (
    <div style={{ display: "flex", alignItems: "center", gap: 0, flexWrap: "wrap" }}>
      {HW2_STAGES.map((s, i) => {
        const active   = i === idx;
        const complete = i < idx;
        const badge    = badges?.[s.key];
        return (
          <React.Fragment key={s.key}>
            <button onClick={() => onJump?.(s.key)} style={{
              appearance: "none", background: "none", border: "none",
              cursor: "pointer", padding: "8px 12px", borderRadius: 8,
              display: "inline-flex", alignItems: "center", gap: 8,
              font: `${active ? 600 : 500} 13px 'DM Sans'`,
              color: active ? HW2_COLOR.ink : complete ? HW2_COLOR.ink2 : HW2_COLOR.faint,
              fontFamily: "'DM Sans', sans-serif",
            }}>
              <span style={{
                display: "inline-flex", alignItems: "center", justifyContent: "center",
                width: 20, height: 20, borderRadius: "50%",
                background: complete ? HW2_COLOR.good : active ? HW2_COLOR.ink : "transparent",
                border: complete ? "none" : active ? "none" : `1.5px solid ${HW2_COLOR.rule2}`,
                color: complete || active ? "#fff" : HW2_COLOR.faint,
                font: "600 10px 'DM Mono'",
              }}>
                {complete ? "✓" : i + 1}
              </span>
              <span>{s.label}</span>
              {badge && (
                <span style={{
                  font: "600 10px 'DM Mono'",
                  background: badge.tone === "bad" ? HW2_COLOR.badSoft : HW2_COLOR.blueSoft,
                  color: badge.tone === "bad" ? HW2_COLOR.bad : HW2_COLOR.blue,
                  padding: "2px 6px", borderRadius: 4,
                }}>{badge.label}</span>
              )}
            </button>
            {i < HW2_STAGES.length - 1 && (
              <span style={{ color: HW2_COLOR.rule2, font: "300 14px 'DM Sans'", padding: "0 2px" }}>›</span>
            )}
          </React.Fragment>
        );
      })}
    </div>
  );
}

// ─── Buttons / Chips / Cards / Primitive bits ────────────────────────────────
function HW2Btn({ kind = "default", size = "md", children, onClick, disabled, style, ...rest }) {
  const sizes = {
    sm: { padding: "5px 10px", font: "500 12px 'DM Sans'", radius: 6 },
    md: { padding: "8px 14px", font: "500 13px 'DM Sans'", radius: 8 },
    lg: { padding: "11px 20px", font: "600 14px 'DM Sans'", radius: 10 },
  }[size];
  const kinds = {
    default: { bg: "#fff", color: HW2_COLOR.ink, border: `1px solid ${HW2_COLOR.rule2}`, hover: HW2_COLOR.chip },
    primary: { bg: HW2_COLOR.ink, color: "#fff", border: "1px solid transparent", hover: "#2c2e34" },
    accent:  { bg: HW2_COLOR.blue, color: "#fff", border: "1px solid transparent", hover: "#234ec2" },
    ghost:   { bg: "transparent", color: HW2_COLOR.ink2, border: "1px solid transparent", hover: HW2_COLOR.chip },
    danger:  { bg: "#fff", color: HW2_COLOR.bad, border: `1px solid ${HW2_COLOR.rule2}`, hover: HW2_COLOR.badSoft },
  }[kind];
  const [h, setH] = React.useState(false);
  return (
    <button onClick={onClick} disabled={disabled}
      onMouseEnter={() => setH(true)} onMouseLeave={() => setH(false)}
      style={{
        appearance: "none", cursor: disabled ? "default" : "pointer",
        background: h && !disabled ? kinds.hover : kinds.bg,
        color: kinds.color, border: kinds.border, borderRadius: sizes.radius,
        padding: sizes.padding, font: sizes.font, fontFamily: "'DM Sans', sans-serif",
        opacity: disabled ? 0.5 : 1, transition: "background 120ms",
        ...style,
      }} {...rest}>
      {children}
    </button>
  );
}

function HW2Chip({ tone = "neutral", children, mono = false, style }) {
  const tones = {
    neutral: { bg: HW2_COLOR.chip, color: HW2_COLOR.ink2 },
    blue:    { bg: HW2_COLOR.blueSoft, color: HW2_COLOR.blue },
    good:    { bg: HW2_COLOR.goodSoft, color: HW2_COLOR.good },
    warn:    { bg: HW2_COLOR.warnSoft, color: HW2_COLOR.warn },
    bad:     { bg: HW2_COLOR.badSoft, color: HW2_COLOR.bad },
    muted:   { bg: "transparent", color: HW2_COLOR.muted },
  }[tone];
  return (
    <span style={{
      display: "inline-flex", alignItems: "center", gap: 4,
      padding: "3px 8px", borderRadius: 999,
      background: tones.bg, color: tones.color,
      font: `${mono ? "500" : "600"} 11px ${mono ? "'DM Mono'" : "'DM Sans'"}`,
      letterSpacing: mono ? "0" : "0.01em",
      ...style,
    }}>{children}</span>
  );
}

function HW2Card({ children, padded = true, style, ...rest }) {
  return (
    <div {...rest} style={{
      background: HW2_COLOR.surface,
      border: `1px solid ${HW2_COLOR.rule}`,
      borderRadius: 12,
      padding: padded ? 20 : 0,
      ...style,
    }}>{children}</div>
  );
}

// ─── Question-state pill ─────────────────────────────────────────────────────
// State comes from window.HW2.questionState(q) — always derived from contracts.
function HW2QStatePill({ state, size = "md", showIcon = true }) {
  const cfgs = {
    certified:     { color: HW2_COLOR.good,  bg: HW2_COLOR.goodSoft, icon: "✓", label: "Certified" },
    draft:         { color: HW2_COLOR.muted, bg: HW2_COLOR.chip,     icon: "○", label: "Draft" },
    demoted:       { color: HW2_COLOR.bad,   bg: HW2_COLOR.badSoft,  icon: "!", label: "Re-verify" },
    cannot_answer: { color: HW2_COLOR.warn,  bg: HW2_COLOR.warnSoft, icon: "✗", label: "Can’t answer" },
    pending:       { color: HW2_COLOR.faint, bg: HW2_COLOR.chip,     icon: "·", label: "Pending" },
  };
  const cfg = cfgs[state] || cfgs.pending;
  const sizes = size === "sm"
    ? { p: "2px 8px", fs: "9px", icSize: "9px" }
    : { p: "3px 10px", fs: "10px", icSize: "10px" };
  return (
    <span style={{
      display: "inline-flex", alignItems: "center", gap: 5,
      padding: sizes.p, borderRadius: 4,
      background: cfg.bg, color: cfg.color,
      font: `700 ${sizes.fs} 'DM Sans'`,
      letterSpacing: "0.07em", textTransform: "uppercase",
      whiteSpace: "nowrap",
    }}>
      {showIcon && <span style={{ font: `700 ${sizes.icSize} 'DM Sans'` }}>{cfg.icon}</span>}
      {cfg.label}
    </span>
  );
}

// ─── Freshness stamp ────────────────────────────────────────────────────────
function HW2Freshness({ certifiedAt, demoted, demotedReason, snapshot, style }) {
  if (demoted) {
    return (
      <span style={{
        display: "inline-flex", alignItems: "center", gap: 6,
        font: "500 11px 'DM Sans'", color: HW2_COLOR.bad,
        ...style,
      }}>
        <span style={{ width: 6, height: 6, borderRadius: "50%", background: HW2_COLOR.bad }} />
        Re-verify needed — was certified {certifiedAt}
      </span>
    );
  }
  if (certifiedAt) {
    return (
      <span style={{
        display: "inline-flex", alignItems: "center", gap: 6,
        font: "500 11px 'DM Sans'", color: HW2_COLOR.muted,
        ...style,
      }}>
        <span style={{ width: 6, height: 6, borderRadius: "50%", background: HW2_COLOR.good }} />
        Certified as of {certifiedAt}{snapshot && <span style={{ color: HW2_COLOR.faint, font: "500 11px 'DM Mono'" }}> · {snapshot}</span>}
      </span>
    );
  }
  return null;
}

// ─── Contract item ───────────────────────────────────────────────────────────
function HW2Contract({ contract }) {
  const pass = contract.pass;
  return (
    <div style={{
      display: "flex", alignItems: "flex-start", gap: 12,
      padding: "10px 14px", borderRadius: 8,
      background: pass ? HW2_COLOR.surface : HW2_COLOR.paper,
      border: `1px solid ${pass ? HW2_COLOR.rule : HW2_COLOR.rule2}`,
    }}>
      <span style={{
        width: 18, height: 18, borderRadius: "50%", flexShrink: 0,
        background: pass ? HW2_COLOR.goodSoft : HW2_COLOR.badSoft,
        color: pass ? HW2_COLOR.good : HW2_COLOR.bad,
        display: "inline-flex", alignItems: "center", justifyContent: "center",
        font: "700 11px 'DM Sans'", marginTop: 1,
      }}>{pass ? "✓" : "×"}</span>
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ font: "500 13px 'DM Sans'", color: HW2_COLOR.ink2, lineHeight: 1.4 }}>
          {contract.label}
        </div>
        <div style={{ font: "400 11.5px 'DM Sans'", color: pass ? HW2_COLOR.muted : HW2_COLOR.bad, marginTop: 2, lineHeight: 1.4 }}>
          {contract.note}
        </div>
      </div>
    </div>
  );
}

// Export to window for cross-file access (Babel per-script scope).
Object.assign(window, {
  HW2_COLOR, HW2_STAGES, ringTone,
  HW2ReadinessRing, HW2Stepper,
  HW2Btn, HW2Chip, HW2Card,
  HW2QStatePill, HW2Freshness, HW2Contract,
});
