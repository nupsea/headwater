// Headwater 2 — Resolve.
//
// Anti-overload. Two-track UI:
//   • Primary: blocking cards (NOT batchable), one at a time, ranked by impact.
//     Each card lists the SPECIFIC evidence contract(s) it unblocks.
//   • Side panel: trivia (batchable). Defaults to "accept all suggestions"
//     in one click; user can override.
//
// Progress is REAL: every action either flips one or more contracts to pass,
// or records a gap. No fictional points.

function HW2Resolve({ project, cards, onResolveOne, onBatchAccept, onAllDone }) {
  const blocking = cards.filter(c => !c.batchable);
  const trivia   = cards.filter(c =>  c.batchable);

  const [idx, setIdx]               = React.useState(0);
  const [history, setHistory]       = React.useState([]); // {id, choice}
  const [exitingDir, setExitingDir] = React.useState(0);
  const [triviaCollapsed, setTC]    = React.useState(false);
  const [triviaDone, setTD]         = React.useState(false);

  React.useEffect(() => {
    if (history.length >= blocking.length && triviaDone) {
      const t = setTimeout(onAllDone, 500);
      return () => clearTimeout(t);
    }
  }, [history.length, triviaDone]); // eslint-disable-line

  const current = blocking[idx];
  const isDone  = !current;

  const advance = (choice, dir) => {
    if (!current) return;
    setExitingDir(dir);
    setTimeout(() => {
      setHistory(h => [...h, { id: current.id, choice }]);
      onResolveOne(current, choice);
      setIdx(i => i + 1);
      setExitingDir(0);
    }, 220);
  };

  React.useEffect(() => {
    const onKey = (e) => {
      if (e.target.tagName === "INPUT" || e.target.tagName === "TEXTAREA" || e.target.tagName === "SELECT") return;
      if (e.key === "Enter" && current) advance({ kind: "confirm" }, 1);
      if (e.key === "Escape" && current) advance({ kind: "gap" }, -1);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [current]); // eslint-disable-line

  const driftBlocking = blocking.filter(c => c.isDriftCard).length;

  return (
    <div style={{ maxWidth: 1080, margin: "0 auto", padding: "28px 32px 80px" }}>
      <div style={{ display: "flex", alignItems: "baseline", justifyContent: "space-between", marginBottom: 4 }}>
        <span style={{
          font: "600 11px 'DM Sans'", color: HW2_COLOR.blue,
          letterSpacing: "0.08em", textTransform: "uppercase",
        }}>Step 3 of 5 · Resolve</span>
        <span style={{ font: "500 12px 'DM Mono'", color: HW2_COLOR.muted }}>
          {Math.min(history.length + 1, blocking.length)} of {blocking.length} blocking
        </span>
      </div>
      <h2 style={{
        font: "600 26px 'DM Sans'", letterSpacing: "-0.02em",
        color: HW2_COLOR.ink, lineHeight: 1.25, marginTop: 8, marginBottom: 4,
      }}>
        {driftBlocking > 0
          ? `${driftBlocking} drift item${driftBlocking === 1 ? "" : "s"} + ${blocking.length - driftBlocking} other blocker${(blocking.length - driftBlocking) === 1 ? "" : "s"}.`
          : `${blocking.length} things only you can know.`}
      </h2>
      <p style={{ font: "400 14px 'DM Sans'", color: HW2_COLOR.muted, marginBottom: 24, lineHeight: 1.55 }}>
        Ranked by how much each one moves the per-answer verdict. Trivia is on the right
        — accept all suggestions, or open it to override. We won&rsquo;t make blocking
        guesses for you.
      </p>

      <div style={{ display: "grid", gridTemplateColumns: "1fr 280px", gap: 18 }}>

        {/* Blocking card stack */}
        <div style={{ position: "relative", minHeight: 420 }}>
          {/* Behind cards peek */}
          {blocking.slice(idx + 1, idx + 3).map((c, i) => (
            <div key={c.id} style={{
              position: "absolute", inset: 0,
              transform: `translateY(${(i + 1) * 8}px) scale(${1 - (i + 1) * 0.015})`,
              background: HW2_COLOR.surface, border: `1px solid ${HW2_COLOR.rule}`,
              borderRadius: 14, opacity: 0.55 - i * 0.2, zIndex: 0,
            }} />
          ))}

          {current && (
            <ResolveCard
              key={current.id}
              card={current}
              exitingDir={exitingDir}
              onConfirm={(value) => advance({ kind: "confirm", value }, 1)}
              onDontKnow={() => advance({ kind: "gap" }, -1)}
            />
          )}

          {isDone && (
            <div style={{
              position: "absolute", inset: 0, display: "grid", placeItems: "center",
              background: "#fff", border: `1px solid ${HW2_COLOR.rule}`, borderRadius: 14,
              minHeight: 360,
            }}>
              <div style={{ textAlign: "center" }}>
                <div style={{
                  width: 56, height: 56, borderRadius: "50%", margin: "0 auto 14px",
                  background: HW2_COLOR.goodSoft, color: HW2_COLOR.good,
                  display: "grid", placeItems: "center", font: "600 24px 'DM Sans'",
                }}>✓</div>
                <div style={{ font: "600 16px 'DM Sans'", color: HW2_COLOR.ink }}>
                  Blocking resolved.
                </div>
                <div style={{ font: "400 13px 'DM Sans'", color: HW2_COLOR.muted, marginTop: 4 }}>
                  {triviaDone ? "Heading to Readiness…" : "Finish trivia on the right →"}
                </div>
              </div>
            </div>
          )}

          {/* Up next, blocking only */}
          {!isDone && blocking.length - history.length > 1 && (
            <div style={{ marginTop: 22 }}>
              <div style={{
                font: "600 11px 'DM Sans'", color: HW2_COLOR.muted,
                letterSpacing: "0.06em", textTransform: "uppercase", marginBottom: 8,
              }}>Up next (blocking)</div>
              <div style={{ display: "grid", gap: 4 }}>
                {blocking.slice(idx + 1).map((c, i) => (
                  <div key={c.id} style={{
                    display: "flex", alignItems: "center", gap: 12,
                    padding: "6px 12px", borderRadius: 6,
                    font: "500 13px 'DM Sans'", color: HW2_COLOR.muted,
                  }}>
                    <span style={{ font: "500 11px 'DM Mono'", color: HW2_COLOR.faint, width: 22 }}>
                      {idx + i + 2}.
                    </span>
                    <span style={{ flex: 1 }}>{c.title}</span>
                    <ImpactPill impact={c.impact}>{c.impact}</ImpactPill>
                  </div>
                ))}
              </div>
            </div>
          )}

          {!isDone && (
            <div style={{
              marginTop: 18, font: "400 11px 'DM Sans'", color: HW2_COLOR.faint,
              textAlign: "center", display: "flex", justifyContent: "center", gap: 16,
            }}>
              <Kbd k="↵">confirm</Kbd>
              <Kbd k="esc">mark gap</Kbd>
              <span style={{ alignSelf: "center" }}>Non-blocking. Skipped items become explicit gaps in the verdict.</span>
            </div>
          )}
        </div>

        {/* Trivia side panel */}
        <div style={{
          background: HW2_COLOR.surface, border: `1px solid ${HW2_COLOR.rule}`,
          borderRadius: 12, padding: 16, alignSelf: "flex-start",
        }}>
          <div style={{ display: "flex", alignItems: "baseline", justifyContent: "space-between", marginBottom: 8 }}>
            <span style={{ font: "600 11px 'DM Sans'", color: HW2_COLOR.muted, letterSpacing: "0.06em", textTransform: "uppercase" }}>
              Trivia · low impact
            </span>
            <span style={{ font: "500 11px 'DM Mono'", color: HW2_COLOR.faint }}>{trivia.length}</span>
          </div>
          <p style={{ font: "400 12px 'DM Sans'", color: HW2_COLOR.muted, marginBottom: 12, lineHeight: 1.5 }}>
            None of these block a question. Accept all suggestions in one click — or open
            the panel to set them individually.
          </p>

          {!triviaDone ? (
            <>
              <HW2Btn kind="accent" size="md" style={{ width: "100%" }}
                onClick={() => { onBatchAccept(trivia); setTD(true); }}>
                Accept all {trivia.length} suggestions
              </HW2Btn>
              <button onClick={() => setTC(v => !v)} style={{
                appearance: "none", background: "transparent", border: "none", cursor: "pointer",
                marginTop: 8, padding: 0, font: "500 12px 'DM Sans'", color: HW2_COLOR.muted,
                fontFamily: "'DM Sans', sans-serif",
              }}>
                {triviaCollapsed ? "Hide" : "Or override individually"}
              </button>
              {triviaCollapsed && (
                <div style={{ marginTop: 10, display: "grid", gap: 6 }}>
                  {trivia.map(c => (
                    <div key={c.id} style={{
                      padding: "8px 10px", borderRadius: 7,
                      background: HW2_COLOR.paper, border: `1px solid ${HW2_COLOR.rule}`,
                    }}>
                      <div style={{ font: "500 12px 'DM Sans'", color: HW2_COLOR.ink2, lineHeight: 1.4 }}>{c.title}</div>
                      <div style={{ font: "400 11px 'DM Sans'", color: HW2_COLOR.muted, marginTop: 3 }}>
                        Suggested: <strong style={{ color: HW2_COLOR.ink2 }}>{c.suggested}</strong>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </>
          ) : (
            <div style={{
              padding: "10px 12px", borderRadius: 8,
              background: HW2_COLOR.goodSoft, color: HW2_COLOR.good,
              font: "500 12px 'DM Sans'", display: "flex", alignItems: "center", gap: 8,
            }}>
              <span style={{ font: "700 13px 'DM Sans'" }}>✓</span>
              All {trivia.length} suggestions applied.
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

// ─── Single Resolve card ────────────────────────────────────────────────────
function ResolveCard({ card, exitingDir, onConfirm, onDontKnow }) {
  const [choice, setChoice]   = React.useState(card.suggested || null);
  const [mapping, setMapping] = React.useState(() => {
    if (card.kind !== "mapping") return null;
    return Object.fromEntries(card.mapping.map(m => [m.code, m.suggested || ""]));
  });

  const ready = card.kind === "mapping" ? true : !!choice;
  const finalChoice = card.kind === "mapping" ? mapping : choice;

  // Contracts this card clears (precise progress description)
  const clearsLine = card.clearsContracts
    ? `Confirming clears ${card.clearsContracts.contractIds.length} contract${card.clearsContracts.contractIds.length === 1 ? "" : "s"} on question "${card.clearsContracts.questionId}"`
    : "Confirming records a definition; no contract changes";

  return (
    <div style={{
      position: "relative", zIndex: 5,
      background: card.isDriftCard ? "#fff" : HW2_COLOR.surface,
      border: `1px solid ${card.isDriftCard ? HW2_COLOR.bad : HW2_COLOR.rule2}`,
      borderRadius: 14, padding: 26,
      boxShadow: "0 1px 0 rgba(20,20,30,0.02), 0 12px 32px rgba(20,20,30,0.05)",
      transition: "transform 220ms cubic-bezier(0.4,0,0.2,1), opacity 220ms",
      transform: exitingDir === 1  ? "translateX(60px) rotate(2deg)"
              : exitingDir === -1 ? "translateX(-60px) rotate(-2deg)"
              : "translateX(0)",
      opacity: exitingDir === 0 ? 1 : 0,
    }}>
      {card.isDriftCard && (
        <div style={{
          display: "inline-flex", alignItems: "center", gap: 6,
          padding: "3px 9px", borderRadius: 4, marginBottom: 12,
          background: HW2_COLOR.badSoft, color: HW2_COLOR.bad,
          font: "700 10px 'DM Sans'", letterSpacing: "0.08em", textTransform: "uppercase",
        }}>
          <span style={{ width: 6, height: 6, borderRadius: "50%", background: HW2_COLOR.bad }} />
          Continuous certification · revoked Q1
        </div>
      )}
      <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 14, flexWrap: "wrap" }}>
        <ImpactPill impact={card.impact}>{card.impactLabel}</ImpactPill>
        <span style={{ font: "400 12px 'DM Sans'", color: HW2_COLOR.muted }}>· {card.why}</span>
      </div>
      <h3 style={{
        font: "600 19px 'DM Sans'", letterSpacing: "-0.015em",
        color: HW2_COLOR.ink, lineHeight: 1.3, marginBottom: 8,
      }}>{card.title}</h3>
      <p style={{ font: "400 14px 'DM Sans'", color: HW2_COLOR.ink2, lineHeight: 1.55, marginBottom: 18 }}>
        {card.body}
      </p>

      {card.kind === "choice" && (
        <ChoiceBody card={card} choice={choice} setChoice={setChoice} />
      )}
      {card.kind === "binary" && (
        <BinaryBody card={card} choice={choice} setChoice={setChoice} />
      )}
      {card.kind === "mapping" && (
        <MappingBody card={card} mapping={mapping} setMapping={setMapping} />
      )}

      <div style={{
        marginTop: 22, paddingTop: 18, borderTop: `1px solid ${HW2_COLOR.rule}`,
        display: "flex", alignItems: "center", justifyContent: "space-between", gap: 8,
      }}>
        <div style={{ font: "400 12px 'DM Sans'", color: HW2_COLOR.muted, maxWidth: 460, lineHeight: 1.5 }}>
          {clearsLine}.<br />
          <span style={{ color: HW2_COLOR.ink2 }}>If skipped: {card.gapHint}.</span>
        </div>
        <div style={{ display: "flex", gap: 8 }}>
          <HW2Btn onClick={onDontKnow}>I don’t know — mark gap</HW2Btn>
          <HW2Btn kind="accent" disabled={!ready} onClick={() => onConfirm(finalChoice)}>Confirm →</HW2Btn>
        </div>
      </div>
    </div>
  );
}

function ChoiceBody({ card, choice, setChoice }) {
  return (
    <>
      <div style={{ display: "flex", alignItems: "center", gap: 6, flexWrap: "wrap", marginBottom: 18 }}>
        {card.sequence.map((s, i) => (
          <React.Fragment key={s}>
            <span style={{
              padding: "4px 9px", borderRadius: 14,
              background: HW2_COLOR.chip, color: HW2_COLOR.ink2,
              font: "500 12px 'DM Mono'",
            }}>{s}</span>
            {i < card.sequence.length - 1 && <span style={{ color: HW2_COLOR.faint, font: "500 12px 'DM Mono'" }}>→</span>}
          </React.Fragment>
        ))}
      </div>
      <div style={{ font: "500 13px 'DM Sans'", color: HW2_COLOR.muted, marginBottom: 10 }}>{card.prompt}</div>
      <div style={{ display: "flex", flexWrap: "wrap", gap: 8 }}>
        {card.options.map(opt => (
          <OptionPill key={opt} opt={opt} sel={choice === opt} sug={opt === card.suggested}
            onClick={() => setChoice(opt)} />
        ))}
      </div>
    </>
  );
}
function BinaryBody({ card, choice, setChoice }) {
  return (
    <div style={{ display: "grid", gap: 8 }}>
      {card.options.map(opt => {
        const sel = choice === opt, sug = opt === card.suggested;
        return (
          <button key={opt} onClick={() => setChoice(opt)} style={{
            appearance: "none", cursor: "pointer", textAlign: "left",
            padding: "12px 16px", borderRadius: 10,
            border: `1.5px solid ${sel ? HW2_COLOR.blue : HW2_COLOR.rule2}`,
            background: sel ? HW2_COLOR.blueSoft : "#fff",
            font: "500 13px 'DM Sans'", color: sel ? HW2_COLOR.blue : HW2_COLOR.ink,
            fontFamily: "'DM Sans', sans-serif",
            display: "flex", alignItems: "center", gap: 10,
          }}>
            <Radio sel={sel} />
            <span style={{ flex: 1 }}>{opt}</span>
            {sug && <span style={{ font: "500 10px 'DM Mono'", color: HW2_COLOR.muted }}>· best guess</span>}
          </button>
        );
      })}
    </div>
  );
}
function MappingBody({ card, mapping, setMapping }) {
  return (
    <div style={{ display: "grid", gap: 8 }}>
      {card.mapping.map(m => (
        <div key={m.code} style={{
          display: "grid", gridTemplateColumns: "60px 1fr", alignItems: "center",
          gap: 12, padding: "10px 14px", borderRadius: 10,
          background: "#fff", border: `1px solid ${HW2_COLOR.rule2}`,
        }}>
          <span style={{
            font: "600 14px 'DM Mono'", color: HW2_COLOR.ink,
            padding: "4px 10px", background: HW2_COLOR.chip, borderRadius: 6,
            textAlign: "center",
          }}>{m.code}</span>
          <select value={mapping[m.code]} onChange={(e) => setMapping(p => ({ ...p, [m.code]: e.target.value }))}
            style={{
              appearance: "none", background: "#fff",
              border: `1px solid ${HW2_COLOR.rule2}`, borderRadius: 8,
              padding: "8px 12px", font: "500 13px 'DM Sans'", color: HW2_COLOR.ink,
              fontFamily: "'DM Sans', sans-serif", width: "100%", cursor: "pointer",
            }}>
            <option value="">— I don’t know — mark as gap</option>
            {m.options.map(o => <option key={o} value={o}>{o}</option>)}
          </select>
        </div>
      ))}
    </div>
  );
}

function OptionPill({ opt, sel, sug, onClick }) {
  return (
    <button onClick={onClick} style={{
      appearance: "none", cursor: "pointer", padding: "10px 14px",
      borderRadius: 10, border: `1.5px solid ${sel ? HW2_COLOR.blue : HW2_COLOR.rule2}`,
      background: sel ? HW2_COLOR.blueSoft : "#fff",
      font: "500 13px 'DM Sans'", color: sel ? HW2_COLOR.blue : HW2_COLOR.ink,
      fontFamily: "'DM Sans', sans-serif",
      display: "inline-flex", alignItems: "center", gap: 8,
    }}>
      <Radio sel={sel} />
      {opt}
      {sug && <span style={{ font: "500 10px 'DM Mono'", color: HW2_COLOR.muted }}>· best guess</span>}
    </button>
  );
}
function Radio({ sel }) {
  return (
    <span style={{
      width: 14, height: 14, borderRadius: "50%",
      border: `1.5px solid ${sel ? HW2_COLOR.blue : HW2_COLOR.rule2}`,
      background: sel ? HW2_COLOR.blue : "transparent",
      display: "inline-flex", alignItems: "center", justifyContent: "center", flexShrink: 0,
    }}>{sel && <span style={{ width: 5, height: 5, borderRadius: "50%", background: "#fff" }} />}</span>
  );
}

function ImpactPill({ impact, children }) {
  const tones = {
    high: { bg: HW2_COLOR.badSoft, color: HW2_COLOR.bad },
    med:  { bg: HW2_COLOR.warnSoft, color: HW2_COLOR.warn },
    low:  { bg: HW2_COLOR.chip,     color: HW2_COLOR.muted },
  }[impact] || { bg: HW2_COLOR.chip, color: HW2_COLOR.muted };
  return (
    <span style={{
      display: "inline-flex", alignItems: "center", gap: 4,
      padding: "3px 8px", borderRadius: 4,
      background: tones.bg, color: tones.color,
      font: "700 10px 'DM Sans'", letterSpacing: "0.06em", textTransform: "uppercase",
    }}>{children}</span>
  );
}

function Kbd({ k, children }) {
  return (
    <span style={{ display: "inline-flex", alignItems: "center", gap: 6 }}>
      <span style={{
        font: "500 11px 'DM Mono'", color: HW2_COLOR.ink2,
        padding: "2px 6px", background: "#fff",
        border: `1px solid ${HW2_COLOR.rule2}`, borderRadius: 4,
      }}>{k}</span>
      <span>{children}</span>
    </span>
  );
}

Object.assign(window, { HW2Resolve });
