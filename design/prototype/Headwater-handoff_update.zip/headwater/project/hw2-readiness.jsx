// Headwater 2 — Readiness ledger (stage 4).
//
// Now per-question. The hero artifacts:
//   • A list of per-question verdicts: Certified · Draft · Can't answer · Re-verify.
//   • The "can't answer" question is treated as a HERO state (not a corner case)
//     — the most trust-building screen in the product.
//   • Behind that: the shared 5-bucket data ledger (have/trustworthy/risky/missing/misleading).
//   • Per-answer freshness ("as of <date>, snapshot <id>") on certified items.

function HW2Readiness({ project, readiness, source, onAnswer, onImprove }) {
  const askable      = project.questions.filter(q => q.state !== "cannot_answer");
  const cantAnswer   = project.questions.filter(q => q.state === "cannot_answer");
  const projectRead  = window.HW2.computeProjectReadout(project);

  return (
    <div style={{ maxWidth: 1020, margin: "0 auto", padding: "28px 32px 80px" }}>
      <span style={{
        font: "600 11px 'DM Sans'", color: HW2_COLOR.blue,
        letterSpacing: "0.08em", textTransform: "uppercase",
      }}>Step 4 of 5 · Readiness</span>
      <h2 style={{
        font: "600 26px 'DM Sans'", letterSpacing: "-0.02em",
        color: HW2_COLOR.ink, lineHeight: 1.25, marginTop: 8, marginBottom: 4,
      }}>The verdict — per question.</h2>
      <p style={{ font: "400 14px 'DM Sans'", color: HW2_COLOR.muted, marginBottom: 24, lineHeight: 1.5 }}>
        Headwater certifies <em>answers</em>, not projects. The same project can hold a
        certified answer next to a Draft one — and a previously certified answer can be
        revoked when the data drifts.
      </p>

      {/* Per-question verdict cards */}
      <div style={{ display: "grid", gap: 12, marginBottom: 28 }}>
        {askable.map((q) => <QuestionVerdict key={q.id} q={q} />)}
      </div>

      {/* HERO: can't-answer questions — the honest negative */}
      {cantAnswer.length > 0 && (
        <div style={{
          padding: "20px 22px", marginBottom: 28,
          background: "#fff", border: `1.5px solid ${HW2_COLOR.warn}`, borderRadius: 12,
        }}>
          <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 10 }}>
            <span style={{
              padding: "3px 9px", borderRadius: 4,
              background: HW2_COLOR.warnSoft, color: HW2_COLOR.warn,
              font: "700 10px 'DM Sans'", letterSpacing: "0.08em", textTransform: "uppercase",
              display: "inline-flex", alignItems: "center", gap: 5,
            }}>
              <span>✗</span> Can’t answer with this data
            </span>
            <span style={{ font: "400 12px 'DM Sans'", color: HW2_COLOR.muted }}>
              {cantAnswer.length} question{cantAnswer.length === 1 ? "" : "s"}
            </span>
          </div>
          {cantAnswer.map(q => (
            <div key={q.id} style={{
              padding: "14px 0",
              borderTop: `1px solid ${HW2_COLOR.rule}`,
            }}>
              <div style={{ font: "600 15px 'DM Sans'", color: HW2_COLOR.ink, marginBottom: 6, letterSpacing: "-0.01em" }}>
                {q.title}
              </div>
              <div style={{ font: "400 13px 'DM Sans'", color: HW2_COLOR.ink2, lineHeight: 1.55, marginBottom: 6 }}>
                <strong style={{ color: HW2_COLOR.warn }}>Why not: </strong>
                {q.cannotAnswerReason}
              </div>
              {q.cannotAnswerHint && (
                <div style={{ font: "400 12px 'DM Sans'", color: HW2_COLOR.muted, lineHeight: 1.5 }}>
                  {q.cannotAnswerHint}
                </div>
              )}
            </div>
          ))}
          <div style={{
            marginTop: 14, padding: "10px 14px",
            background: HW2_COLOR.warnSoft, borderRadius: 8,
            font: "400 12px 'DM Sans'", color: HW2_COLOR.ink2, lineHeight: 1.5,
          }}>
            <strong style={{ color: HW2_COLOR.warn }}>This is the moment Headwater earns trust.</strong>{" "}
            A confident "we can&rsquo;t answer that" is more valuable than a confidently-wrong number.
          </div>
        </div>
      )}

      {/* Shared 5-bucket data ledger */}
      <div style={{
        font: "600 11px 'DM Sans'", color: HW2_COLOR.muted,
        letterSpacing: "0.07em", textTransform: "uppercase", marginBottom: 10,
      }}>The underlying data, in five buckets</div>
      <div style={{ display: "grid", gap: 10, marginBottom: 24 }}>
        {readiness.buckets.map(b => <ReadinessRow key={b.key} bucket={b} />)}
      </div>

      {/* The "sacred badge" rule */}
      <div style={{
        padding: "14px 18px", marginBottom: 24,
        background: HW2_COLOR.chip, borderRadius: 10,
        border: `1px solid ${HW2_COLOR.rule2}`,
        font: "400 12px 'DM Sans'", color: HW2_COLOR.ink2, lineHeight: 1.55,
      }}>
        <strong style={{ color: HW2_COLOR.ink }}>The rule:</strong>{" "}
        Certification is recomputed from facts — locked columns + lineage · no blocking
        gap · structural integrity · no misleading items in lineage · consistent
        definition · confident insight. Not from clicks. <strong style={{ color: HW2_COLOR.ink }}>The badge is sacred.</strong>
      </div>

      {/* Actions */}
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", gap: 8 }}>
        <HW2Btn onClick={onImprove}>← Improve readiness</HW2Btn>
        <HW2Btn kind="accent" size="lg" onClick={onAnswer}>
          {projectRead.certifiedCount === projectRead.total && projectRead.total > 0
            ? "View certified answers"
            : "Go to Answer →"}
        </HW2Btn>
      </div>
    </div>
  );
}

// ─── A single per-question verdict ──────────────────────────────────────────
function QuestionVerdict({ q }) {
  const state = window.HW2.questionState(q);
  const ro    = window.HW2.computeQuestionReadiness(q);
  const [open, setOpen] = React.useState(false);

  const stateColor = ({
    certified: HW2_COLOR.good,
    draft:     HW2_COLOR.muted,
    demoted:   HW2_COLOR.bad,
  })[state];

  return (
    <div style={{
      background: HW2_COLOR.surface,
      border: `1px solid ${state === "demoted" ? HW2_COLOR.bad : HW2_COLOR.rule}`,
      borderRadius: 12, overflow: "hidden",
    }}>
      <button onClick={() => setOpen(v => !v)} style={{
        appearance: "none", background: "transparent", border: "none", cursor: "pointer",
        width: "100%", padding: "16px 20px", textAlign: "left",
        display: "flex", alignItems: "center", gap: 16,
        fontFamily: "'DM Sans', sans-serif",
      }}>
        <HW2ReadinessRing
          value={ro.pct}
          certified={state === "certified"}
          demoted={state === "demoted"}
          size={40} stroke={3} showLabel={false} animate={false} />
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 4 }}>
            <HW2QStatePill state={state} size="sm" />
            <span style={{ font: "500 11px 'DM Mono'", color: HW2_COLOR.faint }}>
              {ro.passing}/{ro.total} contracts pass
            </span>
          </div>
          <div style={{ font: "600 15px 'DM Sans'", color: HW2_COLOR.ink, lineHeight: 1.35, letterSpacing: "-0.005em" }}>
            {q.title}
          </div>
          {state === "demoted" && q.demotedReason && (
            <div style={{ font: "400 12px 'DM Sans'", color: HW2_COLOR.bad, marginTop: 6, lineHeight: 1.5 }}>
              {q.demotedReason}
            </div>
          )}
          {state === "certified" && q.certifiedAt && (
            <HW2Freshness certifiedAt={q.certifiedAt} style={{ marginTop: 6 }} />
          )}
        </div>
        <span style={{ color: HW2_COLOR.faint, font: "500 11px 'DM Mono'" }}>{open ? "▾" : "▸"}</span>
      </button>

      {open && (
        <div style={{ padding: "0 20px 18px 76px", display: "grid", gap: 8 }}>
          {q.contracts.map(c => <HW2Contract key={c.id} contract={c} />)}
          {q.insightConfidence && (
            <div style={{
              display: "flex", alignItems: "center", gap: 8,
              padding: "8px 14px", borderRadius: 8,
              background: HW2_COLOR.paper, border: `1px dashed ${HW2_COLOR.rule2}`,
              font: "400 12px 'DM Sans'", color: HW2_COLOR.muted, lineHeight: 1.5,
            }}>
              <span style={{ font: "600 11px 'DM Mono'", color: HW2_COLOR.faint }}>insight</span>
              <span><strong style={{ color: HW2_COLOR.ink2 }}>{q.insightConfidence.label}</strong> · {q.insightConfidence.basis}</span>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

// ─── Bucket row (shared data landscape) ─────────────────────────────────────
function ReadinessRow({ bucket }) {
  const [open, setOpen] = React.useState(false);
  const tones = {
    good:  { color: HW2_COLOR.good, bg: HW2_COLOR.goodSoft, sym: "✓" },
    warn:  { color: HW2_COLOR.warn, bg: HW2_COLOR.warnSoft, sym: "!" },
    muted: { color: HW2_COLOR.muted, bg: HW2_COLOR.chip,    sym: "○" },
    bad:   { color: HW2_COLOR.bad,  bg: HW2_COLOR.badSoft,  sym: "△" },
  }[bucket.tone];
  return (
    <div style={{
      background: HW2_COLOR.surface, border: `1px solid ${HW2_COLOR.rule}`,
      borderRadius: 12, overflow: "hidden",
    }}>
      <button onClick={() => setOpen(v => !v)} style={{
        appearance: "none", background: "transparent", border: "none", cursor: "pointer",
        width: "100%", padding: "12px 18px", textAlign: "left",
        display: "flex", alignItems: "center", gap: 14, fontFamily: "'DM Sans', sans-serif",
      }}>
        <span style={{
          width: 26, height: 26, borderRadius: "50%",
          background: tones.bg, color: tones.color,
          display: "inline-flex", alignItems: "center", justifyContent: "center",
          font: "700 13px 'DM Sans'", flexShrink: 0,
        }}>{tones.sym}</span>
        <span style={{ font: "600 13px 'DM Sans'", color: HW2_COLOR.ink, minWidth: 130 }}>{bucket.label}</span>
        <span style={{ font: "400 13px 'DM Sans'", color: HW2_COLOR.muted, flex: 1, lineHeight: 1.45 }}>
          {bucket.items[0]}
          {bucket.items.length > 1 && <span style={{ color: HW2_COLOR.faint }}> +{bucket.items.length - 1} more</span>}
        </span>
        <span style={{ color: HW2_COLOR.faint, font: "500 11px 'DM Mono'" }}>{open ? "▾" : "▸"}</span>
      </button>
      {open && (
        <div style={{ padding: "0 18px 14px 58px", display: "grid", gap: 6 }}>
          {bucket.items.map((it, i) => (
            <div key={i} style={{
              padding: "9px 14px", background: HW2_COLOR.paper, borderRadius: 8,
              border: `1px solid ${HW2_COLOR.rule}`,
              font: "400 12.5px 'DM Sans'", color: HW2_COLOR.ink2, lineHeight: 1.5,
              display: "flex", alignItems: "flex-start", gap: 10,
            }}>
              <span style={{ font: "500 12px 'DM Mono'", color: tones.color, marginTop: 1, flexShrink: 0 }}>{tones.sym}</span>
              <span>{it}</span>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

Object.assign(window, { HW2Readiness });
