// Headwater 2 — root app.
//
// Routing: Catalog · Query · Project flow (Frame → Generate → Understand →
// Resolve → Readiness → Answer). The project banner with the readout, drift
// callout, and stepper sits above the project body.
//
// Importantly: certification state is NEVER mutated by a "points" handler.
// When the user confirms a Resolve card, we flip the specific evidence
// contracts that card declares it clears. The Question state is derived from
// contracts via window.HW2.questionState().

const { useState, useEffect, useMemo } = React;

function HW2App() {
  // --- Data ---
  const initial = useMemo(() => JSON.parse(JSON.stringify(window.HW2)), []);
  const [sources]   = useState(initial.sources);
  const [source]    = useState(initial.sources[0]);
  const [projects, setProjects] = useState(initial.projects);
  const [data]      = useState(initial);

  // --- Routing ---
  const [route, setRoute] = useState(() => {
    // Land on the project with drift, if any — otherwise Catalog.
    const drifted = initial.projects.find(p => p.driftSinceLastVisit);
    if (drifted) return { kind: "project", projectId: drifted.id, stage: drifted.stage || "answer" };
    return { kind: "catalog" };
  });
  const [pendingSql, setPendingSql] = useState("");
  const project = route.kind === "project" ? projects.find(p => p.id === route.projectId) : null;
  const stage   = route.kind === "project" ? route.stage : null;

  // --- Connect modal ---
  const [connectOpen, setConnectOpen] = useState(false);

  // --- Mutators ---
  const updateProject = (id, patch) =>
    setProjects(ps => ps.map(p => p.id === id ? { ...p, ...patch, lastTouched: "Just now" } : p));

  const flipContracts = (questionId, contractIds, pass) => {
    if (!project) return;
    setProjects(ps => ps.map(p => {
      if (p.id !== project.id) return p;
      return {
        ...p,
        questions: p.questions.map(q => {
          if (q.id !== questionId) return q;
          const nextContracts = q.contracts.map(c =>
            contractIds.includes(c.id) ? { ...c, pass } : c
          );
          // If we just made every contract pass and this q was demoted, lift the demotion.
          const allPass = nextContracts.every(c => c.pass);
          const nextState = (q.state === "demoted" && allPass) ? "certified" : q.state;
          const certifiedAt = (nextState === "certified" && q.state === "demoted") ? "Today" : q.certifiedAt;
          return { ...q, contracts: nextContracts, state: nextState, certifiedAt };
        }),
      };
    }));
  };

  const newProject = () => {
    const overLimit = projects.length >= window.HW2.sourceLimits.maxProjectsPerSource;
    if (overLimit) {
      alert(`Limit: ${window.HW2.sourceLimits.maxProjectsPerSource} projects per source.`);
      return;
    }
    const id = "p_" + Date.now();
    const p = {
      id, title: "Untitled goal", goal: "", sourceId: source.id,
      selectedTables: [], stage: "frame", lastTouched: "Just now",
      questions: [], proposedNotAnswerable: [],
    };
    setProjects(ps => [...ps, p]);
    setRoute({ kind: "project", projectId: id, stage: "frame" });
  };

  const goRoute = (r) => setRoute(r);
  const jumpStage = (k) => setRoute(r => ({ ...r, stage: k }));
  const openQueryWith = (sql) => { setPendingSql(sql); setRoute({ kind: "query" }); };

  // Dismiss drift banner when user lands on resolve
  React.useEffect(() => {
    if (stage === "resolve" && project?.driftSinceLastVisit) {
      // banner stays visible — only clears once the drift card is confirmed
    }
  }, [stage, project?.id]);

  // --- Tweaks ---
  const t = useTweaks(TWEAK_DEFAULTS);
  const [tweaksOpen, setTweaksOpen] = useState(false);
  useEffect(() => {
    const onMsg = (e) => {
      if (e.data?.type === "__activate_edit_mode")   setTweaksOpen(true);
      if (e.data?.type === "__deactivate_edit_mode") setTweaksOpen(false);
    };
    window.addEventListener("message", onMsg);
    window.parent.postMessage({ type: "__edit_mode_available" }, "*");
    return () => window.removeEventListener("message", onMsg);
  }, []);

  // ─── Render main area ────────────────────────────────────────────────────
  let main = null;
  if (route.kind === "catalog") {
    main = <HW2Catalog source={source} catalogColumns={data.catalogColumns}
                       sampleRows={data.sampleRows} onOpenQuery={openQueryWith} />;
  } else if (route.kind === "query") {
    main = <HW2Query source={source} sampleRows={data.sampleRows} initialSQL={pendingSql} />;
  } else if (project) {
    main = <ProjectFlow project={project} source={source} data={data}
                        stage={stage}
                        onUpdate={(patch) => updateProject(project.id, patch)}
                        onJumpStage={jumpStage}
                        flipContracts={flipContracts} />;
  }

  return (
    <>
      <HW2Shell
        source={source} sources={sources} projects={projects}
        route={route} onRoute={goRoute}
        project={project} stage={stage} onJumpStage={jumpStage}
        onConnectSource={() => setConnectOpen(true)}
        onNewProject={newProject}>
        {main}
      </HW2Shell>

      {connectOpen && (
        <HW2Connect
          connectors={data.connectors}
          sampleSchemas={source.schemas}
          onClose={() => setConnectOpen(false)}
          onComplete={() => setConnectOpen(false)}
        />
      )}

      {tweaksOpen && <Hw2Tweaks t={t} onClose={() => setTweaksOpen(false)} />}
    </>
  );
}

// ─── ProjectFlow ────────────────────────────────────────────────────────────
function ProjectFlow({ project, source, data, stage, onUpdate, onJumpStage, flipContracts }) {
  if (stage === "frame") {
    return <HW2Frame
      project={project} source={source}
      onGenerate={(spec) => {
        onUpdate({
          goal: spec.goal,
          decision: spec.decision, metric: spec.metric, horizon: spec.horizon,
          selectedTables: spec.selectedTables,
          title: spec.goal ? truncate(spec.goal, 64) : project.title,
          stage: "generate",
        });
        onJumpStage("generate");
      }}
    />;
  }
  if (stage === "generate") {
    return <HW2Generate
      project={project} source={source}
      onDone={() => { onUpdate({ stage: "understand" }); onJumpStage("understand"); }}
    />;
  }
  if (stage === "understand") {
    return <HW2Understand
      project={project} data={data}
      onProposedAcceptAll={() => { /* no-op visual */ }}
      onProposedCurate={(curated) => {
        // For brand-new projects, materialize the curated proposed questions
        // onto the project as actual questions with default contracts.
        if (project.questions.length > 0) return;
        const accepted = data.proposedQuestions.filter(pq => curated[pq.id]?.keep);
        const newQuestions = accepted.map(pq => buildBlankQuestionFromProposed(pq));
        onUpdate({ questions: newQuestions });
      }}
      onConfirm={() => { onUpdate({ stage: "resolve" }); onJumpStage("resolve"); }}
    />;
  }
  if (stage === "resolve") {
    return <HW2Resolve
      project={project}
      cards={data.resolveCards}
      onResolveOne={(card, choice) => {
        // Flip the specific contracts this card declared it clears (only on
        // confirm; "I don't know" leaves them failing as an explicit gap).
        if (choice?.kind === "confirm" && card.clearsContracts) {
          flipContracts(
            card.clearsContracts.questionId,
            card.clearsContracts.contractIds,
            true,
          );
        }
        // Drift dismissal: when the drift card is confirmed, clear the banner.
        if (card.isDriftCard && choice?.kind === "confirm") {
          onUpdate({ driftSinceLastVisit: null });
        }
      }}
      onBatchAccept={() => { /* trivia accepted silently */ }}
      onAllDone={() => { onUpdate({ stage: "readiness" }); onJumpStage("readiness"); }}
    />;
  }
  if (stage === "readiness") {
    return <HW2Readiness
      project={project} readiness={data.readinessLedger} source={source}
      onAnswer={() => { onUpdate({ stage: "answer" }); onJumpStage("answer"); }}
      onImprove={() => onJumpStage("resolve")}
    />;
  }
  if (stage === "answer") {
    return <HW2Answer
      project={project} source={source} chartData={data.chartData}
      onJumpToResolve={() => { onUpdate({ stage: "resolve" }); onJumpStage("resolve"); }}
      onExportReport={() => alert("Audit report export — Markdown verdict + contracts + lineage + freshness.")}
    />;
  }
  return null;
}

function buildBlankQuestionFromProposed(pq) {
  const baseContracts = [
    { id: "cols_locked",       label: "All referenced columns locked + lineage traced", pass: false, note: "to be checked after Generate" },
    { id: "no_blocking_gaps",  label: "No blocking gap on this question",               pass: false, note: "Resolve items pending" },
    { id: "structural_int",    label: "Structural integrity on join path",              pass: true,  note: "checked on this scope" },
    { id: "no_misleading",     label: "No unresolved misleading finding in lineage",    pass: true,  note: "—" },
    { id: "def_consistency",   label: "Definition consistency / traceable to source",   pass: false, note: "to be confirmed" },
    { id: "insight_confident", label: "Insight passes confidence bar (sample, σ)",      pass: pq.answerable === true, note: pq.answerable === true ? "sufficient sample" : "needs verification" },
  ];
  return {
    id: pq.id, title: pq.title,
    state: pq.answerable === false ? "cannot_answer" : "draft",
    cannotAnswerReason: pq.answerable === false ? pq.reason : undefined,
    insightConfidence: pq.answerable === true ? { value: 0.85, label: "High", basis: "auto-estimated" } : { value: 0.3, label: "Low", basis: pq.reason },
    sql: null, chartType: null, vouched: pq.neededColumns || [],
    contracts: baseContracts,
  };
}

function truncate(s, n) { return s.length > n ? s.slice(0, n - 1) + "…" : s; }

// ─── Tweaks ─────────────────────────────────────────────────────────────────
const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "showAdvancedConfidence": true
}/*EDITMODE-END*/;

function Hw2Tweaks({ t, onClose }) {
  return (
    <TweaksPanel title="Tweaks" onClose={onClose}>
      <TweakSection title="About this prototype">
        <div style={{ font: "400 12px 'DM Sans'", color: HW2_COLOR.muted, lineHeight: 1.55 }}>
          Open <strong>Reduce patient wait times</strong> to see the live workflow with one
          certified answer, one Draft, one demoted (drift!) and one honest "can&rsquo;t answer."
          The project banner shows the continuous-certification call-out.
        </div>
      </TweakSection>
    </TweaksPanel>
  );
}

// Mount
const root = ReactDOM.createRoot(document.getElementById("root"));
root.render(<HW2App />);
