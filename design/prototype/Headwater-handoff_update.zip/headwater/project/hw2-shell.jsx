// Headwater 2 — workspace shell.
//
// New surface for continuous certification:
//   • Each project row in the left rail shows a "Re-verify N" pill when a
//     drift event has revoked a previously-certified answer.
//   • The project banner shows the project's READOUT — % of blocking evidence
//     cleared across asked questions — and an inline re-verify call-out when
//     a drift event is pending.

function HW2Shell({
  source, sources, projects, route, onRoute, project, stage, onJumpStage,
  onConnectSource, onNewProject, children,
}) {
  const projectReadout = project ? window.HW2.computeProjectReadout(project) : null;

  return (
    <div style={{
      height: "100vh", display: "flex", flexDirection: "column",
      background: HW2_COLOR.paper, color: HW2_COLOR.ink,
      fontFamily: "'DM Sans', sans-serif", overflow: "hidden",
    }}>
      {/* Top bar */}
      <header style={{
        height: 48, flexShrink: 0,
        display: "flex", alignItems: "center", justifyContent: "space-between",
        padding: "0 18px",
        background: "rgba(250, 249, 246, 0.85)",
        backdropFilter: "saturate(140%) blur(8px)",
        borderBottom: `1px solid ${HW2_COLOR.rule}`,
        zIndex: 10,
      }}>
        <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
          <span style={{
            width: 16, height: 16, borderRadius: 4,
            background: `linear-gradient(135deg, ${HW2_COLOR.blue}, #4980f0)`,
          }} />
          <span style={{ font: "700 14px 'DM Sans'", letterSpacing: "-0.02em" }}>Headwater</span>
          <span style={{ font: "500 11px 'DM Mono'", color: HW2_COLOR.faint, marginLeft: 2 }}>v2</span>
        </div>
        <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
          <button style={{
            appearance: "none", background: "#fff", cursor: "pointer",
            border: `1px solid ${HW2_COLOR.rule2}`, borderRadius: 999,
            padding: "5px 12px", font: "500 12px 'DM Sans'", color: HW2_COLOR.ink,
            display: "inline-flex", alignItems: "center", gap: 6,
          }}>
            <span style={{ width: 18, height: 18, borderRadius: "50%", background: HW2_COLOR.chip, display: "grid", placeItems: "center", color: HW2_COLOR.muted, font: "600 10px 'DM Sans'" }}>N</span>
            Nupul
          </button>
        </div>
      </header>

      {/* Body: rail + main */}
      <div style={{ flex: 1, display: "flex", overflow: "hidden", minHeight: 0 }}>
        <HW2Rail
          source={source} sources={sources}
          projects={projects} route={route} onRoute={onRoute}
          onConnectSource={onConnectSource} onNewProject={onNewProject}
        />
        <main style={{ flex: 1, overflowY: "auto", background: HW2_COLOR.paper, minWidth: 0 }}>
          {project ? (
            <div>
              <ProjectBanner project={project} stage={stage}
                onJumpStage={onJumpStage}
                projectReadout={projectReadout} />
              <div>{children}</div>
            </div>
          ) : children}
        </main>
      </div>
    </div>
  );
}

// ─── Left rail ───────────────────────────────────────────────────────────────
function HW2Rail({ source, sources, projects, route, onRoute, onConnectSource, onNewProject }) {
  const reVerifyCount = (p) => (p.driftSinceLastVisit ? p.driftSinceLastVisit.affectedQuestionIds.length : 0);

  return (
    <aside style={{
      width: 248, flexShrink: 0,
      background: "#f3f1ea",
      borderRight: `1px solid ${HW2_COLOR.rule}`,
      display: "flex", flexDirection: "column",
      overflowY: "auto",
    }}>
      {/* Source switcher */}
      <div style={{ padding: "16px 14px 8px" }}>
        <div style={{ font: "600 10px 'DM Sans'", color: HW2_COLOR.faint, letterSpacing: "0.08em", textTransform: "uppercase", marginBottom: 6, padding: "0 4px" }}>
          Source
        </div>
        <button onClick={() => onRoute({ kind: "catalog" })} style={{
          appearance: "none", cursor: "pointer", width: "100%",
          background: "#fff", border: `1px solid ${HW2_COLOR.rule2}`, borderRadius: 8,
          padding: "8px 10px", textAlign: "left",
          display: "flex", alignItems: "center", gap: 8,
          fontFamily: "'DM Sans', sans-serif",
        }}>
          <span style={{ width: 6, height: 6, borderRadius: "50%", background: HW2_COLOR.good }} />
          <span style={{ flex: 1, minWidth: 0 }}>
            <div style={{ font: "600 13px 'DM Sans'", color: HW2_COLOR.ink, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
              {source.name}
            </div>
            <div style={{ font: "500 10px 'DM Mono'", color: HW2_COLOR.muted, marginTop: 1 }}>
              {source.kind} · profiled {source.profiledAt.split(" ")[0]}
            </div>
          </span>
        </button>
        <button onClick={onConnectSource} style={{
          appearance: "none", cursor: "pointer", width: "100%",
          background: "transparent", border: "none",
          padding: "6px 4px", textAlign: "left", marginTop: 4,
          font: "500 12px 'DM Sans'", color: HW2_COLOR.muted,
        }}>
          + Connect source
          <span style={{ marginLeft: 6, font: "400 10px 'DM Mono'", color: HW2_COLOR.faint }}>
            ({sources.length}/{window.HW2.sourceLimits.maxSources})
          </span>
        </button>
      </div>

      <Divider />

      {/* Workspace tools */}
      <RailSection label="Workspace">
        <RailItem
          active={route.kind === "catalog"}
          onClick={() => onRoute({ kind: "catalog" })}
          icon={<TableIcon />} label="Catalog"
          hint={`${source.schemas.length} schemas`} />
        <RailItem
          active={route.kind === "query"}
          onClick={() => onRoute({ kind: "query" })}
          icon={<QueryIcon />} label="Query"
          hint="SQL console" />
      </RailSection>

      <Divider />

      {/* Projects */}
      <RailSection label="Projects" action={
        <button onClick={onNewProject} title="New project" style={{
          appearance: "none", background: "transparent", border: "none", cursor: "pointer",
          padding: "0 2px", color: HW2_COLOR.muted, font: "600 14px 'DM Sans'",
          lineHeight: 1,
        }}>+</button>
      }>
        {projects.length === 0 && (
          <div style={{ padding: "6px 12px", font: "400 12px 'DM Sans'", color: HW2_COLOR.faint }}>
            No projects yet.
          </div>
        )}
        {projects.map(p => {
          const ro = window.HW2.computeProjectReadout(p);
          const driftN = reVerifyCount(p);
          return (
            <RailItem
              key={p.id}
              active={route.kind === "project" && route.projectId === p.id}
              onClick={() => onRoute({ kind: "project", projectId: p.id, stage: p.stage })}
              icon={<HW2ReadinessRing value={ro.pct} certified={ro.certifiedCount === ro.total && ro.total > 0 && driftN === 0} demoted={driftN > 0} size={18} stroke={2.5} showLabel={false} animate={false} />}
              label={p.title}
              hint={
                driftN > 0
                  ? <span style={{ color: HW2_COLOR.bad, font: "600 10.5px 'DM Sans'" }}>Re-verify {driftN}</span>
                  : `${p.questions?.length || 0} q · ${ro.certifiedCount}/${ro.total} cert.`
              }
            />
          );
        })}
        <div style={{ padding: "6px 12px 0", font: "400 10px 'DM Mono'", color: HW2_COLOR.faint }}>
          {projects.length} / {window.HW2.sourceLimits.maxProjectsPerSource} per source
        </div>
      </RailSection>

      <div style={{ flex: 1 }} />

      {/* Footer tip */}
      <div style={{ padding: "12px 14px", borderTop: `1px solid ${HW2_COLOR.rule}` }}>
        <div style={{ font: "400 11px 'DM Sans'", color: HW2_COLOR.faint, lineHeight: 1.5 }}>
          Catalog & Query are power tools. Projects are the guided workflow.
        </div>
      </div>
    </aside>
  );
}

function RailSection({ label, action, children }) {
  return (
    <div style={{ padding: "10px 8px 6px" }}>
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", padding: "0 8px", marginBottom: 4 }}>
        <span style={{ font: "600 10px 'DM Sans'", color: HW2_COLOR.faint, letterSpacing: "0.08em", textTransform: "uppercase" }}>{label}</span>
        {action}
      </div>
      <div style={{ display: "grid", gap: 1 }}>{children}</div>
    </div>
  );
}

function RailItem({ active, onClick, icon, label, hint }) {
  return (
    <button onClick={onClick} style={{
      appearance: "none", cursor: "pointer", width: "100%",
      background: active ? "#fff" : "transparent",
      border: active ? `1px solid ${HW2_COLOR.rule2}` : "1px solid transparent",
      borderRadius: 7, padding: "8px 9px", textAlign: "left",
      display: "flex", alignItems: "center", gap: 9,
      fontFamily: "'DM Sans', sans-serif",
      boxShadow: active ? "0 1px 0 rgba(20,20,30,0.02)" : "none",
    }}>
      <span style={{ width: 20, height: 20, display: "inline-flex", alignItems: "center", justifyContent: "center", color: active ? HW2_COLOR.ink : HW2_COLOR.muted, flexShrink: 0 }}>{icon}</span>
      <span style={{ flex: 1, minWidth: 0 }}>
        <div style={{ font: `${active ? 600 : 500} 13px 'DM Sans'`, color: active ? HW2_COLOR.ink : HW2_COLOR.ink2, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{label}</div>
        {hint != null && <div style={{ font: "400 10.5px 'DM Sans'", color: HW2_COLOR.muted, marginTop: 1, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{hint}</div>}
      </span>
    </button>
  );
}

function Divider() { return <div style={{ height: 1, background: HW2_COLOR.rule, margin: "4px 14px" }} />; }

// ─── Project banner ──────────────────────────────────────────────────────────
function ProjectBanner({ project, stage, onJumpStage, projectReadout }) {
  const drift = project.driftSinceLastVisit;
  const allCertified = projectReadout.total > 0 && projectReadout.certifiedCount === projectReadout.total && !drift;
  const stageBadges = drift ? { resolve: { tone: "bad", label: "Re-verify" } } : null;

  return (
    <section style={{
      padding: "20px 32px 14px",
      background: HW2_COLOR.paper,
      borderBottom: `1px solid ${HW2_COLOR.rule}`,
      position: "sticky", top: 0, zIndex: 5,
    }}>
      <div style={{ display: "flex", alignItems: "center", gap: 22, marginBottom: 14 }}>
        <HW2ReadinessRing
          value={projectReadout.pct}
          certified={allCertified}
          demoted={!!drift}
          size={56} stroke={5} showLabel={false} />
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 4, flexWrap: "wrap" }}>
            <span style={{ font: "600 10px 'DM Sans'", color: HW2_COLOR.muted, letterSpacing: "0.07em", textTransform: "uppercase" }}>Project goal</span>
            <span style={{ font: "500 11px 'DM Mono'", color: HW2_COLOR.muted }}>
              {projectReadout.certifiedCount}/{projectReadout.total} certified
              {projectReadout.total > 0 && <span style={{ color: HW2_COLOR.faint }}> · {projectReadout.pct}% evidence cleared</span>}
            </span>
          </div>
          <h1 style={{
            font: "600 21px 'DM Sans'", letterSpacing: "-0.02em",
            color: HW2_COLOR.ink, lineHeight: 1.25,
          }}>{project.goal || project.title}</h1>
        </div>
        <div style={{ display: "flex", flexDirection: "column", alignItems: "flex-end", gap: 4 }}>
          <span style={{ font: "500 11px 'DM Mono'", color: HW2_COLOR.faint }}>
            {project.selectedTables.length} tables
          </span>
          <span style={{ font: "400 11px 'DM Sans'", color: HW2_COLOR.muted }}>
            {project.lastTouched}
          </span>
        </div>
      </div>

      {/* Drift call-out — the continuous-certification moment */}
      {drift && (
        <div style={{
          padding: "10px 14px", marginBottom: 14, borderRadius: 10,
          background: HW2_COLOR.badSoft, border: `1px solid ${HW2_COLOR.bad}33`,
          display: "flex", alignItems: "center", gap: 12,
        }}>
          <span style={{
            width: 24, height: 24, borderRadius: "50%", background: HW2_COLOR.bad,
            color: "#fff", display: "grid", placeItems: "center", flexShrink: 0,
            font: "700 12px 'DM Sans'",
          }}>!</span>
          <div style={{ flex: 1, lineHeight: 1.45 }}>
            <div style={{ font: "600 13px 'DM Sans'", color: HW2_COLOR.bad }}>
              {drift.affectedQuestionIds.length} certified answer{drift.affectedQuestionIds.length === 1 ? "" : "s"} need re-verification · {drift.detectedAt}
            </div>
            <div style={{ font: "400 12px 'DM Sans'", color: HW2_COLOR.ink2, marginTop: 2 }}>
              {drift.reason}
            </div>
          </div>
          <HW2Btn size="sm" onClick={() => onJumpStage("resolve")}>Re-verify →</HW2Btn>
        </div>
      )}

      <HW2Stepper current={stage} onJump={onJumpStage} badges={stageBadges} />
    </section>
  );
}

// ─── Tiny icons ──────────────────────────────────────────────────────────────
function TableIcon() {
  return (
    <svg width="14" height="14" viewBox="0 0 16 16" fill="none">
      <rect x="2" y="3" width="12" height="10" rx="1.2" stroke="currentColor" strokeWidth="1.3" />
      <line x1="2" y1="6.5" x2="14" y2="6.5" stroke="currentColor" strokeWidth="1.3" />
      <line x1="6" y1="6.5" x2="6" y2="13" stroke="currentColor" strokeWidth="1.3" />
    </svg>
  );
}
function QueryIcon() {
  return (
    <svg width="14" height="14" viewBox="0 0 16 16" fill="none">
      <path d="M3 5l3 3-3 3" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round" />
      <line x1="8.5" y1="11.2" x2="13" y2="11.2" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" />
    </svg>
  );
}

Object.assign(window, { HW2Shell, ProjectBanner });
