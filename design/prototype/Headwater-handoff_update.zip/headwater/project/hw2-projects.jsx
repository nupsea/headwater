// Headwater 2 — Frame stage (INVERTED).
//
// The user supplies:  goal + (optional) decision/metric/horizon + scope (tables).
// They do NOT enter questions. Questions are proposed by the engine after
// Generate, in the Understand step.

function HW2Frame({ project, source, onGenerate }) {
  const [goal, setGoal]                  = React.useState(project.goal || "");
  const [decision, setDecision]          = React.useState(project.decision || "");
  const [metric, setMetric]              = React.useState(project.metric || "");
  const [horizon, setHorizon]            = React.useState(project.horizon || "");
  const [advanced, setAdvanced]          = React.useState(false);
  const [selected, setSelected]          = React.useState(
    () => new Set(project.selectedTables || preselectedDefault(source))
  );
  const [showTablePicker, setShowPicker] = React.useState(false);

  const ready = goal.trim().length >= 6 && selected.size > 0;

  const toggleTable = (fqn) => {
    const next = new Set(selected);
    next.has(fqn) ? next.delete(fqn) : next.add(fqn);
    setSelected(next);
  };

  return (
    <div style={{ maxWidth: 800, margin: "0 auto", padding: "32px 32px 80px" }}>
      <span style={{
        font: "600 11px 'DM Sans'", color: HW2_COLOR.blue,
        letterSpacing: "0.08em", textTransform: "uppercase",
      }}>Step 1 of 5 · Frame</span>
      <h2 style={{
        font: "600 26px 'DM Sans'", letterSpacing: "-0.02em",
        color: HW2_COLOR.ink, lineHeight: 1.25, marginTop: 8, marginBottom: 6,
      }}>What goal are we serving?</h2>
      <p style={{ font: "400 14px 'DM Sans'", color: HW2_COLOR.muted, marginBottom: 24, lineHeight: 1.55 }}>
        State a goal and a scope. You don&rsquo;t need to know the questions yet —
        <strong style={{ color: HW2_COLOR.ink2 }}> Headwater will propose the questions this data can credibly answer </strong>
        on the next step, and flag the ones it can&rsquo;t.
      </p>

      {/* Goal */}
      <label style={{ font: "600 12px 'DM Sans'", color: HW2_COLOR.muted, display: "block", marginBottom: 8 }}>
        The goal
      </label>
      <textarea
        value={goal} onChange={(e) => setGoal(e.target.value)}
        placeholder="e.g. Reduce patient wait time before imaging across modalities"
        rows={2}
        style={{
          width: "100%", resize: "vertical", display: "block",
          padding: "12px 16px",
          background: "#fff", border: `1px solid ${HW2_COLOR.rule2}`, borderRadius: 10,
          font: "500 16px 'DM Sans'", color: HW2_COLOR.ink, lineHeight: 1.4,
          fontFamily: "'DM Sans', sans-serif", outline: "none",
        }}
        onFocus={(e) => e.currentTarget.style.borderColor = HW2_COLOR.blue}
        onBlur={(e) => e.currentTarget.style.borderColor = HW2_COLOR.rule2}
      />

      <button onClick={() => setAdvanced(v => !v)} style={{
        appearance: "none", background: "transparent", border: "none", cursor: "pointer",
        marginTop: 14, padding: 0, color: HW2_COLOR.muted,
        font: "500 13px 'DM Sans'", display: "inline-flex", alignItems: "center", gap: 6,
        fontFamily: "'DM Sans', sans-serif",
      }}>
        <span style={{ font: "500 11px 'DM Mono'", color: HW2_COLOR.faint }}>{advanced ? "▼" : "▶"}</span>
        Add detail (optional): decision · target metric · time horizon
      </button>
      {advanced && (
        <div style={{ marginTop: 14, display: "grid", gap: 12 }}>
          <Field label="Decision you’re making" value={decision} onChange={setDecision} placeholder="e.g. Where to add staff or change process" />
          <Field label="Target metric"           value={metric}   onChange={setMetric}   placeholder="e.g. Mean wait from arrival to room"     />
          <Field label="Time horizon"            value={horizon}  onChange={setHorizon}  placeholder="e.g. Next quarter"                       />
        </div>
      )}

      {/* Scope */}
      <div style={{ marginTop: 32 }}>
        <div style={{ display: "flex", alignItems: "baseline", justifyContent: "space-between", marginBottom: 10 }}>
          <label style={{ font: "600 12px 'DM Sans'", color: HW2_COLOR.muted }}>
            Data scope · {selected.size} table{selected.size === 1 ? "" : "s"} from {source.name}
          </label>
          <button onClick={() => setShowPicker(v => !v)} style={anchorStyle}>
            {showTablePicker ? "Hide" : "Edit"} table picks
          </button>
        </div>

        {!showTablePicker ? (
          <div style={{ display: "flex", flexWrap: "wrap", gap: 6 }}>
            {[...selected].map(fqn => (
              <HW2Chip key={fqn} mono tone="blue">{fqn}</HW2Chip>
            ))}
            {selected.size === 0 && (
              <button onClick={() => setShowPicker(true)} style={{
                appearance: "none", cursor: "pointer", background: HW2_COLOR.chip,
                border: `1px dashed ${HW2_COLOR.rule2}`, borderRadius: 8,
                padding: "10px 14px", font: "500 13px 'DM Sans'", color: HW2_COLOR.muted,
              }}>
                + Pick tables from {source.name}
              </button>
            )}
          </div>
        ) : (
          <HW2Card padded={false}>
            <div style={{
              padding: "8px 14px", background: HW2_COLOR.paper,
              borderBottom: `1px solid ${HW2_COLOR.rule}`,
              font: "400 11px 'DM Sans'", color: HW2_COLOR.muted,
            }}>
              Pick across schemas. Profiles are reused — picking doesn&rsquo;t re-scan.
            </div>
            <div style={{ maxHeight: 320, overflowY: "auto", padding: "8px 6px" }}>
              {source.schemas.map(s => (
                <div key={s.name} style={{ marginBottom: 6 }}>
                  <div style={{ padding: "4px 12px", font: "600 11px 'DM Mono'", color: HW2_COLOR.muted }}>
                    {s.name}
                  </div>
                  {s.tables.map(t => {
                    const fqn = `${s.name}.${t.name}`;
                    const sel = selected.has(fqn);
                    return (
                      <label key={t.name} style={{
                        display: "flex", alignItems: "center", gap: 10,
                        padding: "5px 12px", cursor: "pointer",
                      }}>
                        <input type="checkbox" checked={sel} onChange={() => toggleTable(fqn)} style={{ accentColor: HW2_COLOR.blue }} />
                        <span style={{ font: "500 12px 'DM Mono'", color: HW2_COLOR.ink2, minWidth: 140 }}>{t.name}</span>
                        <span style={{ flex: 1, font: "400 12px 'DM Sans'", color: HW2_COLOR.muted, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
                          {t.description}
                        </span>
                        <span style={{ font: "400 11px 'DM Mono'", color: HW2_COLOR.faint }}>
                          {t.rows >= 1000 ? `${(t.rows/1000).toFixed(1)}k` : t.rows}
                        </span>
                      </label>
                    );
                  })}
                </div>
              ))}
            </div>
          </HW2Card>
        )}
      </div>

      {/* Optional resources hint */}
      <button style={{
        appearance: "none", background: "transparent", border: "none", cursor: "pointer",
        marginTop: 18, padding: 0, color: HW2_COLOR.muted,
        font: "500 13px 'DM Sans'", display: "inline-flex", alignItems: "center", gap: 6,
      }}>
        <span style={{ font: "500 11px 'DM Mono'", color: HW2_COLOR.faint }}>▶</span>
        Add context (optional): glossary · data dictionary · domain notes
      </button>

      {/* Action */}
      <div style={{ marginTop: 36, display: "flex", justifyContent: "space-between", alignItems: "center" }}>
        <span style={{ font: "400 12px 'DM Sans'", color: HW2_COLOR.faint }}>
          {!ready
            ? "Add a goal and pick at least one table."
            : "Headwater will read the scope and propose questions next."}
        </span>
        <HW2Btn kind="accent" size="lg" disabled={!ready}
          onClick={() => onGenerate({
            goal, decision, metric, horizon,
            selectedTables: [...selected],
          })}>
          Generate understanding →
        </HW2Btn>
      </div>
    </div>
  );
}

function Field({ label, value, onChange, placeholder }) {
  return (
    <div>
      <label style={{ font: "600 12px 'DM Sans'", color: HW2_COLOR.muted, display: "block", marginBottom: 6 }}>{label}</label>
      <input value={value} onChange={(e) => onChange(e.target.value)} placeholder={placeholder}
        style={{
          width: "100%", padding: "10px 14px",
          background: "#fff", border: `1px solid ${HW2_COLOR.rule2}`, borderRadius: 8,
          font: "400 14px 'DM Sans'", color: HW2_COLOR.ink,
          fontFamily: "'DM Sans', sans-serif", outline: "none",
        }} />
    </div>
  );
}

function preselectedDefault(source) {
  // Sensible default: every table currently flagged "selected: true" in the
  // shared catalog. Used for new projects on a source.
  const out = [];
  for (const s of source.schemas) {
    for (const t of s.tables) if (t.selected) out.push(`${s.name}.${t.name}`);
  }
  return out;
}

const anchorStyle = {
  appearance: "none", background: "transparent", border: "none", cursor: "pointer",
  padding: 0, color: HW2_COLOR.blue, font: "500 12px 'DM Sans'",
  fontFamily: "'DM Sans', sans-serif",
};

Object.assign(window, { HW2Frame });
