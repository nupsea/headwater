// Headwater 2 — fixture data.
//
// Aligned to the updated vision (2026-05-28):
//   • Project = goal + many questions; each question has its own readiness state.
//   • Certification is evidence-derived from a per-question contract set, never
//     from points / clicks.
//   • Frame is inverted: questions are PROPOSED by the engine after Generate.
//   • Continuous certification: a re-eval trigger ("drift event") can revoke a
//     previously-certified answer.
//   • One source per project; max 3 sources, max 5 projects per source.

window.HW2 = {
  // ──────────────────────────────────────────────────────────────────────────
  // Sources (the shared pool — profiles computed once, reused across projects)
  // ──────────────────────────────────────────────────────────────────────────
  sources: [
    {
      id: "hospital_pg",
      name: "hospital_db",
      kind: "Postgres",
      host: "pg.hospital.internal:5432",
      profiledAt: "2026-05-26 14:02",
      snapshot: "snap_2026-05-26",      // latest snapshot id
      schemas: [
        {
          name: "clinical",
          tables: [
            { name: "cases",     rows: 3193,  cols: 9, pk: "case_id",    fk: null,                selected: true,  description: "Patient visit / case header" },
            { name: "exams",     rows: 3507,  cols: 6, pk: "exam_id",    fk: "case_id → cases",  selected: true,  description: "Each scan / exam performed" },
            { name: "events",    rows: 27343, cols: 5, pk: "event_id",   fk: "case_id → cases",  selected: true,  description: "Workflow activity event log" },
            { name: "patients",  rows: 2814,  cols: 7, pk: "patient_id", fk: null,                selected: false, description: "Patient master" },
            { name: "diagnoses", rows: 4126,  cols: 5, pk: "dx_id",      fk: "case_id → cases",  selected: false, description: "Diagnoses per case" },
          ],
        },
        {
          name: "ops",
          tables: [
            { name: "rooms",      rows: 28,   cols: 5, pk: "room_id",      fk: null,                selected: true,  description: "Imaging rooms & modality" },
            { name: "equipment",  rows: 41,   cols: 6, pk: "equipment_id", fk: "room_id → rooms",  selected: false, description: "Scanners & devices" },
            { name: "schedules",  rows: 8924, cols: 6, pk: "schedule_id",  fk: null,                selected: false, description: "Booking schedule" },
          ],
        },
        {
          name: "staff",
          tables: [
            { name: "shifts",      rows: 1612, cols: 5, pk: "shift_id",  fk: null,                selected: true,  description: "Staff shift roster" },
            { name: "assignments", rows: 4203, cols: 4, pk: "assign_id", fk: "shift_id → shifts", selected: false, description: "Who worked which case" },
            { name: "staff",       rows: 184,  cols: 8, pk: "staff_id",  fk: null,                selected: false, description: "Staff master" },
          ],
        },
        {
          name: "billing",
          tables: [
            { name: "invoices", rows: 3015, cols: 7, pk: "invoice_id", fk: "case_id → cases", selected: false, description: "Invoices" },
            { name: "payments", rows: 4112, cols: 5, pk: "payment_id", fk: "invoice_id",      selected: false, description: "Payments" },
            { name: "payers",   rows: 38,   cols: 4, pk: "payer_id",   fk: null,                selected: false, description: "Insurance payers" },
          ],
        },
      ],
    },
  ],
  sourceLimits: { maxSources: 3, maxProjectsPerSource: 5 },

  catalogColumns: {
    "clinical.cases": [
      { name: "case_id",            type: "varchar",   pk: true,  semantic: "Identifier",  desc: "Unique visit id",                    locked: true,  nulls: 0,    lockedBy: "system / inferred" },
      { name: "patient_id",         type: "varchar",   pk: false, semantic: "Identifier",  desc: "FK → patients",                      locked: true,  nulls: 0,    lockedBy: "Nupul · 2026-05-26" },
      { name: "arrival_time",       type: "timestamp", pk: false, semantic: "Timestamp",   desc: "Patient check-in time",              locked: true,  nulls: 0,    lockedBy: "system / inferred" },
      { name: "patient_type",       type: "varchar",   pk: false, semantic: "Categorical", desc: "A/H/S/D — A=Ambulatory, S=Scheduled, D=Discharged; H unmapped", locked: false, nulls: 0,    lockedBy: null },
      { name: "total_wait_time",    type: "interval",  pk: false, semantic: "Duration",    desc: "Two formats present — see Resolve",  locked: false, nulls: 12,   lockedBy: null },
      { name: "scheduled_imaging", type: "boolean",    pk: false, semantic: "Flag",        desc: "Pre-scheduled vs walk-in",            locked: false, nulls: 4,    lockedBy: null },
      { name: "discharge_time",     type: "timestamp", pk: false, semantic: "Timestamp",   desc: "End of visit",                       locked: false, nulls: 38,   lockedBy: null },
      { name: "billing_status",     type: "varchar",   pk: false, semantic: "Categorical", desc: "Open/closed/disputed",                locked: false, nulls: 0,    lockedBy: null },
      { name: "case_notes",         type: "text",      pk: false, semantic: "Free text",   desc: "Free-form clinician notes",           locked: false, nulls: 1894, lockedBy: null },
    ],
    "clinical.exams": [
      { name: "exam_id",              type: "varchar",   pk: true,  semantic: "Identifier",  desc: "PK", locked: true, nulls: 0, lockedBy: "system / inferred" },
      { name: "case_id",              type: "varchar",   pk: false, semantic: "Identifier",  desc: "FK → cases", locked: true, nulls: 0, lockedBy: "system / inferred" },
      { name: "modality",             type: "varchar",   pk: false, semantic: "Categorical", desc: "MRI / CT / US / X-ray — only set on exam rows", locked: false, nulls: 412, lockedBy: null },
      { name: "scan_time_duration",   type: "interval",  pk: false, semantic: "Duration",    desc: "Active scan duration", locked: true, nulls: 0, lockedBy: "system / inferred" },
      { name: "tech_id",              type: "varchar",   pk: false, semantic: "Identifier",  desc: "FK → staff", locked: false, nulls: 23,  lockedBy: null },
      { name: "reading_radiologist",  type: "varchar",   pk: false, semantic: "Identifier",  desc: "FK → staff", locked: false, nulls: 102, lockedBy: null },
    ],
    "clinical.events": [
      { name: "event_id",         type: "varchar",   pk: true,  semantic: "Identifier",  desc: "PK", locked: true, nulls: 0, lockedBy: "system / inferred" },
      { name: "case_id",          type: "varchar",   pk: false, semantic: "Identifier",  desc: "FK → cases", locked: true, nulls: 0, lockedBy: "system / inferred" },
      { name: "activity",         type: "varchar",   pk: false, semantic: "Categorical", desc: "Workflow step name", locked: false, nulls: 0, lockedBy: null },
      { name: "timestamp_start",  type: "timestamp", pk: false, semantic: "Timestamp",   desc: "Step start", locked: true, nulls: 0, lockedBy: "system / inferred" },
      { name: "timestamp_end",    type: "timestamp", pk: false, semantic: "Timestamp",   desc: "Step end",   locked: false, nulls: 311, lockedBy: null },
    ],
    "ops.rooms": [
      { name: "room_id",         type: "varchar", pk: true,  semantic: "Identifier",  desc: "PK",            locked: true, nulls: 0, lockedBy: "system / inferred" },
      { name: "room_name",       type: "varchar", pk: false, semantic: "Label",       desc: "Display name",  locked: false, nulls: 0, lockedBy: null },
      { name: "modality",        type: "varchar", pk: false, semantic: "Categorical", desc: "MRI/CT/US",     locked: false, nulls: 0, lockedBy: null },
      { name: "capacity_per_hr", type: "int",     pk: false, semantic: "Quantity",    desc: "Throughput cap",locked: false, nulls: 2, lockedBy: null },
      { name: "is_active",       type: "boolean", pk: false, semantic: "Flag",        desc: "In service",    locked: false, nulls: 0, lockedBy: null },
    ],
    "staff.shifts": [
      { name: "shift_id",   type: "varchar",   pk: true,  semantic: "Identifier",  desc: "PK",                          locked: true, nulls: 0,  lockedBy: "system / inferred" },
      { name: "staff_id",   type: "varchar",   pk: false, semantic: "Identifier",  desc: "FK → staff",                  locked: false, nulls: 0,  lockedBy: null },
      { name: "shift_start",type: "timestamp", pk: false, semantic: "Timestamp",   desc: "Start",                       locked: false, nulls: 0,  lockedBy: null },
      { name: "shift_end",  type: "timestamp", pk: false, semantic: "Timestamp",   desc: "End",                         locked: false, nulls: 14, lockedBy: null },
      { name: "role",       type: "varchar",   pk: false, semantic: "Categorical", desc: "Tech/Radiologist/Reception",  locked: false, nulls: 0,  lockedBy: null },
    ],
  },

  sampleRows: {
    "clinical.cases": [
      { case_id: "C-39201", patient_id: "P-1024", arrival_time: "2026-05-21 08:14", patient_type: "A", total_wait_time: "00:24", scheduled_imaging: true,  billing_status: "open" },
      { case_id: "C-39202", patient_id: "P-2389", arrival_time: "2026-05-21 08:31", patient_type: "S", total_wait_time: "0 days 00:51:00", scheduled_imaging: false, billing_status: "open" },
      { case_id: "C-39203", patient_id: "P-0413", arrival_time: "2026-05-21 09:02", patient_type: "H", total_wait_time: "00:12", scheduled_imaging: true,  billing_status: "closed" },
      { case_id: "C-39204", patient_id: "P-5512", arrival_time: "2026-05-21 09:18", patient_type: "A", total_wait_time: "00:38", scheduled_imaging: true,  billing_status: "open" },
    ],
    "clinical.events": [
      { event_id: "E-101", case_id: "C-39201", activity: "Llegada_Pacientes_H",  timestamp_start: "2026-05-21 08:14", timestamp_end: "2026-05-21 08:15" },
      { event_id: "E-102", case_id: "C-39201", activity: "Recepcion",            timestamp_start: "2026-05-21 08:16", timestamp_end: "2026-05-21 08:21" },
      { event_id: "E-103", case_id: "C-39201", activity: "FrontOffice",          timestamp_start: "2026-05-21 08:21", timestamp_end: "2026-05-21 08:29" },
      { event_id: "E-104", case_id: "C-39201", activity: "AsignacionSala",       timestamp_start: "2026-05-21 08:30", timestamp_end: "2026-05-21 08:32" },
      { event_id: "E-105", case_id: "C-39201", activity: "ExaminacionExtra?",    timestamp_start: "2026-05-21 08:38", timestamp_end: "2026-05-21 08:54" },
    ],
  },

  connectors: [
    { id: "csv",       name: "CSV / files",   blurb: "Drop CSV or JSON files" },
    { id: "postgres",  name: "Postgres",      blurb: "Connect to a Postgres database" },
    { id: "snowflake", name: "Snowflake",     blurb: "Snowflake account" },
    { id: "bigquery",  name: "BigQuery",      blurb: "GCP service account" },
    { id: "duckdb",    name: "DuckDB",        blurb: "Local DuckDB file" },
    { id: "redshift",  name: "Redshift",      blurb: "AWS Redshift cluster" },
    { id: "mysql",     name: "MySQL",         blurb: "MySQL / MariaDB" },
    { id: "sqlite",    name: "SQLite",        blurb: "SQLite file" },
  ],

  // ──────────────────────────────────────────────────────────────────────────
  // Projects — goal + many questions; each question carries its own evidence
  // contracts (the SOURCE OF TRUTH for certification — no progress points).
  // ──────────────────────────────────────────────────────────────────────────
  projects: [
    {
      id: "wait_times",
      title: "Reduce patient wait times",
      goal: "Reduce patient wait time before imaging across modalities",
      sourceId: "hospital_pg",
      selectedTables: ["clinical.cases", "clinical.exams", "clinical.events", "staff.shifts", "ops.rooms"],
      stage: "answer",
      lastTouched: "2 hours ago",
      // Continuous certification: a drift event on this snapshot revoked one
      // previously-certified answer (see q1).
      driftSinceLastVisit: {
        detectedAt: "Today · 09:42",
        reason: "events.activity gained a new label 'CheckInExpress' — vocabulary changed",
        affectedQuestionIds: ["q1"],
      },
      questions: [
        // q1 — was Certified, now demoted by drift. Use as the "continuous cert" demo.
        {
          id: "q1",
          title: "When is wait time worst across the day?",
          state: "demoted",                                    // certified|draft|cannot_answer|demoted
          certifiedAt: "2026-05-26",
          demotedReason: "Source drifted: a new activity label 'CheckInExpress' appeared since certification. The wait window may include or exclude it.",
          insightConfidence: { value: 0.92, label: "High", basis: "n = 3,193 visits · 7 days · σ stable" },
          sql:
`SELECT EXTRACT(HOUR FROM arrival_time) AS hour,
       AVG(total_wait_time)             AS avg_wait,
       COUNT(*)                         AS visits
FROM   clinical.cases
GROUP  BY 1
ORDER  BY 1;`,
          chartType: "line",
          vouched: ["cases.arrival_time", "cases.total_wait_time"],
          // Evidence contracts: every fact that must hold for certification.
          contracts: [
            { id: "cols_locked",       label: "All referenced columns locked + lineage traced", pass: true,  note: "2 columns, both locked" },
            { id: "no_blocking_gaps",  label: "No blocking gap on this question",               pass: true,  note: "none" },
            { id: "structural_int",    label: "Structural integrity on join path",              pass: true,  note: "no joins" },
            { id: "no_misleading",     label: "No unresolved misleading finding in lineage",    pass: false, note: "'CheckInExpress' is unmapped — vocab drift" },
            { id: "def_consistency",   label: "Definition consistency / traceable to source",   pass: true,  note: "single metric, one source" },
            { id: "insight_confident", label: "Insight passes confidence bar (sample, σ)",      pass: true,  note: "n=3193, low variance" },
          ],
        },
        // q2 — Draft because a Resolve gap is open.
        {
          id: "q2",
          title: "Which patient_type has the longest wait?",
          state: "draft",
          insightConfidence: { value: 0.81, label: "Medium-high", basis: "n = 3,193 across 4 segments" },
          sql:
`SELECT patient_type,
       AVG(total_wait_time) AS avg_wait,
       COUNT(*)             AS visits
FROM   clinical.cases
GROUP  BY 1
ORDER  BY 2 DESC;`,
          chartType: "bar",
          vouched: ["cases.patient_type", "cases.total_wait_time"],
          contracts: [
            { id: "cols_locked",       label: "All referenced columns locked + lineage traced", pass: false, note: "cases.patient_type not locked — meaning of code 'H' unmapped" },
            { id: "no_blocking_gaps",  label: "No blocking gap on this question",               pass: false, note: "Resolve card: patient_type meanings — 'H' is still un-mapped" },
            { id: "structural_int",    label: "Structural integrity on join path",              pass: true,  note: "no joins" },
            { id: "no_misleading",     label: "No unresolved misleading finding in lineage",    pass: true,  note: "—" },
            { id: "def_consistency",   label: "Definition consistency / traceable to source",   pass: false, note: "Two duration formats for total_wait_time — pick one" },
            { id: "insight_confident", label: "Insight passes confidence bar (sample, σ)",      pass: true,  note: "n=3193" },
          ],
        },
        // q3 — Certified.
        {
          id: "q3",
          title: "Which workflow step contributes most to wait?",
          state: "certified",
          certifiedAt: "2026-05-27",
          insightConfidence: { value: 0.94, label: "High", basis: "n = 27,343 events; effect size large" },
          sql:
`SELECT activity,
       AVG(timestamp_end - timestamp_start) AS avg_step_duration,
       COUNT(*) AS occurrences
FROM   clinical.events
WHERE  activity IN ('Recepcion','FrontOffice','BackOffice','AsignacionSala')
GROUP  BY 1
ORDER  BY 2 DESC;`,
          chartType: "bar",
          vouched: ["events.activity", "events.timestamp_start", "events.timestamp_end"],
          contracts: [
            { id: "cols_locked",       label: "All referenced columns locked + lineage traced", pass: true, note: "3 columns, all locked" },
            { id: "no_blocking_gaps",  label: "No blocking gap on this question",               pass: true, note: "registration boundary confirmed — FrontOffice" },
            { id: "structural_int",    label: "Structural integrity on join path",              pass: true, note: "single table" },
            { id: "no_misleading",     label: "No unresolved misleading finding in lineage",    pass: true, note: "—" },
            { id: "def_consistency",   label: "Definition consistency / traceable to source",   pass: true, note: "step duration single definition" },
            { id: "insight_confident", label: "Insight passes confidence bar (sample, σ)",      pass: true, note: "n=27,343" },
          ],
        },
        // q4 — Cannot answer (the hero negative).
        {
          id: "q4",
          title: "Has wait time changed week-over-week?",
          state: "cannot_answer",
          cannotAnswerReason: "Only 7 days of history exist. Week-over-week needs at least 14 days; 4–8 weeks recommended for any seasonal signal.",
          cannotAnswerHint: "Source has data only from 2026-05-20 to 2026-05-26. Re-ask after the source has accumulated ≥ 2 weeks.",
          insightConfidence: { value: 0.18, label: "Low", basis: "n_periods = 1; cannot compute change" },
          sql: null, chartType: null, vouched: [],
          contracts: [
            { id: "cols_locked",       label: "All referenced columns locked + lineage traced", pass: true,  note: "—" },
            { id: "no_blocking_gaps",  label: "No blocking gap on this question",               pass: true,  note: "—" },
            { id: "structural_int",    label: "Structural integrity on join path",              pass: true,  note: "—" },
            { id: "no_misleading",     label: "No unresolved misleading finding in lineage",    pass: true,  note: "—" },
            { id: "def_consistency",   label: "Definition consistency / traceable to source",   pass: true,  note: "—" },
            { id: "insight_confident", label: "Insight passes confidence bar (sample, σ)",      pass: false, note: "1 period of data; cannot certify a comparison" },
          ],
        },
      ],
      // Proposed-but-rejected questions (kept so the user can re-add)
      proposedNotAnswerable: [
        { id: "qp1", title: "Which staff member is the bottleneck?", reason: "staff.assignments isn't in the selected scope; no link from event to staff" },
      ],
    },
    {
      id: "utilization",
      title: "Maximize device utilization",
      goal: "Maximize MRI / CT / Ultrasound throughput across rooms",
      sourceId: "hospital_pg",
      selectedTables: ["clinical.exams", "ops.rooms", "ops.equipment"],
      stage: "frame",
      lastTouched: "Just created",
      questions: [],
      proposedNotAnswerable: [],
    },
  ],

  // ──────────────────────────────────────────────────────────────────────────
  // Generated content: workflow, relevant cols, proposed questions, etc.
  // ──────────────────────────────────────────────────────────────────────────
  workflow: [
    { step: "Arrival",        zone: "before" },
    { step: "Recepcion",      zone: "registration" },
    { step: "FrontOffice",    zone: "registration" },
    { step: "BackOffice",     zone: "registration" },
    { step: "AsignacionSala", zone: "registration" },
    { step: "Wait",           zone: "after" },
    { step: "Exam",           zone: "after" },
  ],

  relevant: [
    { table: "cases",  col: "arrival_time",    reason: "Start of wait window" },
    { table: "cases",  col: "total_wait_time", reason: "Target metric" },
    { table: "cases",  col: "patient_type",    reason: "Segmentation driver" },
    { table: "events", col: "activity",        reason: "Defines workflow step" },
    { table: "events", col: "timestamp_start", reason: "Step duration" },
    { table: "events", col: "timestamp_end",   reason: "Step duration" },
    { table: "shifts", col: "shift_start",     reason: "Staff coverage at arrival" },
  ],
  irrelevant: [
    { table: "exams",  col: "reading_radiologist", reason: "Post-registration" },
    { table: "cases",  col: "case_notes",          reason: "Free text" },
    { table: "cases",  col: "billing_status",      reason: "Not used by goal" },
    { table: "cases",  col: "scheduled_imaging",   reason: "Captured in another field" },
    { table: "cases",  col: "discharge_time",      reason: "Post-registration" },
  ],

  // ──────────────────────────────────────────────────────────────────────────
  // Proposed questions — the heart of the inverted Frame. Engine generates
  // these from the relevant slice, classifies each as answerable or not (and
  // why), and the user curates.
  // ──────────────────────────────────────────────────────────────────────────
  proposedQuestions: [
    {
      id: "pq_hour",
      title: "When is wait time worst across the day?",
      answerable: true,
      reason: "We have arrival_time and total_wait_time on every case.",
      neededColumns: ["cases.arrival_time", "cases.total_wait_time"],
    },
    {
      id: "pq_type",
      title: "Which patient_type waits longest?",
      answerable: "with_caveat",
      reason: "Computable, but patient_type code H is unmapped — segments will be labeled by raw code until you resolve it.",
      neededColumns: ["cases.patient_type", "cases.total_wait_time"],
    },
    {
      id: "pq_step",
      title: "Which workflow step contributes most to wait?",
      answerable: true,
      reason: "events.activity sequences are clean and consistent for the registration zone.",
      neededColumns: ["events.activity", "events.timestamp_start", "events.timestamp_end"],
    },
    {
      id: "pq_wow",
      title: "Has wait time changed week-over-week?",
      answerable: false,
      reason: "Only 7 days of history. Week-over-week needs ≥ 14 days; trend detection wants 4–8 weeks.",
      neededColumns: [],
    },
    {
      id: "pq_staff",
      title: "Is wait correlated with staff coverage?",
      answerable: "with_caveat",
      reason: "Possible via staff.shifts overlap with arrival_time — but accuracy depends on whether shifts cover all roles, which isn't clear from the data alone.",
      neededColumns: ["cases.arrival_time", "staff.shifts.shift_start", "staff.shifts.shift_end"],
    },
    {
      id: "pq_bottleneck",
      title: "Which staff member is the bottleneck?",
      answerable: false,
      reason: "staff.assignments isn't in your selected scope. No link from event to a specific staff member.",
      neededColumns: ["staff.assignments (not in scope)"],
    },
  ],

  // ──────────────────────────────────────────────────────────────────────────
  // Resolve cards — ranked by impact on the verdict, NOT by trustGain points.
  // Each card lists which contracts it clears (so progress is real).
  // The drift card is first so the continuous-cert moment is unmissable.
  // ──────────────────────────────────────────────────────────────────────────
  resolveCards: [
    {
      id: "vocab_drift",                                       // continuous-cert demo
      impact: "high", impactLabel: "High impact · NEW",
      why: "Auto-revoked Q1's certification — new label since cert",
      title: "New activity label 'CheckInExpress' — what is it?",
      body: "This label appeared in events.activity after Q1 was certified on 2026-05-26. Headwater revoked Q1's badge until you classify it.",
      kind: "binary",
      options: ["Maps to Recepcion (registration step)", "Is a separate, post-registration step"],
      suggested: "",
      gapHint: "Q1 stays Draft",
      clearsContracts: { questionId: "q1", contractIds: ["no_misleading"] },
      batchable: false,
      isDriftCard: true,
    },
    {
      id: "boundary",
      impact: "high", impactLabel: "High impact",
      why: "Defines your core metric",
      title: 'Where does "registration" end?',
      body: "The wait metric needs a boundary. The steps I see:",
      sequence: ["Arrival", "Recepcion", "FrontOffice", "BackOffice", "AsignacionSala"],
      prompt: "Registration is complete after:",
      kind: "choice",
      options: ["Recepcion", "FrontOffice", "BackOffice", "AsignacionSala"],
      suggested: "FrontOffice",
      gapHint: "Without a boundary the wait metric is undefined",
      clearsContracts: { questionId: "q3", contractIds: ["no_blocking_gaps"] },
      batchable: false,
    },
    {
      id: "patient_type",
      impact: "high", impactLabel: "High impact",
      why: "Affects how you segment results (and blocks Q2 certification)",
      title: "What do patient_type codes mean?",
      body: "Four codes in cases.patient_type. The data alone can't tell you what they mean.",
      kind: "mapping",
      mapping: [
        { code: "A", suggested: "Ambulatory", options: ["Ambulatory", "Admitted", "Appointment", "Acute"] },
        { code: "H", suggested: "",           options: ["Homecare", "Hospitalized", "Emergency", "Other"] },
        { code: "S", suggested: "Scheduled",  options: ["Scheduled", "Same-day", "Staff", "Self-pay"] },
        { code: "D", suggested: "Discharged", options: ["Discharged", "Direct", "Default", "Doctor referral"] },
      ],
      gapHint: "Segments will be labeled by raw code; Q2 stays Draft",
      clearsContracts: { questionId: "q2", contractIds: ["cols_locked", "no_blocking_gaps"] },
      batchable: false,
    },
    {
      id: "duration_format",
      impact: "med", impactLabel: "Medium impact · trivia",
      why: "Two formats prevent a single definition",
      title: "Two duration formats — pick one",
      body: 'cases.total_wait_time appears as both "00:10" and "0 days 00:22:00". Pick the canonical format.',
      kind: "binary",
      options: ["HH:MM (compact)", "ISO-ish '0 days HH:MM:SS'"],
      suggested: "HH:MM (compact)",
      gapHint: "Q2 def_consistency contract fails",
      clearsContracts: { questionId: "q2", contractIds: ["def_consistency"] },
      batchable: true,
    },
    {
      id: "vocab_us",
      impact: "low", impactLabel: "Low impact · trivia",
      why: "Reporting consistency",
      title: '"UltraSound" vs "US" — same thing?',
      body: "Two spellings in events.activity. Merging keeps counts consistent.",
      kind: "binary",
      options: ["Yes, merge into one", "No, they're different"],
      suggested: "Yes, merge into one",
      gapHint: "Counts split across two labels",
      clearsContracts: null,
      batchable: true,
    },
    {
      id: "modality_nulls",
      impact: "low", impactLabel: "Low impact · trivia",
      why: "Reporting clarity, not blocking any current question",
      title: "exams.modality is empty 88% of the time — missing or N/A?",
      body: "Modality is only set on exam rows. Either confirm 'N/A for non-exams' or flag as quality issue.",
      kind: "binary",
      options: ["Not-applicable for non-exam events", "Truly missing data"],
      suggested: "Not-applicable for non-exam events",
      gapHint: "Doesn't block — but defaults to flagging 24,070 events as low quality",
      clearsContracts: null,
      batchable: true,
    },
  ],

  // ──────────────────────────────────────────────────────────────────────────
  // Readiness — per-question. The buckets below describe the SHARED data
  // landscape; the per-question verdict is computed from contracts.
  // ──────────────────────────────────────────────────────────────────────────
  readinessLedger: {
    buckets: [
      { key: "have", label: "You have", tone: "good", items: [
        "7-day event log, 3,193 visits",
        "Arrival timestamp on every case",
        "Reconstructed workflow: Arrival → Recepcion → FrontOffice → AsignacionSala → Wait → Exam",
        "Two duration fields (one usable, one not — see Risky)",
      ] },
      { key: "trustworthy", label: "Trustworthy", tone: "good", items: [
        "case grain is clean (case_id unique, no nulls)",
        "case → exam → event joins verified (referential integrity 100%)",
        "Arrival times in monotonic UTC, no clock skew detected",
      ] },
      { key: "risky", label: "Risky — verify", tone: "warn", items: [
        'Two duration formats: "00:10" vs "0 days 00:22:00" — pick one',
        "Weekday pattern unusual (Sun/Thu high) — verify against hospital ops calendar",
        'Unusual spike on 2026-04-18 (3.2× median) — single-day anomaly',
      ] },
      { key: "missing", label: "Missing / gaps", tone: "muted", items: [
        'No explicit "registration complete" event — using FrontOffice as proxy',
        "patient_type meaning for code H still unmapped",
      ] },
      { key: "misleading", label: "Misleading", tone: "bad", items: [
        'events.activity \'ExaminacionExtra?\' contains a literal "?" — looks like a question, isn\'t',
        'activity "Llegada_Pacientes_H" mixes language and a code suffix — appears to mean "Arrival, Homecare"',
        'New label "CheckInExpress" appeared after Q1 was certified — unmapped',
      ] },
    ],
  },

  // Chart data per question
  chartData: {
    waitByHour: Array.from({ length: 24 }, (_, h) => {
      const base = 6
        + Math.max(0, 14 * Math.exp(-Math.pow((h - 10) / 3.2, 2)))
        + Math.max(0, 9  * Math.exp(-Math.pow((h - 15) / 2.4, 2)));
      return { hour: h, wait: Math.round(base * 10) / 10, visits: Math.round(40 + base * 7) };
    }),
    waitByPatientType: [
      { label: "A", value: 21, n: 1842 },
      { label: "H", value: 28, n: 612 },
      { label: "S", value: 14, n: 489 },
      { label: "D", value: 19, n: 250 },
    ],
    stepDurations: [
      { label: "FrontOffice",    value: 12 },
      { label: "Recepcion",      value: 7  },
      { label: "BackOffice",     value: 6  },
      { label: "AsignacionSala", value: 3  },
    ],
  },
};

// ─── Pure helpers (no React, available globally) ────────────────────────────
// Compute per-question readiness % from contracts (= % of contracts passing).
// THIS IS THE ONLY VALID READINESS NUMBER. There is no per-project trust score.
window.HW2.computeQuestionReadiness = function (q) {
  if (!q?.contracts || q.contracts.length === 0) return { pct: 0, passing: 0, total: 0 };
  const total   = q.contracts.length;
  const passing = q.contracts.filter(c => c.pass).length;
  return { pct: Math.round((passing / total) * 100), passing, total };
};
window.HW2.questionState = function (q) {
  // Authoritative state derivation. UI never sets state — it derives it.
  if (q.state === "demoted")        return "demoted";
  if (q.state === "cannot_answer")  return "cannot_answer";
  const allPass = (q.contracts || []).every(c => c.pass);
  return allPass ? "certified" : "draft";
};
// Project-level readout: % of "blocking evidence cleared" across all asked
// questions = mean of per-question readiness, excluding cannot_answer ones.
window.HW2.computeProjectReadout = function (project) {
  const askable = (project.questions || []).filter(q => q.state !== "cannot_answer");
  if (askable.length === 0) return { pct: 0, certifiedCount: 0, total: 0 };
  const sum = askable.reduce((a, q) => a + window.HW2.computeQuestionReadiness(q).pct, 0);
  const certifiedCount = askable.filter(q => window.HW2.questionState(q) === "certified").length;
  return { pct: Math.round(sum / askable.length), certifiedCount, total: askable.length };
};
