// Headwater 2 — Resolve. The anti-overload screen.
// One card at a time, ranked by impact. Confirm / I-don't-know / Skip.
// Each resolution nudges the trust ring up.

function HW2Resolve({ project, cards, onResolveOne, onAllDone }) {
  const [idx, setIdx]         = React.useState(project.resolved || 0);
  const [history, setHistory] = React.useState([]); // {id, choice}
  const [exitingDir, setExitingDir] = React.useState(0); // -1 left (skip), +1 right (confirm), 0 idle

  // Auto-jump to readiness once all 4 are answered
  React.useEffect(() => {
    if (history.length >= cards.length) {
      const t = setTimeout(onAllDone, 700);
      return () => clearTimeout(t);
    }
  }, [history.length]); // eslint-disable-line

  const current = cards[idx];
  const isDone  = !current;

  const advance = (choice, dir) => {
    if (!current) return;
    setExitingDir(dir);
    setTimeout(() => {
      setHistory(h => [...h, { id: current.id, choice }]);
      onResolveOne(current, choice);
      setIdx(i => i + 1);
      setExitingDir(0);
    }, 220);
  };

  // Keyboard nav
  React.useEffect(() => {
    const onKey = (e) => {
      if (e.key === "Enter" && current) advance("confirm", 1);
      if (e.key === "Escape" && current) advance("skip", -1);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [current]); // eslint-disable-line

  return (
    <div style={{ maxWidth: 880, margin: "0 auto", padding: "32px 32px 80px" }}>
      <div style={{ display: "flex", alignItems: "baseline", justifyContent: "space-between", marginBottom: 6 }}>
        <span style={{
          font: "600 11px 'DM Sans'", color: HW2_COLOR.blue,
          letterSpacing: "0.08em", textTransform: "uppercase",
        }}>Step 3 of 5 · Resolve</span>
        <span style={{ font: "500 12px 'DM Mono'", color: HW2_COLOR.muted }}>
          {Math.min(history.length + 1, cards.length)} of {cards.length}
        </span>
      </div>
      <h2 style={{
        font: "600 26px 'DM Sans'", letterSpacing: "-0.02em",
        color: HW2_COLOR.ink, lineHeight: 1.25, marginTop: 8, marginBottom: 4,
      }}>
        {isDone ? "All four resolved." : `${cards.length - history.length} things only you can know.`}
      </h2>
      <p style={{ font: "400 14px 'DM Sans'", color: HW2_COLOR.muted, marginBottom: 24, lineHeight: 1.5 }}>
        {isDone
          ? "Trust has settled. Heading to the readiness verdict…"
          : "Ranked by how much each one moves your verdict. We won't make these guesses for you."}
      </p>

      {/* Card stack */}
      <div style={{ position: "relative", minHeight: 380 }}>
        {/* Behind cards — peek of next */}
        {cards.slice(idx + 1, idx + 3).map((c, i) => (
          <div key={c.id} style={{
            position: "absolute", inset: 0, transform: `translateY(${(i + 1) * 8}px) scale(${1 - (i + 1) * 0.02})`,
            background: HW2_COLOR.surface, border: `1px solid ${HW2_COLOR.rule}`,
            borderRadius: 14, opacity: 0.6 - i * 0.2, zIndex: 0,
          }} />
        ))}

        {/* Active card */}
        {current && (
          <ResolveCard
            key={current.id}
            card={current}
            exitingDir={exitingDir}
            onConfirm={(choice) => advance({ kind: "confirm", value: choice }, 1)}
            onDontKnow={() => advance({ kind: "gap" }, -1)}
            onSkip={() => advance({ kind: "skip" }, -1)}
          />
        )}

        {isDone && (
          <div style={{
            position: "absolute", inset: 0, display: "grid", placeItems: "center",
            background: "#fff", border: `1px solid ${HW2_COLOR.rule}`, borderRadius: 14,
          }}>
            <div style={{ textAlign: "center" }}>
              <div style={{
                width: 56, height: 56, borderRadius: "50%",
                background: HW2_COLOR.goodSoft, display: "grid", placeItems: "center",
                margin: "0 auto 14px", color: HW2_COLOR.good,
                font: "600 24px 'DM Sans'",
              }}>✓</div>
              <div style={{ font: "600 16px 'DM Sans'", color: HW2_COLOR.ink }}>Resolution complete.</div>
              <div style={{ font: "400 13px 'DM Sans'", color: HW2_COLOR.muted, marginTop: 4 }}>
                Calculating readiness verdict…
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Up next preview */}
      {!isDone && cards.length - history.length > 1 && (
        <div style={{ marginTop: 24 }}>
          <div style={{
            font: "600 11px 'DM Sans'", color: HW2_COLOR.muted,
            letterSpacing: "0.06em", textTransform: "uppercase", marginBottom: 8,
          }}>Up next</div>
          <div style={{ display: "grid", gap: 6 }}>
            {cards.slice(idx + 1).map((c, i) => (
              <div key={c.id} style={{
                display: "flex", alignItems: "center", gap: 12,
                padding: "8px 12px", borderRadius: 8,
                font: "500 13px 'DM Sans'", color: HW2_COLOR.muted,
              }}>
                <span style={{ font: "500 11px 'DM Mono'", color: HW2_COLOR.faint, width: 22 }}>
                  {idx + i + 2}.
                </span>
                <span style={{ flex: 1 }}>{c.title}</span>
                <ImpactPill impact={c.impact}>{c.impact}</ImpactPill>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Keyboard hint */}
      {!isDone && (
        <div style={{
          marginTop: 28, font: "400 11px 'DM Sans'", color: HW2_COLOR.faint,
          textAlign: "center", display: "flex", justifyContent: "center", gap: 16,
        }}>
          <KbdHint k="↵">confirm</KbdHint>
          <KbdHint k="esc">mark gap</KbdHint>
          <span style={{ alignSelf: "center" }}>Non-blocking. Skipped items become gaps in the verdict.</span>
        </div>
      )}
    </div>
  );
}

function ResolveCard({ card, exitingDir, onConfirm, onDontKnow, onSkip }) {
  // Local state for each card type
  const [choice, setChoice] = React.useState(card.suggested || null);
  const [mapping, setMapping] = React.useState(() => {
    if (card.kind !== "mapping") return null;
    return Object.fromEntries(card.mapping.map(m => [m.code, m.suggested || ""]));
  });

  const ready = card.kind === "mapping" ? true : !!choice;
  const finalChoice = card.kind === "mapping" ? mapping : choice;

  return (
    <div style={{
      position: "relative", zIndex: 5,
      background: HW2_COLOR.surface,
      border: `1px solid ${HW2_COLOR.rule2}`, borderRadius: 14,
      padding: 28, boxShadow: "0 1px 0 rgba(20,20,30,0.02), 0 12px 32px rgba(20,20,30,0.05)",
      transition: "transform 220ms cubic-bezier(0.4,0,0.2,1), opacity 220ms",
      transform: exitingDir === 1  ? "translateX(60px) rotate(2deg)"
              : exitingDir === -1 ? "translateX(-60px) rotate(-2deg)"
              : "translateX(0)",
      opacity: exitingDir === 0 ? 1 : 0,
    }}>
      <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 14 }}>
        <ImpactPill impact={card.impact}>{card.impactLabel}</ImpactPill>
        <span style={{ font: "400 12px 'DM Sans'", color: HW2_COLOR.muted }}>· {card.why}</span>
      </div>
      <h3 style={{
        font: "600 20px 'DM Sans'", letterSpacing: "-0.015em",
        color: HW2_COLOR.ink, lineHeight: 1.3, marginBottom: 8,
      }}>{card.title}</h3>
      <p style={{ font: "400 14px 'DM Sans'", color: HW2_COLOR.ink2, lineHeight: 1.5, marginBottom: 18 }}>
        {card.body}
      </p>

      {/* Body by kind */}
      {card.kind === "choice" && (
        <>
          {/* Visual sequence */}
          <div style={{ display: "flex", alignItems: "center", gap: 6, flexWrap: "wrap", marginBottom: 18 }}>
            {card.sequence.map((s, i) => (
              <React.Fragment key={s}>
                <span style={{
                  padding: "4px 9px", borderRadius: 14,
                  background: HW2_COLOR.chip, color: HW2_COLOR.ink2,
                  font: "500 12px 'DM Mono'",
                }}>{s}</span>
                {i < card.sequence.length - 1 && <span style={{ color: HW2_COLOR.faint, font: "500 12px 'DM Mono'" }}>→</span>}
              </React.Fragment>
            ))}
          </div>
          <div style={{ font: "500 13px 'DM Sans'", color: HW2_COLOR.muted, marginBottom: 10 }}>
            {card.prompt}
          </div>
          <div style={{ display: "flex", flexWrap: "wrap", gap: 8 }}>
            {card.options.map(opt => {
              const sel = choice === opt;
              const sug = opt === card.suggested;
              return (
                <button key={opt} onClick={() => setChoice(opt)} style={{
                  appearance: "none", cursor: "pointer", padding: "10px 14px",
                  borderRadius: 10, border: `1.5px solid ${sel ? HW2_COLOR.blue : HW2_COLOR.rule2}`,
                  background: sel ? HW2_COLOR.blueSoft : "#fff",
                  font: "500 13px 'DM Sans'", color: sel ? HW2_COLOR.blue : HW2_COLOR.ink,
                  fontFamily: "'DM Sans', sans-serif",
                  display: "inline-flex", alignItems: "center", gap: 8,
                }}>
                  <span style={{
                    width: 14, height: 14, borderRadius: "50%",
                    border: `1.5px solid ${sel ? HW2_COLOR.blue : HW2_COLOR.rule2}`,
                    background: sel ? HW2_COLOR.blue : "transparent",
                    display: "inline-flex", alignItems: "center", justifyContent: "center",
                  }}>
                    {sel && <span style={{ width: 5, height: 5, borderRadius: "50%", background: "#fff" }} />}
                  </span>
                  {opt}
                  {sug && <span style={{ font: "500 10px 'DM Mono'", color: HW2_COLOR.muted }}>· best guess</span>}
                </button>
              );
            })}
          </div>
        </>
      )}

      {card.kind === "binary" && (
        <div style={{ display: "grid", gap: 8 }}>
          {card.options.map(opt => {
            const sel = choice === opt;
            const sug = opt === card.suggested;
            return (
              <button key={opt} onClick={() => setChoice(opt)} style={{
                appearance: "none", cursor: "pointer", textAlign: "left",
                padding: "12px 16px", borderRadius: 10,
                border: `1.5px solid ${sel ? HW2_COLOR.blue : HW2_COLOR.rule2}`,
                background: sel ? HW2_COLOR.blueSoft : "#fff",
                font: "500 13px 'DM Sans'", color: sel ? HW2_COLOR.blue : HW2_COLOR.ink,
                fontFamily: "'DM Sans', sans-serif",
                display: "flex", alignItems: "center", gap: 10,
              }}>
                <span style={{
                  width: 14, height: 14, borderRadius: "50%",
                  border: `1.5px solid ${sel ? HW2_COLOR.blue : HW2_COLOR.rule2}`,
                  background: sel ? HW2_COLOR.blue : "transparent",
                  display: "inline-flex", alignItems: "center", justifyContent: "center",
                }}>
                  {sel && <span style={{ width: 5, height: 5, borderRadius: "50%", background: "#fff" }} />}
                </span>
                <span style={{ flex: 1 }}>{opt}</span>
                {sug && <span style={{ font: "500 10px 'DM Mono'", color: HW2_COLOR.muted }}>· best guess</span>}
              </button>
            );
          })}
        </div>
      )}

      {card.kind === "mapping" && (
        <div style={{ display: "grid", gap: 8 }}>
          {card.mapping.map(m => (
            <div key={m.code} style={{
              display: "grid", gridTemplateColumns: "60px 1fr", alignItems: "center",
              gap: 12, padding: "10px 14px", borderRadius: 10,
              background: "#fff", border: `1px solid ${HW2_COLOR.rule2}`,
            }}>
              <span style={{
                font: "600 14px 'DM Mono'", color: HW2_COLOR.ink,
                padding: "4px 10px", background: HW2_COLOR.chip, borderRadius: 6,
                textAlign: "center",
              }}>{m.code}</span>
              <select
                value={mapping[m.code]}
                onChange={(e) => setMapping(p => ({ ...p, [m.code]: e.target.value }))}
                style={{
                  appearance: "none", background: "#fff",
                  border: `1px solid ${HW2_COLOR.rule2}`, borderRadius: 8,
                  padding: "8px 12px",
                  font: "500 13px 'DM Sans'", color: HW2_COLOR.ink,
                  fontFamily: "'DM Sans', sans-serif",
                  width: "100%", cursor: "pointer",
                }}>
                <option value="">— I don&rsquo;t know — mark as gap</option>
                {m.options.map(o => <option key={o} value={o}>{o}</option>)}
              </select>
            </div>
          ))}
        </div>
      )}

      {/* Footer actions */}
      <div style={{
        marginTop: 22, paddingTop: 18, borderTop: `1px solid ${HW2_COLOR.rule}`,
        display: "flex", alignItems: "center", justifyContent: "space-between", gap: 8,
      }}>
        <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
          <HW2Chip tone="muted" mono>+{card.trustGain}% trust</HW2Chip>
          <span style={{ font: "400 12px 'DM Sans'", color: HW2_COLOR.muted }}>
            if skipped: <span style={{ color: HW2_COLOR.ink2 }}>{card.gapHint}</span>
          </span>
        </div>
        <div style={{ display: "flex", gap: 8 }}>
          <HW2Btn onClick={onDontKnow}>I don&rsquo;t know — mark gap</HW2Btn>
          <HW2Btn kind="accent" onClick={() => onConfirm(finalChoice)} disabled={!ready}>
            Confirm →
          </HW2Btn>
        </div>
      </div>
    </div>
  );
}

function ImpactPill({ impact, children }) {
  const tones = {
    high: { bg: HW2_COLOR.badSoft, color: HW2_COLOR.bad },
    med:  { bg: HW2_COLOR.warnSoft, color: HW2_COLOR.warn },
    low:  { bg: HW2_COLOR.chip, color: HW2_COLOR.muted },
  }[impact] || { bg: HW2_COLOR.chip, color: HW2_COLOR.muted };
  return (
    <span style={{
      display: "inline-flex", alignItems: "center", gap: 4,
      padding: "3px 8px", borderRadius: 4,
      background: tones.bg, color: tones.color,
      font: "700 10px 'DM Sans'", letterSpacing: "0.06em", textTransform: "uppercase",
    }}>{children}</span>
  );
}

function KbdHint({ k, children }) {
  return (
    <span style={{ display: "inline-flex", alignItems: "center", gap: 6 }}>
      <span style={{
        font: "500 11px 'DM Mono'", color: HW2_COLOR.ink2,
        padding: "2px 6px", background: "#fff",
        border: `1px solid ${HW2_COLOR.rule2}`, borderRadius: 4,
      }}>{k}</span>
      <span>{children}</span>
    </span>
  );
}

Object.assign(window, { HW2Resolve });
