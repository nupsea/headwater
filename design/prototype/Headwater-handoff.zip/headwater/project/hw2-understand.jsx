// Headwater 2 — Generate (animated, no input needed) + Understand screens.

// ─── Generate ──────────────────────────────────────────────────────────────
// Transparent progress while H2 ingests, profiles, types, relates, scopes.
function HW2Generate({ project, source, onDone }) {
  const steps = [
    { key: "ingest",   label: "Ingested",        detail: source.tables.map(t => t.name).join(" · ") },
    { key: "profile",  label: "Profiled",       detail: "columns · stats · keys" },
    { key: "type",     label: "Typed columns",  detail: "timestamps · durations · codes · ids" },
    { key: "relate",   label: "Found structure", detail: "case → exams → events (event log)" },
    { key: "scope",    label: "Scoping to goal", detail: "evaluating column relevance" },
  ];
  const [i, setI] = React.useState(0);
  React.useEffect(() => {
    if (i >= steps.length) {
      const t = setTimeout(onDone, 600);
      return () => clearTimeout(t);
    }
    const t = setTimeout(() => setI(i + 1), 700);
    return () => clearTimeout(t);
  }, [i]); // eslint-disable-line

  return (
    <div style={{ maxWidth: 720, margin: "0 auto", padding: "80px 32px" }}>
      <span style={{
        font: "600 11px 'DM Sans'", color: HW2_COLOR.blue,
        letterSpacing: "0.08em", textTransform: "uppercase",
      }}>Generating understanding</span>
      <h2 style={{
        font: "600 26px 'DM Sans'", letterSpacing: "-0.02em",
        color: HW2_COLOR.ink, lineHeight: 1.25, marginTop: 8, marginBottom: 6,
      }}>Reading {source.name}.</h2>
      <p style={{ font: "400 14px 'DM Sans'", color: HW2_COLOR.muted, marginBottom: 32 }}>
        {source.tables.reduce((a, t) => a + t.rows, 0).toLocaleString()} rows across {source.tables.length} files. This runs on its own — no input needed.
      </p>

      <HW2Card>
        {steps.map((s, idx) => {
          const done   = idx <  i;
          const active = idx === i;
          const wait   = idx >  i;
          return (
            <div key={s.key} style={{
              display: "flex", alignItems: "center", gap: 14,
              padding: "10px 0",
              borderBottom: idx < steps.length - 1 ? `1px solid ${HW2_COLOR.rule}` : "none",
            }}>
              <span style={{
                width: 22, height: 22, borderRadius: "50%",
                display: "inline-flex", alignItems: "center", justifyContent: "center",
                background: done ? HW2_COLOR.good : active ? "#fff" : "#fff",
                border: active ? `2px solid ${HW2_COLOR.blue}`
                       : done ? "none"
                       : `1.5px solid ${HW2_COLOR.rule2}`,
                color: "#fff",
              }}>
                {done && <span style={{ font: "700 12px 'DM Sans'" }}>✓</span>}
                {active && <span style={{
                  width: 8, height: 8, borderRadius: "50%", background: HW2_COLOR.blue,
                  animation: "hw2-pulse 1s ease-in-out infinite",
                }} />}
              </span>
              <div style={{ flex: 1, opacity: wait ? 0.45 : 1 }}>
                <div style={{ font: "600 14px 'DM Sans'", color: HW2_COLOR.ink }}>{s.label}</div>
                <div style={{ font: "400 12px 'DM Mono'", color: HW2_COLOR.muted, marginTop: 2 }}>{s.detail}</div>
              </div>
              {active && <span style={{ font: "500 11px 'DM Sans'", color: HW2_COLOR.blue }}>working…</span>}
            </div>
          );
        })}
      </HW2Card>

      <p style={{ font: "400 12px 'DM Sans'", color: HW2_COLOR.faint, textAlign: "center", marginTop: 24 }}>
        We&rsquo;ll show you what we found next. Nothing is committed until you say so.
      </p>

      <style>{`
        @keyframes hw2-pulse { 0%,100%{transform:scale(1)} 50%{transform:scale(1.4); opacity:0.4} }
      `}</style>
    </div>
  );
}

// ─── Understand ────────────────────────────────────────────────────────────
function HW2Understand({ project, data, onConfirm, onSomethingOff }) {
  const [showIrrelevant, setShowIrrelevant] = React.useState(false);
  const [showEvidence, setShowEvidence] = React.useState(false);

  return (
    <div style={{ maxWidth: 920, margin: "0 auto", padding: "32px 32px 80px" }}>
      <span style={{
        font: "600 11px 'DM Sans'", color: HW2_COLOR.blue,
        letterSpacing: "0.08em", textTransform: "uppercase",
      }}>Step 2 of 5 · Understand</span>
      <h2 style={{
        font: "600 26px 'DM Sans'", letterSpacing: "-0.02em",
        color: HW2_COLOR.ink, lineHeight: 1.25, marginTop: 8, marginBottom: 4,
      }}>Here&rsquo;s what this data is.</h2>
      <p style={{ font: "400 14px 'DM Sans'", color: HW2_COLOR.muted, marginBottom: 28 }}>
        A patient imaging journey, logged as events. Skim it. Confirm at the bottom.
      </p>

      {/* ER diagram (simple boxes & flows) */}
      <HW2Card style={{ padding: "26px 28px", marginBottom: 18 }}>
        <div style={{ font: "600 11px 'DM Sans'", color: HW2_COLOR.muted, textTransform: "uppercase", letterSpacing: "0.06em", marginBottom: 14 }}>
          The shape of it
        </div>
        <ErDiagram tables={data.source.tables} />
      </HW2Card>

      {/* Workflow lane with registration zone */}
      <HW2Card style={{ padding: "26px 28px", marginBottom: 18 }}>
        <div style={{ display: "flex", alignItems: "baseline", justifyContent: "space-between", marginBottom: 14 }}>
          <span style={{ font: "600 11px 'DM Sans'", color: HW2_COLOR.muted, textTransform: "uppercase", letterSpacing: "0.06em" }}>
            Reconstructed workflow
          </span>
          <span style={{ font: "400 11px 'DM Sans'", color: HW2_COLOR.faint }}>
            inferred from events.activity sequences
          </span>
        </div>
        <WorkflowLane steps={data.workflow} />
        <div style={{ marginTop: 14, font: "400 13px 'DM Sans'", color: HW2_COLOR.ink2, lineHeight: 1.55 }}>
          The shaded band is the <strong>registration zone</strong> — the steps that look like they
          define your wait window. We&rsquo;ll confirm exactly where it ends in the next step.
        </div>
      </HW2Card>

      {/* Relevant columns chips */}
      <HW2Card>
        <div style={{ display: "flex", alignItems: "baseline", justifyContent: "space-between", marginBottom: 12 }}>
          <span style={{ font: "600 11px 'DM Sans'", color: HW2_COLOR.muted, textTransform: "uppercase", letterSpacing: "0.06em" }}>
            Relevant to your goal
          </span>
          <span style={{ font: "400 11px 'DM Sans'", color: HW2_COLOR.faint }}>
            {data.relevant.length} columns
          </span>
        </div>
        <div style={{ display: "flex", flexWrap: "wrap", gap: 8, marginBottom: 8 }}>
          {data.relevant.map((c) => (
            <span key={c.table + c.col} title={c.reason} style={{
              display: "inline-flex", alignItems: "center", gap: 6,
              padding: "5px 9px", borderRadius: 6,
              background: HW2_COLOR.blueSoft, color: HW2_COLOR.blue,
              font: "500 12px 'DM Mono'",
            }}>
              <span style={{ color: HW2_COLOR.muted }}>{c.table}.</span>{c.col}
            </span>
          ))}
        </div>

        <button onClick={() => setShowIrrelevant(v => !v)} style={{
          appearance: "none", background: "none", border: "none", cursor: "pointer",
          padding: 0, marginTop: 6, color: HW2_COLOR.muted,
          font: "500 13px 'DM Sans'", display: "inline-flex", alignItems: "center", gap: 6,
        }}>
          <span style={{ font: "500 11px 'DM Mono'", color: HW2_COLOR.faint }}>{showIrrelevant ? "▼" : "▶"}</span>
          {data.irrelevant.length} columns judged not relevant to this goal
        </button>
        {showIrrelevant && (
          <div style={{ display: "flex", flexWrap: "wrap", gap: 6, marginTop: 10 }}>
            {data.irrelevant.map((c) => (
              <span key={c.table + c.col} title={c.reason} style={{
                padding: "4px 8px", borderRadius: 6,
                background: HW2_COLOR.chip, color: HW2_COLOR.muted,
                font: "500 12px 'DM Mono'", textDecoration: "line-through", textDecorationColor: HW2_COLOR.faint,
              }}>
                <span style={{ color: HW2_COLOR.faint }}>{c.table}.</span>{c.col}
              </span>
            ))}
          </div>
        )}
      </HW2Card>

      {/* Action — looks right? */}
      <div style={{
        marginTop: 28, display: "flex", alignItems: "center", justifyContent: "space-between",
        padding: "16px 20px", background: HW2_COLOR.surface,
        border: `1px solid ${HW2_COLOR.rule2}`, borderRadius: 12,
      }}>
        <div>
          <div style={{ font: "600 14px 'DM Sans'", color: HW2_COLOR.ink }}>Looks right?</div>
          <div style={{ font: "400 12px 'DM Sans'", color: HW2_COLOR.muted, marginTop: 2 }}>
            One high-level confirmation. We&rsquo;ll surface the specific ambiguities next.
          </div>
        </div>
        <div style={{ display: "flex", gap: 8 }}>
          <button onClick={() => setShowEvidence(v => !v)} style={{
            appearance: "none", background: "transparent", border: "none", cursor: "pointer",
            padding: "8px 12px", color: HW2_COLOR.muted, font: "500 13px 'DM Sans'",
          }}>Show evidence</button>
          <HW2Btn onClick={onSomethingOff}>Something&rsquo;s off</HW2Btn>
          <HW2Btn kind="accent" onClick={onConfirm}>Yes, continue →</HW2Btn>
        </div>
      </div>
    </div>
  );
}

// ─── ER diagram (handmade because it's just 3 boxes) ────────────────────────
function ErDiagram({ tables }) {
  return (
    <div style={{ display: "flex", alignItems: "center", justifyContent: "center", gap: 14, paddingTop: 6 }}>
      {tables.map((t, i) => (
        <React.Fragment key={t.name}>
          <div style={{
            minWidth: 170, padding: "12px 14px",
            background: "#fff", border: `1px solid ${HW2_COLOR.rule2}`, borderRadius: 10,
          }}>
            <div style={{ font: "600 13px 'DM Mono'", color: HW2_COLOR.ink }}>{t.name}</div>
            <div style={{ font: "400 11px 'DM Sans'", color: HW2_COLOR.muted, marginTop: 2 }}>
              {t.rows.toLocaleString()} rows · {t.cols} cols
            </div>
            <div style={{ font: "400 11px 'DM Mono'", color: HW2_COLOR.faint, marginTop: 6 }}>
              {t.pk && <>pk: {t.pk}<br /></>}
              {t.fk && <>fk: {t.fk}</>}
            </div>
          </div>
          {i < tables.length - 1 && (
            <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 2 }}>
              <span style={{ font: "500 11px 'DM Mono'", color: HW2_COLOR.faint }}>1 — many</span>
              <span style={{ width: 28, height: 1, background: HW2_COLOR.rule2 }} />
            </div>
          )}
        </React.Fragment>
      ))}
    </div>
  );
}

// ─── Workflow lane (with registration zone shading) ──────────────────────────
function WorkflowLane({ steps }) {
  // Find the registration band span
  const firstReg = steps.findIndex(s => s.zone === "registration");
  const lastReg  = steps.length - 1 - [...steps].reverse().findIndex(s => s.zone === "registration");

  return (
    <div style={{ position: "relative", padding: "12px 0 28px" }}>
      {/* Shaded band */}
      {firstReg !== -1 && (
        <div style={{
          position: "absolute", top: 4, bottom: 22,
          left: `calc(${(firstReg / steps.length) * 100}% + 4px)`,
          width: `calc(${((lastReg - firstReg + 1) / steps.length) * 100}% - 8px)`,
          background: HW2_COLOR.blueSoft, borderRadius: 8,
          border: `1px dashed ${HW2_COLOR.blue}`, zIndex: 0,
        }} />
      )}
      <div style={{ position: "relative", display: "grid", gridTemplateColumns: `repeat(${steps.length}, 1fr)`, gap: 0, zIndex: 1 }}>
        {steps.map((s, i) => (
          <div key={s.step} style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 6 }}>
            <span style={{
              padding: "5px 9px", borderRadius: 14, background: "#fff",
              border: `1px solid ${s.zone === "registration" ? HW2_COLOR.blue : HW2_COLOR.rule2}`,
              font: "500 12px 'DM Mono'",
              color: s.zone === "registration" ? HW2_COLOR.blue : HW2_COLOR.ink2,
              whiteSpace: "nowrap",
            }}>
              {s.step}
            </span>
            {i < steps.length - 1 && (
              <span style={{
                position: "absolute", top: 22,
                left: `calc(${((i + 0.5) / steps.length) * 100}%)`,
                width: `calc(${100 / steps.length}% - 16px)`,
                height: 1, background: HW2_COLOR.rule2, zIndex: -1,
              }} />
            )}
          </div>
        ))}
      </div>
      {firstReg !== -1 && (
        <div style={{
          position: "absolute", bottom: -2,
          left: `${(firstReg / steps.length) * 100}%`,
          width: `${((lastReg - firstReg + 1) / steps.length) * 100}%`,
          textAlign: "center",
          font: "500 10px 'DM Sans'", color: HW2_COLOR.blue,
          letterSpacing: "0.08em", textTransform: "uppercase",
        }}>registration zone</div>
      )}
    </div>
  );
}

Object.assign(window, { HW2Generate, HW2Understand });
