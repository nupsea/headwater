// Headwater 2 — shared UI primitives. All component names are HW2-prefixed
// to avoid Babel global-scope collisions.

const HW2_COLOR = {
  paper:   "#faf9f6",      // warm near-white canvas
  surface: "#ffffff",
  ink:     "#15161a",      // deep ink
  ink2:    "#3a3c43",
  muted:   "#74757b",
  faint:   "#9c9da3",
  rule:    "#ebe9e3",      // hairline divider, warm
  rule2:   "#dfdcd2",
  chip:    "#f1efe8",
  blue:    "#2b5fd9",      // calm accent
  blueSoft:"#e7eefc",
  good:    "#0e7a55",      // green / certified
  goodSoft:"#e1efe7",
  warn:    "#a26108",      // amber
  warnSoft:"#f5ecd9",
  bad:     "#b4351c",      // red / misleading
  badSoft: "#f7e3dc",
};

// ─── Trust Ring ──────────────────────────────────────────────────────────────
// The hero object. SVG arc that fills as trust rises. Color + label adapt.
function HW2TrustRing({ value, size = 56, stroke = 4, showLabel = true, animate = true }) {
  const r = (size - stroke) / 2;
  const c = Math.PI * 2 * r;
  const v = Math.max(0, Math.min(100, value || 0));
  const fill = c * (v / 100);
  const tone = trustTone(v);
  const ringColor = tone.color;
  const [drawn, setDrawn] = React.useState(animate ? 0 : v);
  React.useEffect(() => {
    if (!animate) { setDrawn(v); return; }
    let raf, t0;
    const from = drawn;
    const dur = 700;
    const step = (t) => {
      if (!t0) t0 = t;
      const p = Math.min(1, (t - t0) / dur);
      const eased = 1 - Math.pow(1 - p, 3);
      setDrawn(from + (v - from) * eased);
      if (p < 1) raf = requestAnimationFrame(step);
    };
    raf = requestAnimationFrame(step);
    return () => cancelAnimationFrame(raf);
  }, [v]); // eslint-disable-line
  const fillNow = c * (drawn / 100);
  return (
    <div style={{ display: "inline-flex", alignItems: "center", gap: 10 }}>
      <svg width={size} height={size} style={{ display: "block" }}>
        <circle cx={size/2} cy={size/2} r={r}
          stroke={HW2_COLOR.rule2} strokeWidth={stroke} fill="none" />
        <circle cx={size/2} cy={size/2} r={r}
          stroke={ringColor} strokeWidth={stroke} fill="none"
          strokeLinecap="round"
          strokeDasharray={`${fillNow} ${c}`}
          transform={`rotate(-90 ${size/2} ${size/2})`} />
        <text x="50%" y="50%" textAnchor="middle" dominantBaseline="central"
          style={{ font: "600 13px 'DM Sans', sans-serif", fill: HW2_COLOR.ink, letterSpacing: "-0.02em" }}>
          {Math.round(drawn)}
        </text>
      </svg>
      {showLabel && (
        <div style={{ display: "flex", flexDirection: "column", lineHeight: 1.15 }}>
          <span style={{ font: "600 11px 'DM Sans'", color: HW2_COLOR.muted, letterSpacing: "0.04em", textTransform: "uppercase" }}>Trust</span>
          <span style={{ font: "600 14px 'DM Sans'", color: tone.color, letterSpacing: "-0.01em" }}>{tone.label}</span>
        </div>
      )}
    </div>
  );
}

function trustTone(v) {
  if (v >= 90) return { label: "Certified",  color: HW2_COLOR.good, key: "certified" };
  if (v >= 75) return { label: "Ready-ish",  color: HW2_COLOR.good, key: "ready" };
  if (v >= 50) return { label: "Forming",    color: HW2_COLOR.blue, key: "forming" };
  if (v >= 20) return { label: "Low",        color: HW2_COLOR.warn, key: "low" };
  if (v > 0)   return { label: "Starting",   color: HW2_COLOR.warn, key: "starting" };
  return         { label: "Not started", color: HW2_COLOR.faint, key: "none" };
}

// ─── Stage stepper (top of every project screen) ─────────────────────────────
const HW2_STAGES = [
  { key: "frame",      label: "Frame" },
  { key: "understand", label: "Understand" },
  { key: "resolve",    label: "Resolve" },
  { key: "readiness",  label: "Readiness" },
  { key: "answer",     label: "Answer" },
];

function HW2Stepper({ current, onJump, project }) {
  const idx = HW2_STAGES.findIndex((s) => s.key === current);
  return (
    <div style={{ display: "flex", alignItems: "center", gap: 0 }}>
      {HW2_STAGES.map((s, i) => {
        const active   = i === idx;
        const complete = i < idx;
        const future   = i > idx;
        const badge =
          s.key === "resolve" && project?.resolveTotal > 0
            ? `${project.resolved}/${project.resolveTotal}`
            : null;
        return (
          <React.Fragment key={s.key}>
            <button
              onClick={() => onJump?.(s.key)}
              style={{
                appearance: "none", background: "none", border: "none",
                cursor: "pointer", padding: "8px 12px", borderRadius: 8,
                display: "inline-flex", alignItems: "center", gap: 8,
                font: `${active ? 600 : 500} 13px 'DM Sans'`,
                color: active ? HW2_COLOR.ink : complete ? HW2_COLOR.ink2 : HW2_COLOR.faint,
                fontFamily: "'DM Sans', sans-serif",
              }}>
              <span style={{
                display: "inline-flex", alignItems: "center", justifyContent: "center",
                width: 20, height: 20, borderRadius: "50%",
                background: complete ? HW2_COLOR.good : active ? HW2_COLOR.ink : "transparent",
                border: complete ? "none" : active ? "none" : `1.5px solid ${HW2_COLOR.rule2}`,
                color: complete || active ? "#fff" : HW2_COLOR.faint,
                font: "600 10px 'DM Mono'",
              }}>
                {complete ? "✓" : i + 1}
              </span>
              <span>{s.label}</span>
              {badge && (
                <span style={{
                  font: "600 10px 'DM Mono'",
                  background: HW2_COLOR.blueSoft, color: HW2_COLOR.blue,
                  padding: "2px 6px", borderRadius: 4,
                }}>{badge}</span>
              )}
            </button>
            {i < HW2_STAGES.length - 1 && (
              <span style={{ color: HW2_COLOR.rule2, font: "300 14px 'DM Sans'", padding: "0 2px" }}>›</span>
            )}
          </React.Fragment>
        );
      })}
    </div>
  );
}

// ─── Primitive buttons ──────────────────────────────────────────────────────
function HW2Btn({ kind = "default", size = "md", children, onClick, disabled, style, ...rest }) {
  const sizes = {
    sm: { padding: "5px 10px", font: "500 12px 'DM Sans'", radius: 6 },
    md: { padding: "8px 14px", font: "500 13px 'DM Sans'", radius: 8 },
    lg: { padding: "11px 20px", font: "600 14px 'DM Sans'", radius: 10 },
  }[size];
  const kinds = {
    default: { bg: "#fff", color: HW2_COLOR.ink, border: `1px solid ${HW2_COLOR.rule2}`, hover: HW2_COLOR.chip },
    primary: { bg: HW2_COLOR.ink, color: "#fff", border: "1px solid transparent", hover: "#2c2e34" },
    accent:  { bg: HW2_COLOR.blue, color: "#fff", border: "1px solid transparent", hover: "#234ec2" },
    ghost:   { bg: "transparent", color: HW2_COLOR.ink2, border: "1px solid transparent", hover: HW2_COLOR.chip },
    danger:  { bg: "#fff", color: HW2_COLOR.bad, border: `1px solid ${HW2_COLOR.rule2}`, hover: HW2_COLOR.badSoft },
  }[kind];
  const [h, setH] = React.useState(false);
  return (
    <button onClick={onClick} disabled={disabled}
      onMouseEnter={() => setH(true)} onMouseLeave={() => setH(false)}
      style={{
        appearance: "none", cursor: disabled ? "default" : "pointer",
        background: h && !disabled ? kinds.hover : kinds.bg,
        color: kinds.color, border: kinds.border, borderRadius: sizes.radius,
        padding: sizes.padding, font: sizes.font, fontFamily: "'DM Sans', sans-serif",
        opacity: disabled ? 0.5 : 1, transition: "background 120ms",
        ...style,
      }} {...rest}>
      {children}
    </button>
  );
}

// ─── Tag / chip ──────────────────────────────────────────────────────────────
function HW2Chip({ tone = "neutral", children, mono = false, style }) {
  const tones = {
    neutral: { bg: HW2_COLOR.chip, color: HW2_COLOR.ink2 },
    blue:    { bg: HW2_COLOR.blueSoft, color: HW2_COLOR.blue },
    good:    { bg: HW2_COLOR.goodSoft, color: HW2_COLOR.good },
    warn:    { bg: HW2_COLOR.warnSoft, color: HW2_COLOR.warn },
    bad:     { bg: HW2_COLOR.badSoft, color: HW2_COLOR.bad },
    muted:   { bg: "transparent", color: HW2_COLOR.muted },
  }[tone];
  return (
    <span style={{
      display: "inline-flex", alignItems: "center", gap: 4,
      padding: "3px 8px", borderRadius: 999,
      background: tones.bg, color: tones.color,
      font: `${mono ? "500" : "600"} 11px ${mono ? "'DM Mono'" : "'DM Sans'"}`,
      letterSpacing: mono ? "0" : "0.01em",
      ...style,
    }}>{children}</span>
  );
}

// ─── Card ────────────────────────────────────────────────────────────────────
function HW2Card({ children, padded = true, style, ...rest }) {
  return (
    <div {...rest} style={{
      background: HW2_COLOR.surface,
      border: `1px solid ${HW2_COLOR.rule}`,
      borderRadius: 12,
      padding: padded ? 20 : 0,
      ...style,
    }}>{children}</div>
  );
}

// Export to window for cross-file access (Babel scopes per-script).
Object.assign(window, {
  HW2_COLOR, HW2_STAGES,
  HW2TrustRing, HW2Stepper, HW2Btn, HW2Chip, HW2Card,
  trustTone,
});
