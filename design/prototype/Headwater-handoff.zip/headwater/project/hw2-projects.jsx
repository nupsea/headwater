// Headwater 2 — Frame stage (project = goal + many questions + table scope).

function HW2Frame({ project, source, onGenerate, onUpdate }) {
  const [goal, setGoal]         = React.useState(project.goal || "");
  const [questions, setQuestions] = React.useState(project.questions || []);
  const [newQ, setNewQ] = React.useState("");
  const [selected, setSelected] = React.useState(
    () => new Set(project.selectedTables || [])
  );
  const [showTablePicker, setShowTablePicker] = React.useState(false);

  const ready = goal.trim().length >= 6 && questions.length > 0 && selected.size > 0;

  const addQuestion = () => {
    if (!newQ.trim()) return;
    setQuestions(qs => [...qs, { id: "q_" + Date.now(), title: newQ.trim(), status: "draft", vouched: [] }]);
    setNewQ("");
  };
  const removeQuestion = (id) => setQuestions(qs => qs.filter(q => q.id !== id));
  const toggleTable = (fqn) => {
    const next = new Set(selected);
    next.has(fqn) ? next.delete(fqn) : next.add(fqn);
    setSelected(next);
  };

  return (
    <div style={{ maxWidth: 880, margin: "0 auto", padding: "32px 32px 80px" }}>
      <span style={{
        font: "600 11px 'DM Sans'", color: HW2_COLOR.blue,
        letterSpacing: "0.08em", textTransform: "uppercase",
      }}>Step 1 of 5 · Frame</span>
      <h2 style={{
        font: "600 26px 'DM Sans'", letterSpacing: "-0.02em",
        color: HW2_COLOR.ink, lineHeight: 1.25, marginTop: 8, marginBottom: 6,
      }}>What goal are we serving?</h2>
      <p style={{ font: "400 14px 'DM Sans'", color: HW2_COLOR.muted, marginBottom: 24, lineHeight: 1.55 }}>
        A project is a theme — a goal you&rsquo;ll explore through many questions. Headwater will tell you,
        honestly, whether this data can answer them.
      </p>

      {/* Goal */}
      <label style={{ font: "600 12px 'DM Sans'", color: HW2_COLOR.muted, display: "block", marginBottom: 8 }}>
        The goal
      </label>
      <textarea
        value={goal} onChange={(e) => setGoal(e.target.value)}
        placeholder="e.g. Reduce patient wait time before imaging across modalities"
        rows={2}
        style={{
          width: "100%", resize: "vertical", display: "block",
          padding: "12px 16px",
          background: "#fff", border: `1px solid ${HW2_COLOR.rule2}`, borderRadius: 10,
          font: "500 16px 'DM Sans'", color: HW2_COLOR.ink, lineHeight: 1.4,
          fontFamily: "'DM Sans', sans-serif", outline: "none",
        }}
        onFocus={(e) => e.currentTarget.style.borderColor = HW2_COLOR.blue}
        onBlur={(e) => e.currentTarget.style.borderColor = HW2_COLOR.rule2}
      />

      {/* Questions */}
      <div style={{ marginTop: 32 }}>
        <div style={{ display: "flex", alignItems: "baseline", justifyContent: "space-between", marginBottom: 10 }}>
          <label style={{ font: "600 12px 'DM Sans'", color: HW2_COLOR.muted }}>
            Questions to answer
          </label>
          <span style={{ font: "400 11px 'DM Sans'", color: HW2_COLOR.faint }}>
            {questions.length} added · you can add more later
          </span>
        </div>

        <div style={{ display: "grid", gap: 6 }}>
          {questions.map((q, i) => (
            <div key={q.id} style={{
              display: "flex", alignItems: "center", gap: 12,
              padding: "10px 14px",
              background: "#fff", border: `1px solid ${HW2_COLOR.rule2}`, borderRadius: 8,
            }}>
              <span style={{
                font: "500 11px 'DM Mono'", color: HW2_COLOR.faint,
                width: 20, flexShrink: 0,
              }}>Q{i + 1}</span>
              <input
                value={q.title}
                onChange={(e) => setQuestions(qs => qs.map(x => x.id === q.id ? { ...x, title: e.target.value } : x))}
                style={{
                  flex: 1, appearance: "none", background: "transparent", border: "none",
                  padding: 0, font: "500 14px 'DM Sans'", color: HW2_COLOR.ink2, outline: "none",
                  fontFamily: "'DM Sans', sans-serif",
                }}
              />
              <button onClick={() => removeQuestion(q.id)} style={{
                appearance: "none", background: "transparent", border: "none", cursor: "pointer",
                color: HW2_COLOR.faint, padding: 4, font: "300 18px 'DM Sans'", lineHeight: 1,
              }}>×</button>
            </div>
          ))}
          {/* Add row */}
          <div style={{
            display: "flex", alignItems: "center", gap: 12,
            padding: "10px 14px", borderRadius: 8,
            background: HW2_COLOR.chip, border: `1px dashed ${HW2_COLOR.rule2}`,
          }}>
            <span style={{ font: "500 11px 'DM Mono'", color: HW2_COLOR.faint, width: 20 }}>+</span>
            <input
              value={newQ}
              onChange={(e) => setNewQ(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && addQuestion()}
              placeholder="Add a question — e.g. When is wait time longest?"
              style={{
                flex: 1, appearance: "none", background: "transparent", border: "none",
                padding: 0, font: "500 14px 'DM Sans'", color: HW2_COLOR.ink, outline: "none",
                fontFamily: "'DM Sans', sans-serif",
              }}
            />
            <HW2Btn size="sm" onClick={addQuestion}>Add</HW2Btn>
          </div>
        </div>
      </div>

      {/* Tables */}
      <div style={{ marginTop: 32 }}>
        <div style={{ display: "flex", alignItems: "baseline", justifyContent: "space-between", marginBottom: 10 }}>
          <label style={{ font: "600 12px 'DM Sans'", color: HW2_COLOR.muted }}>
            Data scope · {selected.size} tables from {source.name}
          </label>
          <button onClick={() => setShowTablePicker(v => !v)} style={anchorBtnLink}>
            {showTablePicker ? "Hide" : "Edit"} table picks
          </button>
        </div>

        {!showTablePicker ? (
          <div style={{ display: "flex", flexWrap: "wrap", gap: 6 }}>
            {[...selected].map(fqn => (
              <HW2Chip key={fqn} mono tone="blue">{fqn}</HW2Chip>
            ))}
            {selected.size === 0 && (
              <button onClick={() => setShowTablePicker(true)} style={{
                appearance: "none", cursor: "pointer", background: HW2_COLOR.chip,
                border: `1px dashed ${HW2_COLOR.rule2}`, borderRadius: 8,
                padding: "10px 14px", font: "500 13px 'DM Sans'", color: HW2_COLOR.muted,
              }}>
                + Pick tables from {source.name}
              </button>
            )}
          </div>
        ) : (
          <HW2Card padded={false}>
            <div style={{
              padding: "8px 14px", background: HW2_COLOR.paper,
              borderBottom: `1px solid ${HW2_COLOR.rule}`,
              font: "400 11px 'DM Sans'", color: HW2_COLOR.muted,
            }}>
              Pick across schemas. Profiles are reused — picking doesn&rsquo;t re-scan.
            </div>
            <div style={{ maxHeight: 280, overflowY: "auto", padding: "8px 6px" }}>
              {source.schemas.map(s => (
                <div key={s.name} style={{ marginBottom: 6 }}>
                  <div style={{ padding: "4px 12px", font: "600 11px 'DM Mono'", color: HW2_COLOR.muted }}>
                    {s.name}
                  </div>
                  {s.tables.map(t => {
                    const fqn = `${s.name}.${t.name}`;
                    const sel = selected.has(fqn);
                    return (
                      <label key={t.name} style={{
                        display: "flex", alignItems: "center", gap: 10,
                        padding: "5px 12px", cursor: "pointer",
                      }}>
                        <input type="checkbox" checked={sel} onChange={() => toggleTable(fqn)}
                          style={{ accentColor: HW2_COLOR.blue }} />
                        <span style={{ font: "500 12px 'DM Mono'", color: HW2_COLOR.ink2, minWidth: 140 }}>{t.name}</span>
                        <span style={{ flex: 1, font: "400 12px 'DM Sans'", color: HW2_COLOR.muted, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
                          {t.description}
                        </span>
                        <span style={{ font: "400 11px 'DM Mono'", color: HW2_COLOR.faint }}>
                          {t.rows >= 1000 ? `${(t.rows/1000).toFixed(1)}k` : t.rows}
                        </span>
                      </label>
                    );
                  })}
                </div>
              ))}
            </div>
          </HW2Card>
        )}
      </div>

      {/* Action */}
      <div style={{ marginTop: 36, display: "flex", justifyContent: "space-between", alignItems: "center" }}>
        <span style={{ font: "400 12px 'DM Sans'", color: HW2_COLOR.faint }}>
          {!ready && "Add a goal, at least one question, and pick at least one table."}
        </span>
        <HW2Btn kind="accent" size="lg" disabled={!ready}
          onClick={() => onGenerate({ goal, questions, selectedTables: [...selected] })}>
          Generate understanding →
        </HW2Btn>
      </div>
    </div>
  );
}

const anchorBtnLink = {
  appearance: "none", background: "transparent", border: "none", cursor: "pointer",
  padding: 0, color: HW2_COLOR.blue, font: "500 12px 'DM Sans'",
  fontFamily: "'DM Sans', sans-serif",
};

Object.assign(window, { HW2Frame });
