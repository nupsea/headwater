// Headwater 2 — fixture data. A project is a goal/theme with many questions;
// sources have multiple schemas; the user picks a subset of tables.

window.HW2 = {
  sources: [
    {
      id: "hospital_pg",
      name: "hospital_db",
      kind: "Postgres",
      host: "pg.hospital.internal:5432",
      profiledAt: "2026-05-26 14:02",
      schemas: [
        {
          name: "clinical",
          tables: [
            { name: "cases",       rows: 3193,   cols: 9,  pk: "case_id",     fk: null,                  selected: true,  description: "Patient visit / case header" },
            { name: "exams",       rows: 3507,   cols: 6,  pk: "exam_id",     fk: "case_id → cases",    selected: true,  description: "Each scan / exam performed" },
            { name: "events",      rows: 27343,  cols: 5,  pk: "event_id",    fk: "case_id → cases",    selected: true,  description: "Workflow activity event log" },
            { name: "patients",    rows: 2814,   cols: 7,  pk: "patient_id",  fk: null,                  selected: false, description: "Patient master" },
            { name: "diagnoses",   rows: 4126,   cols: 5,  pk: "dx_id",       fk: "case_id → cases",    selected: false, description: "Diagnoses per case" },
          ],
        },
        {
          name: "ops",
          tables: [
            { name: "rooms",       rows: 28,     cols: 5,  pk: "room_id",        fk: null,             selected: true,  description: "Imaging rooms & modality" },
            { name: "equipment",   rows: 41,     cols: 6,  pk: "equipment_id",   fk: "room_id → rooms", selected: false, description: "Scanners & devices" },
            { name: "schedules",   rows: 8924,   cols: 6,  pk: "schedule_id",    fk: null,             selected: false, description: "Booking schedule" },
          ],
        },
        {
          name: "staff",
          tables: [
            { name: "shifts",      rows: 1612,   cols: 5,  pk: "shift_id",     fk: null,               selected: true,  description: "Staff shift roster" },
            { name: "assignments", rows: 4203,   cols: 4,  pk: "assign_id",    fk: "shift_id → shifts", selected: false, description: "Who worked which case" },
            { name: "staff",       rows: 184,    cols: 8,  pk: "staff_id",     fk: null,               selected: false, description: "Staff master" },
          ],
        },
        {
          name: "billing",
          tables: [
            { name: "invoices",    rows: 3015,   cols: 7,  pk: "invoice_id",   fk: "case_id → cases",  selected: false, description: "Invoices" },
            { name: "payments",    rows: 4112,   cols: 5,  pk: "payment_id",   fk: "invoice_id",       selected: false, description: "Payments" },
            { name: "payers",      rows: 38,     cols: 4,  pk: "payer_id",     fk: null,                selected: false, description: "Insurance payers" },
          ],
        },
      ],
    },
  ],

  // Sample columns for the Catalog (when expanding a table)
  catalogColumns: {
    "clinical.cases": [
      { name: "case_id",          type: "varchar",   pk: true,  semantic: "Identifier", desc: "Unique visit id",                   locked: true,  nulls: 0 },
      { name: "patient_id",       type: "varchar",   pk: false, semantic: "Identifier", desc: "FK → patients",                     locked: false, nulls: 0 },
      { name: "arrival_time",     type: "timestamp", pk: false, semantic: "Timestamp",  desc: "Patient check-in time",             locked: true,  nulls: 0 },
      { name: "patient_type",     type: "varchar",   pk: false, semantic: "Categorical", desc: "A/H/S/D — meaning unconfirmed",    locked: false, nulls: 0 },
      { name: "total_wait_time",  type: "interval",  pk: false, semantic: "Duration",   desc: "Two formats present — see Resolve", locked: false, nulls: 12 },
      { name: "scheduled_imaging",type: "boolean",   pk: false, semantic: "Flag",       desc: "Pre-scheduled vs walk-in",          locked: false, nulls: 4  },
      { name: "discharge_time",   type: "timestamp", pk: false, semantic: "Timestamp",  desc: "End of visit",                      locked: false, nulls: 38 },
      { name: "billing_status",   type: "varchar",   pk: false, semantic: "Categorical", desc: "Open/closed/disputed",             locked: false, nulls: 0  },
      { name: "case_notes",       type: "text",      pk: false, semantic: "Free text",  desc: "Free-form clinician notes",         locked: false, nulls: 1894 },
    ],
    "clinical.exams": [
      { name: "exam_id",          type: "varchar",   pk: true,  semantic: "Identifier", desc: "PK", locked: true, nulls: 0 },
      { name: "case_id",          type: "varchar",   pk: false, semantic: "Identifier", desc: "FK → cases", locked: true, nulls: 0 },
      { name: "modality",         type: "varchar",   pk: false, semantic: "Categorical", desc: "MRI / CT / US / X-ray — 88% null on non-exam events", locked: false, nulls: 412 },
      { name: "scan_time_duration", type: "interval", pk: false, semantic: "Duration", desc: "Active scan duration", locked: true, nulls: 0 },
      { name: "tech_id",          type: "varchar",   pk: false, semantic: "Identifier", desc: "FK → staff", locked: false, nulls: 23 },
      { name: "reading_radiologist", type: "varchar", pk: false, semantic: "Identifier", desc: "FK → staff", locked: false, nulls: 102 },
    ],
    "clinical.events": [
      { name: "event_id",         type: "varchar",   pk: true,  semantic: "Identifier", desc: "PK", locked: true, nulls: 0 },
      { name: "case_id",          type: "varchar",   pk: false, semantic: "Identifier", desc: "FK → cases", locked: true, nulls: 0 },
      { name: "activity",         type: "varchar",   pk: false, semantic: "Categorical", desc: "Workflow step name", locked: false, nulls: 0 },
      { name: "timestamp_start",  type: "timestamp", pk: false, semantic: "Timestamp",  desc: "Step start", locked: true, nulls: 0 },
      { name: "timestamp_end",    type: "timestamp", pk: false, semantic: "Timestamp",  desc: "Step end", locked: false, nulls: 311 },
    ],
    "ops.rooms": [
      { name: "room_id",          type: "varchar",   pk: true,  semantic: "Identifier", desc: "PK", locked: true, nulls: 0 },
      { name: "room_name",        type: "varchar",   pk: false, semantic: "Label",      desc: "Display name", locked: false, nulls: 0 },
      { name: "modality",         type: "varchar",   pk: false, semantic: "Categorical", desc: "MRI/CT/US", locked: false, nulls: 0 },
      { name: "capacity_per_hr",  type: "int",       pk: false, semantic: "Quantity",   desc: "Throughput cap", locked: false, nulls: 2 },
      { name: "is_active",        type: "boolean",   pk: false, semantic: "Flag",       desc: "In service", locked: false, nulls: 0 },
    ],
    "staff.shifts": [
      { name: "shift_id",         type: "varchar",   pk: true,  semantic: "Identifier", desc: "PK", locked: true, nulls: 0 },
      { name: "staff_id",         type: "varchar",   pk: false, semantic: "Identifier", desc: "FK → staff", locked: false, nulls: 0 },
      { name: "shift_start",      type: "timestamp", pk: false, semantic: "Timestamp",  desc: "Start", locked: false, nulls: 0 },
      { name: "shift_end",        type: "timestamp", pk: false, semantic: "Timestamp",  desc: "End", locked: false, nulls: 14 },
      { name: "role",             type: "varchar",   pk: false, semantic: "Categorical", desc: "Tech/Radiologist/Reception", locked: false, nulls: 0 },
    ],
  },

  // Sample rows for previewing in the catalog
  sampleRows: {
    "clinical.cases": [
      { case_id: "C-39201", patient_id: "P-1024", arrival_time: "2026-05-21 08:14", patient_type: "A", total_wait_time: "00:24", scheduled_imaging: true,  billing_status: "open" },
      { case_id: "C-39202", patient_id: "P-2389", arrival_time: "2026-05-21 08:31", patient_type: "S", total_wait_time: "0 days 00:51:00", scheduled_imaging: false, billing_status: "open" },
      { case_id: "C-39203", patient_id: "P-0413", arrival_time: "2026-05-21 09:02", patient_type: "H", total_wait_time: "00:12", scheduled_imaging: true,  billing_status: "closed" },
      { case_id: "C-39204", patient_id: "P-5512", arrival_time: "2026-05-21 09:18", patient_type: "A", total_wait_time: "00:38", scheduled_imaging: true,  billing_status: "open" },
    ],
    "clinical.events": [
      { event_id: "E-101", case_id: "C-39201", activity: "Llegada_Pacientes_H",  timestamp_start: "2026-05-21 08:14", timestamp_end: "2026-05-21 08:15" },
      { event_id: "E-102", case_id: "C-39201", activity: "Recepcion",            timestamp_start: "2026-05-21 08:16", timestamp_end: "2026-05-21 08:21" },
      { event_id: "E-103", case_id: "C-39201", activity: "FrontOffice",          timestamp_start: "2026-05-21 08:21", timestamp_end: "2026-05-21 08:29" },
      { event_id: "E-104", case_id: "C-39201", activity: "AsignacionSala",       timestamp_start: "2026-05-21 08:30", timestamp_end: "2026-05-21 08:32" },
      { event_id: "E-105", case_id: "C-39201", activity: "ExaminacionExtra?",    timestamp_start: "2026-05-21 08:38", timestamp_end: "2026-05-21 08:54" },
    ],
  },

  // Catalog connectors (for the Connect flow)
  connectors: [
    { id: "csv",       name: "CSV / files",   blurb: "Drop CSV or JSON files" },
    { id: "postgres",  name: "Postgres",      blurb: "Connect to a Postgres database" },
    { id: "snowflake", name: "Snowflake",     blurb: "Snowflake account" },
    { id: "bigquery",  name: "BigQuery",      blurb: "GCP service account" },
    { id: "duckdb",    name: "DuckDB",        blurb: "Local DuckDB file" },
    { id: "redshift",  name: "Redshift",      blurb: "AWS Redshift cluster" },
    { id: "mysql",     name: "MySQL",         blurb: "MySQL / MariaDB" },
    { id: "sqlite",    name: "SQLite",        blurb: "SQLite file" },
  ],

  projects: [
    {
      id: "wait_times",
      title: "Reduce patient wait times",
      goal: "Reduce patient wait time before imaging across modalities",
      sourceId: "hospital_pg",
      // Tables the user picked across schemas
      selectedTables: ["clinical.cases", "clinical.exams", "clinical.events", "staff.shifts", "ops.rooms"],
      stage: "resolve",
      trust: 62,
      lastTouched: "2 hours ago",
      resolved: 0,
      resolveTotal: 4,
      questions: [
        {
          id: "q1",
          title: "When is wait time worst across the day?",
          status: "answered",
          sql:
`SELECT EXTRACT(HOUR FROM arrival_time) AS hour,
       AVG(total_wait_time) AS avg_wait
FROM   clinical.cases
GROUP  BY 1
ORDER  BY 1;`,
          chartType: "line",
          vouched: ["cases.arrival_time", "cases.total_wait_time"],
        },
        {
          id: "q2",
          title: "Which patient_type has the longest wait?",
          status: "drafted",
          sql:
`SELECT patient_type,
       AVG(total_wait_time) AS avg_wait,
       COUNT(*) AS visits
FROM   clinical.cases
GROUP  BY 1
ORDER  BY 2 DESC;`,
          chartType: "bar",
          vouched: ["cases.patient_type", "cases.total_wait_time"],
          warning: "patient_type meaning still unmapped for code H",
        },
        {
          id: "q3",
          title: "Which workflow step contributes most to wait?",
          status: "drafted",
          sql:
`SELECT activity,
       AVG(timestamp_end - timestamp_start) AS avg_step_duration,
       COUNT(*) AS occurrences
FROM   clinical.events
WHERE  activity IN ('Recepcion','FrontOffice','BackOffice','AsignacionSala')
GROUP  BY 1
ORDER  BY 2 DESC;`,
          chartType: "bar",
          vouched: ["events.activity", "events.timestamp_start", "events.timestamp_end"],
        },
        {
          id: "q4",
          title: "Has wait time changed week-over-week?",
          status: "draft",
          sql: null,
          chartType: null,
          vouched: [],
        },
      ],
    },
    {
      id: "utilization",
      title: "Maximize device utilization",
      goal: "Maximize MRI / CT / Ultrasound throughput across rooms",
      sourceId: "hospital_pg",
      selectedTables: ["clinical.exams", "ops.rooms", "ops.equipment"],
      stage: "frame",
      trust: 0,
      lastTouched: "Just created",
      resolved: 0,
      resolveTotal: 0,
      questions: [],
    },
  ],

  // --- Reconstructed workflow events (for the Understand screen) ---
  workflow: [
    { step: "Arrival",         relevant: true,  zone: "before" },
    { step: "Recepcion",       relevant: true,  zone: "registration" },
    { step: "FrontOffice",     relevant: true,  zone: "registration" },
    { step: "BackOffice",      relevant: true,  zone: "registration" },
    { step: "AsignacionSala",  relevant: true,  zone: "registration" },
    { step: "Wait",            relevant: true,  zone: "after" },
    { step: "Exam",            relevant: false, zone: "after" },
  ],

  relevant: [
    { table: "cases",  col: "arrival_time",      reason: "Start of wait window" },
    { table: "cases",  col: "total_wait_time",   reason: "Target metric" },
    { table: "cases",  col: "patient_type",      reason: "Segmentation driver" },
    { table: "events", col: "activity",          reason: "Defines workflow step" },
    { table: "events", col: "timestamp_start",   reason: "Step duration" },
    { table: "events", col: "timestamp_end",     reason: "Step duration" },
    { table: "shifts", col: "shift_start",       reason: "Staff coverage at arrival" },
  ],
  irrelevant: [
    { table: "exams",  col: "reading_radiologist", reason: "Post-registration" },
    { table: "cases",  col: "case_notes",          reason: "Free text" },
    { table: "cases",  col: "billing_status",      reason: "Not used by goal" },
    { table: "cases",  col: "scheduled_imaging",   reason: "Captured in another field" },
    { table: "cases",  col: "discharge_time",      reason: "Post-registration" },
  ],

  resolveCards: [
    {
      id: "boundary",
      impact: "high", impactLabel: "High impact",
      why: "Defines your core metric",
      title: 'Where does "registration" end?',
      body: "The wait metric needs a boundary. The steps I see:",
      sequence: ["Arrival", "Recepcion", "FrontOffice", "BackOffice", "AsignacionSala"],
      prompt: "Registration is complete after:",
      kind: "choice",
      options: ["Recepcion", "FrontOffice", "BackOffice", "AsignacionSala"],
      suggested: "FrontOffice",
      gapHint: "Without a boundary the wait metric is undefined",
      trustGain: 8,
    },
    {
      id: "patient_type",
      impact: "med", impactLabel: "Medium impact",
      why: "Affects how you segment results",
      title: "What do patient_type codes mean?",
      body: "Four codes in cases.patient_type. Without meanings, segmented results are hard to defend.",
      kind: "mapping",
      mapping: [
        { code: "A", suggested: "Ambulatory",  options: ["Ambulatory", "Admitted", "Appointment", "Acute"] },
        { code: "H", suggested: "",            options: ["Homecare", "Hospitalized", "Emergency", "Other"] },
        { code: "S", suggested: "Scheduled",   options: ["Scheduled", "Same-day", "Staff", "Self-pay"] },
        { code: "D", suggested: "Discharged",  options: ["Discharged", "Direct", "Default", "Doctor referral"] },
      ],
      gapHint: "Segments will be labeled by raw code, not meaning",
      trustGain: 6,
    },
    {
      id: "modality_nulls",
      impact: "med", impactLabel: "Medium impact",
      why: "Quality flag — affects what you can trust",
      title: "exams.modality is empty 88% of the time. Missing or N/A?",
      body: "It's missing on every event except 'Exam'. That looks like a column only set on exam rows, not a data quality issue.",
      kind: "binary",
      options: ["Not-applicable for non-exam events", "Truly missing data"],
      suggested: "Not-applicable for non-exam events",
      gapHint: "Defaults to flagging 24,070 events as low quality",
      trustGain: 4,
    },
    {
      id: "vocab_split",
      impact: "low", impactLabel: "Low impact",
      why: "Reporting consistency",
      title: '"UltraSound" vs "US" — same thing?',
      body: "Two spellings appear in events.activity. Merging keeps downstream counts consistent.",
      kind: "binary",
      options: ["Yes, merge into one", "No, they're different"],
      suggested: "Yes, merge into one",
      gapHint: "Counts split across two labels",
      trustGain: 2,
    },
  ],

  readiness: {
    verdict: 'You can analyze arrival and wait patterns. The registration-complete boundary is user-defined (FrontOffice). 88% of modality is unlabeled — fine for these questions, blocking for device questions.',
    buckets: [
      { key: "have", label: "You have", icon: "✓", tone: "good",
        items: [
          "7-day event log, 3,193 visits",
          "Arrival timestamp on every case",
          "Reconstructed workflow: Arrival → Recepcion → FrontOffice → AsignacionSala → Wait → Exam",
          "Two duration fields (one usable, one not — see Risky)",
        ] },
      { key: "trustworthy", label: "Trustworthy", icon: "✓", tone: "good",
        items: [
          "case grain is clean (case_id unique, no nulls)",
          "case → exam → event joins verified (referential integrity 100%)",
          "Arrival times in monotonic UTC, no clock skew detected",
        ] },
      { key: "risky", label: "Risky — verify", icon: "!", tone: "warn",
        items: [
          'Two duration formats: "00:10" vs "0 days 00:22:00" — pick one',
          "Weekday pattern unusual (Sun/Thu high) — verify against hospital ops calendar",
          'Unusual spike on 2026-04-18 (3.2× median) — single-day anomaly',
        ] },
      { key: "missing", label: "Missing / gaps", icon: "○", tone: "muted",
        items: [
          'No explicit "registration complete" event — using FrontOffice as proxy (user-confirmed)',
          "patient_type meaning for code H still unmapped",
        ] },
      { key: "misleading", label: "Misleading", icon: "△", tone: "bad",
        items: [
          'events.activity \'ExaminacionExtra?\' contains a literal "?" — looks like a question, isn\'t',
          'activity "Llegada_Pacientes_H" mixes language and a code suffix — appears to mean "Arrival, Homecare"',
        ] },
    ],
  },

  // Generated chart data per chart type
  chartData: {
    waitByHour: Array.from({ length: 24 }, (_, h) => {
      const base = 6
        + Math.max(0, 14 * Math.exp(-Math.pow((h - 10) / 3.2, 2)))
        + Math.max(0, 9  * Math.exp(-Math.pow((h - 15) / 2.4, 2)));
      return { hour: h, wait: Math.round(base * 10) / 10, visits: Math.round(40 + base * 7) };
    }),
    waitByPatientType: [
      { label: "A", value: 21, n: 1842 },
      { label: "H", value: 28, n: 612 },
      { label: "S", value: 14, n: 489 },
      { label: "D", value: 19, n: 250 },
    ],
    stepDurations: [
      { label: "FrontOffice", value: 12 },
      { label: "Recepcion", value: 7 },
      { label: "BackOffice", value: 6 },
      { label: "AsignacionSala", value: 3 },
    ],
  },
};
