// hw-insights.jsx — Insights & Exploration (WOW page)

const { useState: useStateI } = React;
const D_I = window.HW;
const { SectionLabel, PanelCard, Btn } = window;

function AInsights({ appState }) {
  const confirmed = appState.confirmedDescs.length;
  const approved  = appState.approvedModels.length;
  const health    = Math.min(99, D_I.insightsData.healthScore + confirmed * 2 + approved * 3);
  const ins       = D_I.insightsData;

  return (
    <div style={{ maxWidth:900 }}>
      {/* Header */}
      <div style={{ marginBottom:28 }}>
        <SectionLabel>Insights &amp; Exploration</SectionLabel>
        <h1 style={{ fontSize:24, fontWeight:700, letterSpacing:"-0.03em", color:"#0f172a" }}>What your data is telling you</h1>
        <p style={{ fontSize:14, color:"#64748b", marginTop:6, lineHeight:1.6 }}>Auto-generated from 8 profiled tables · 59.9K records · 12 relationships · 193 quality contracts.</p>
      </div>

      {/* Health score row */}
      <div style={{ display:"grid", gridTemplateColumns:"auto 1fr 1fr 1fr", gap:16, marginBottom:28, alignItems:"center" }}>
        {/* Donut ring */}
        <div style={{ position:"relative", width:120, height:120, flexShrink:0 }}>
          <div style={{
            width:120, height:120, borderRadius:"50%",
            background:`conic-gradient(#4f46e5 0deg ${health*3.6}deg, #e2e8f0 ${health*3.6}deg 360deg)`,
            display:"flex", alignItems:"center", justifyContent:"center"
          }}>
            <div style={{ width:86, height:86, borderRadius:"50%", background:"#f8fafc", display:"flex", flexDirection:"column", alignItems:"center", justifyContent:"center" }}>
              <span style={{ fontSize:22, fontWeight:800, color:"#0f172a", letterSpacing:"-0.04em", lineHeight:1 }}>{health}%</span>
              <span style={{ fontSize:9, color:"#94a3b8", fontWeight:600, textTransform:"uppercase", letterSpacing:"0.06em" }}>health</span>
            </div>
          </div>
          {health > D_I.insightsData.healthScore && (
            <div style={{ position:"absolute", top:-4, right:-4, width:20, height:20, borderRadius:"50%", background:"#16a34a", display:"flex", alignItems:"center", justifyContent:"center" }}>
              <span style={{ fontSize:10, color:"#fff" }}>↑</span>
            </div>
          )}
        </div>

        {/* Metric tiles */}
        {[
          { label:"Completeness", value:"87.3%", sub:"90 columns", color:"#16a34a", bg:"#f0fdf4", border:"#bbf7d0" },
          { label:"Quality",      value:"94.1%", sub:"193/193 passing", color:"#16a34a", bg:"#f0fdf4", border:"#bbf7d0" },
          { label:"Catalog",      value:`${Math.min(99, 72 + confirmed*4)}%`, sub:"confidence", color: confirmed>0 ? "#16a34a" : "#d97706", bg: confirmed>0 ? "#f0fdf4" : "#fffbeb", border: confirmed>0 ? "#bbf7d0" : "#fde68a" },
        ].map(m => (
          <div key={m.label} style={{ padding:"16px 18px", background:m.bg, border:`1px solid ${m.border}`, borderRadius:12 }}>
            <div style={{ fontSize:11, fontWeight:600, color:m.color, textTransform:"uppercase", letterSpacing:"0.07em", marginBottom:4 }}>{m.label}</div>
            <div style={{ fontSize:28, fontWeight:800, color:"#0f172a", letterSpacing:"-0.04em", lineHeight:1 }}>{m.value}</div>
            <div style={{ fontSize:11, color:m.color, marginTop:4 }}>{m.sub}</div>
          </div>
        ))}
      </div>

      {/* Key findings */}
      <div style={{ marginBottom:28 }}>
        <SectionLabel>Key findings</SectionLabel>
        <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:12 }}>
          {ins.keyFindings.map(f => {
            const colors = { error:["#fef2f2","#dc2626","#fecaca"], warning:["#fffbeb","#d97706","#fde68a"], info:["#eff6ff","#2563eb","#dbeafe"], success:["#f0fdf4","#16a34a","#bbf7d0"] };
            const [bg, fg, border] = colors[f.type] || colors.info;
            return (
              <div key={f.id} style={{ padding:"16px 18px", background:bg, border:`1px solid ${border}`, borderRadius:12 }}>
                <div style={{ display:"flex", alignItems:"flex-start", gap:10, marginBottom:8 }}>
                  <div style={{ width:28, height:28, borderRadius:8, background:fg, display:"flex", alignItems:"center", justifyContent:"center", flexShrink:0 }}>
                    <span style={{ color:"#fff", fontSize:14 }}>{f.icon}</span>
                  </div>
                  <div style={{ fontWeight:600, fontSize:13, color:"#0f172a", lineHeight:1.3 }}>{f.title}</div>
                </div>
                <p style={{ fontSize:12, color:"#475569", lineHeight:1.6, margin:"0 0 10px" }}>{f.detail}</p>
                <div style={{ display:"flex", alignItems:"center", justifyContent:"space-between" }}>
                  <span style={{ fontSize:10, color:fg, fontFamily:"'DM Mono',monospace", background:`${fg}18`, padding:"2px 8px", borderRadius:4 }}>{f.table}</span>
                  <button style={{ fontSize:11, color:fg, background:"none", border:"none", cursor:"pointer", fontFamily:"inherit" }}>{f.action} →</button>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Anomaly detector + Zone health side by side */}
      <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:20, marginBottom:28 }}>
        {/* Anomalies */}
        <PanelCard style={{ padding:"18px 20px" }}>
          <div style={{ display:"flex", alignItems:"center", gap:8, marginBottom:14 }}>
            <div style={{ width:8, height:8, borderRadius:"50%", background:"#dc2626", animation:"pulse 2s infinite" }} />
            <SectionLabel style={{ margin:0 }}>Anomalies detected</SectionLabel>
          </div>
          {ins.anomalies.map((a, i) => (
            <div key={i} style={{ display:"flex", alignItems:"flex-start", gap:10, paddingBottom: i<ins.anomalies.length-1?12:0, marginBottom: i<ins.anomalies.length-1?12:0, borderBottom: i<ins.anomalies.length-1?"1px solid #f1f5f9":"none" }}>
              <div style={{ width:6, height:6, borderRadius:"50%", flexShrink:0, marginTop:5, background: a.severity==="high"?"#dc2626":"#d97706" }} />
              <div style={{ flex:1 }}>
                <div style={{ fontSize:12, fontWeight:600, color:"#0f172a" }}>{a.sensor}</div>
                <div style={{ fontSize:11, color:"#64748b", marginTop:2 }}>{a.value}</div>
                <div style={{ fontSize:10, color:"#94a3b8", marginTop:2, fontFamily:"'DM Mono',monospace" }}>{a.zone}</div>
              </div>
              <span style={{ fontSize:9, fontWeight:700, padding:"2px 7px", borderRadius:4, flexShrink:0, background: a.severity==="high"?"#fef2f2":"#fffbeb", color: a.severity==="high"?"#dc2626":"#d97706", textTransform:"uppercase" }}>{a.severity}</span>
            </div>
          ))}
        </PanelCard>

        {/* Zone health bar chart */}
        <PanelCard style={{ padding:"18px 20px" }}>
          <SectionLabel>Zone air quality score</SectionLabel>
          <div>
            {ins.zoneScores.map(z => (
              <div key={z.zone} style={{ display:"flex", alignItems:"center", gap:10, marginBottom:10 }}>
                <div style={{ width:120, fontSize:11, color:"#475569", textAlign:"right", flexShrink:0, lineHeight:1.3 }}>{z.zone}</div>
                <div style={{ flex:1, height:20, background:"#f1f5f9", borderRadius:4, overflow:"hidden" }}>
                  <div style={{ height:"100%", width:`${z.score}%`, background:z.color, borderRadius:4, transition:"width 0.5s", display:"flex", alignItems:"center", justifyContent:"flex-end", paddingRight:6 }}>
                    <span style={{ fontSize:10, color:"#fff", fontWeight:700 }}>{z.score}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </PanelCard>
      </div>

      {/* PM2.5 trend */}
      <PanelCard style={{ padding:"18px 20px", marginBottom:28 }}>
        <SectionLabel>PM2.5 trend — last 6 months (avg μg/m³)</SectionLabel>
        <div style={{ display:"flex", alignItems:"flex-end", gap:12, height:80 }}>
          {ins.trends.map((t, i) => {
            const maxVal = Math.max(...ins.trends.map(x => x.pm25));
            const pct = t.pm25 / maxVal;
            const isHigh = t.pm25 > 20;
            return (
              <div key={t.month} style={{ flex:1, display:"flex", flexDirection:"column", alignItems:"center", gap:4 }}>
                <span style={{ fontSize:10, color: isHigh?"#dc2626":"#64748b", fontWeight: isHigh?700:400 }}>{t.pm25}</span>
                <div style={{ width:"100%", background: isHigh?"#fee2e2":"#e0e7ff", borderRadius:"3px 3px 0 0", height:`${pct*60}px`, minHeight:4, transition:"height 0.5s" }}>
                  <div style={{ height:"100%", background: isHigh?"#dc2626":"#4f46e5", borderRadius:"3px 3px 0 0", opacity:0.8 }} />
                </div>
                <span style={{ fontSize:10, color:"#94a3b8" }}>{t.month}</span>
              </div>
            );
          })}
        </div>
        <div style={{ fontSize:11, color:"#94a3b8", marginTop:12 }}>Dec spike correlates with Industrial North sensor cluster — 14 anomalous readings recorded.</div>
      </PanelCard>

      {/* Did you know */}
      <div style={{ marginBottom:24 }}>
        <SectionLabel>Did you know?</SectionLabel>
        <div style={{ display:"grid", gridTemplateColumns:"repeat(4,1fr)", gap:12 }}>
          {ins.didYouKnow.map((f, i) => (
            <div key={i} style={{ padding:"16px 16px", background:"#fff", border:"1px solid #e2e8f0", borderRadius:12, textAlign:"center" }}>
              <div style={{ fontSize:24, fontWeight:800, color:"#4f46e5", letterSpacing:"-0.04em", marginBottom:6 }}>{f.stat}</div>
              <div style={{ fontSize:12, fontWeight:600, color:"#0f172a", marginBottom:4 }}>{f.label}</div>
              <div style={{ fontSize:11, color:"#94a3b8", lineHeight:1.4 }}>{f.sub}</div>
            </div>
          ))}
        </div>
      </div>

      {/* Quality contracts summary */}
      <PanelCard style={{ padding:"18px 20px" }}>
        <div style={{ display:"flex", alignItems:"center", justifyContent:"space-between", marginBottom:12 }}>
          <SectionLabel style={{ margin:0 }}>Quality contracts</SectionLabel>
          <span style={{ fontSize:12, color:"#16a34a", fontWeight:600 }}>193 / 193 passing</span>
        </div>
        <div style={{ display:"flex", gap:8, flexWrap:"wrap" }}>
          {[
            { table:"readings",    count:82, status:"pass" },
            { table:"incidents",   count:48, status:"pass" },
            { table:"zones",       count:18, status:"pass" },
            { table:"sites",       count:24, status:"pass" },
            { table:"sensors",     count:12, status:"pass" },
            { table:"inspections", count:6,  status:"pass" },
            { table:"complaints",  count:2,  status:"pass" },
            { table:"programs",    count:1,  status:"pass" },
          ].map(c => (
            <div key={c.table} style={{ padding:"6px 12px", background:"#f0fdf4", border:"1px solid #bbf7d0", borderRadius:20, display:"flex", alignItems:"center", gap:6 }}>
              <div style={{ width:5, height:5, borderRadius:"50%", background:"#16a34a" }} />
              <span style={{ fontSize:11, fontFamily:"'DM Mono',monospace", color:"#166534" }}>{c.table}</span>
              <span style={{ fontSize:10, color:"#4ade80" }}>·</span>
              <span style={{ fontSize:11, color:"#166534", fontWeight:600 }}>{c.count}</span>
            </div>
          ))}
        </div>
      </PanelCard>
    </div>
  );
}

Object.assign(window, { AInsights });
