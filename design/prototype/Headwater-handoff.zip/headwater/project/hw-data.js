// hw-data.js — Headwater design prototype data

window.HW = {
  project: { name: "Environmental Health DB", maturity: "modeled", score: 0.8 },

  queue: [
    { id:1, type:"model", label:"mart_incidents_by_zone",          priority:"blocking", note:"Joins incidents + zones · 3 generated assumptions" },
    { id:2, type:"model", label:"mart_aqi_trends",                 priority:"blocking", note:"Time-series rollup · seasonal pattern detected" },
    { id:3, type:"model", label:"mart_compliance_summary",         priority:"blocking", note:"Aggregates inspections + incidents by zone" },
    { id:4, type:"dict",  label:"readings.sensor_calibration_offset", priority:"warning", note:"Auto-description: confidence 0.41 — below threshold" },
    { id:5, type:"dict",  label:"incidents.severity_tier",         priority:"warning",  note:"3 distinct values — no semantic match found" },
  ],

  pipeline: [
    { key:"discovery",  label:"Discovery",  status:"complete", detail:"8 tables · 59.9K rows" },
    { key:"dictionary", label:"Dictionary", status:"active",   detail:"2 pending" },
    { key:"models",     label:"Models",     status:"active",   detail:"3 pending" },
    { key:"quality",    label:"Quality",    status:"complete", detail:"193/193 passing" },
    { key:"explore",    label:"Explore",    status:"complete", detail:"" },
  ],

  tables: [
    { name:"zones",       rows:25,    domain:"Geographic",    status:"documented" },
    { name:"sites",       rows:500,   domain:"Operational",   status:"documented" },
    { name:"sensors",     rows:832,   domain:"Operational",   status:"documented" },
    { name:"readings",    rows:49302, domain:"Environmental", status:"documented" },
    { name:"inspections", rows:1243,  domain:"Compliance",    status:"documented" },
    { name:"incidents",   rows:5000,  domain:"Compliance",    status:"profiled" },
    { name:"complaints",  rows:3000,  domain:"Compliance",    status:"profiled" },
    { name:"programs",    rows:10,    domain:"Environmental", status:"documented" },
  ],

  relationships: [
    { from:"readings",    fromCol:"sensor_id",  to:"sensors",     toCol:"sensor_id",  integrity:1.00 },
    { from:"sensors",     fromCol:"site_id",    to:"sites",       toCol:"site_id",    integrity:0.99 },
    { from:"sites",       fromCol:"zone_id",    to:"zones",       toCol:"zone_id",    integrity:1.00 },
    { from:"incidents",   fromCol:"zone_id",    to:"zones",       toCol:"zone_id",    integrity:1.00 },
    { from:"incidents",   fromCol:"site_id",    to:"sites",       toCol:"site_id",    integrity:0.96 },
    { from:"inspections", fromCol:"site_id",    to:"sites",       toCol:"site_id",    integrity:1.00 },
    { from:"complaints",  fromCol:"zone_id",    to:"zones",       toCol:"zone_id",    integrity:0.98 },
    { from:"programs",    fromCol:"zone_id",    to:"zones",       toCol:"zone_id",    integrity:1.00 },
  ],

  profiles: {
    readings: {
      rows:49302, domain:"Environmental",
      tableDesc: "Core measurement table. Each row is a single pollutant reading from a sensor at a point in time. Primary source for AQI calculations, trend analysis, and environmental compliance reporting.",
      columns:[
        { name:"reading_id",  type:"integer",   pk:true,       null_pct:0,    cardinality:49302,
          llmDesc:"Unique surrogate key for each sensor reading event. Auto-incremented. Used as the primary join target for quality annotations and audit records." },
        { name:"sensor_id",   type:"integer",   fk:"sensors",  null_pct:0,    cardinality:832,
          llmDesc:"Foreign key to the sensors table. Identifies which physical sensor produced this reading. Each sensor is associated with a specific site and measures one pollutant type." },
        { name:"timestamp",   type:"timestamp",                null_pct:0.2,  cardinality:48907,
          llmDesc:"UTC timestamp when the reading was recorded. The 0.2% null rate corresponds to sensor communication failures during network outages. Critical for time-series aggregation and trend analysis." },
        { name:"pm25_value",  type:"float",                    null_pct:2.1,  min:0.2,   p50:12.4,  p95:68.2,  max:247.1,
          llmDesc:"Fine particulate matter (PM2.5) concentration in μg/m³. EPA annual standard: 12 μg/m³. 24-hour standard: 35 μg/m³. Values above 150 are classified as 'Unhealthy'. The 2.1% null rate suggests intermittent sensor failures — not systematic." },
        { name:"ozone_level", type:"float",                    null_pct:1.8,  min:0.001, p50:0.048, p95:0.178, max:0.412,
          llmDesc:"Ground-level ozone concentration in parts per million (ppm). EPA 8-hour standard: 0.070 ppm. Elevated ozone causes respiratory issues and crop damage. Strongly correlated with temperature and solar radiation." },
        { name:"temperature", type:"float",                    null_pct:0.4,  min:14.2,  p50:68.4,  p95:91.2,  max:108.3,
          llmDesc:"Ambient air temperature in °F at the sensor location. Used to normalize PM2.5 readings — high humidity and temperature affect hygroscopic growth of particles, inflating apparent PM2.5 values." },
        { name:"humidity",    type:"float",                    null_pct:0.6,  min:8,     p50:65,    p95:89,    max:98,
          llmDesc:"Relative humidity percentage at the sensor at time of reading. High humidity (>80%) can cause sensor over-reading of PM2.5 due to water absorption by particles. Applied in quality_flag assignment logic." },
        { name:"quality_flag",type:"varchar",                  null_pct:0,    cardinality:4, top_values:["good","moderate","unhealthy_sg","hazardous"],
          llmDesc:"EPA AQI-derived data quality classification: good (0–12 μg/m³), moderate (12.1–35.4), unhealthy_sg (35.5–55.4), hazardous (>150.4). Assigned by automated QA pipeline. Used to filter readings for public-facing dashboards." },
      ]
    },
    incidents: {
      rows:5000, domain:"Compliance",
      tableDesc: "Recorded environmental incidents — ranging from citizen complaints to automated sensor alerts. Core table for compliance tracking and regulatory reporting. Note: 23% of rows have null severity_tier, indicating a data entry gap in the upstream reporting system.",
      columns:[
        { name:"incident_id",    type:"integer", pk:true,       null_pct:0,    cardinality:5000,
          llmDesc:"Unique identifier for each environmental incident record. Auto-incremented by the reporting system." },
        { name:"zone_id",        type:"integer", fk:"zones",    null_pct:0,    cardinality:25,
          llmDesc:"Geographic zone where the incident occurred. All 25 zones are referenced — 100% referential integrity. Used for geographic aggregation in compliance summaries." },
        { name:"site_id",        type:"integer", fk:"sites",    null_pct:4.2,  cardinality:412,
          llmDesc:"Specific facility or location associated with the incident. 4.2% null for incidents that occurred in a zone but could not be pinned to a specific site (e.g., mobile sources, area emissions)." },
        { name:"incident_date",  type:"timestamp",              null_pct:0,    cardinality:1089,
          llmDesc:"Date and time the incident was reported or first detected. Used for trend analysis, seasonal pattern detection, and regulatory response time calculations." },
        { name:"severity_tier",  type:"varchar",                null_pct:23.1, cardinality:3, top_values:["low","medium","high"],
          llmDesc:"⚠️ Categorical severity classification: low, medium, high. Currently 23% null — a significant data quality gap. Likely caused by manual review backlog in the upstream reporting portal. Recommend investigation and remediation before using this field in compliance models." },
        { name:"severity_score", type:"float",                  null_pct:23.1, min:0.1,  p50:3.4,  p95:8.7,  max:10.0,
          llmDesc:"Numeric severity score (0–10) assigned by automated classification model. Null exactly when severity_tier is null — both fields share the same data entry gap. p50 of 3.4 suggests most incidents are low-to-medium severity." },
        { name:"resolution_days",type:"integer",                null_pct:31.4, min:0,    p50:8,    p95:47,   max:182,
          llmDesc:"Calendar days from incident report to resolution. 31.4% null for open/unresolved incidents. High variance (σ=18.4) indicates inconsistent response times. 921 incidents open >30 days — potential compliance risk." },
        { name:"reported_by",    type:"varchar",                null_pct:0,    cardinality:3, top_values:["citizen","agency","automated"],
          llmDesc:"Source channel of the incident report. citizen: public complaint portal. agency: environmental authority direct entry. automated: triggered by sensor threshold breach. Distribution informs response time benchmarks per channel." },
      ]
    },
    zones: {
      rows:25, domain:"Geographic",
      tableDesc: "Lookup table defining the 25 geographic zones used for spatial aggregation across all compliance, environmental, and operational data. Central hub — 7 of 8 tables reference zone_id.",
      columns:[
        { name:"zone_id",          type:"integer", pk:true,     null_pct:0, cardinality:25,
          llmDesc:"Primary key. Referenced by sites, incidents, complaints, and programs. All foreign keys resolve — 100% referential integrity across the schema." },
        { name:"name",             type:"varchar",              null_pct:0, cardinality:25,
          llmDesc:"Human-readable zone name (e.g., 'Industrial North', 'East Harbor'). Used in all reporting dashboards and public-facing outputs." },
        { name:"region",           type:"varchar",              null_pct:0, cardinality:5,
          llmDesc:"Higher-level regional grouping of zones. 5 distinct regions. Used for roll-up reporting and regulatory jurisdiction mapping." },
        { name:"area_km2",         type:"float",                null_pct:0, min:12.4, p50:38.7, p95:94.2, max:127.3,
          llmDesc:"Zone area in square kilometers. Used to normalize incident and complaint counts into per-km² density metrics for fair comparison across zones of different sizes." },
        { name:"population",       type:"integer",              null_pct:8.0, min:1240, p50:42800, p95:118000, max:231500,
          llmDesc:"Estimated residential population within the zone. 8% null for unpopulated industrial zones. Used for environmental justice analysis — per-capita exposure calculations." },
        { name:"industrial_index", type:"float",                null_pct:0, min:0.02, p50:0.31, p95:0.78, max:0.97,
          llmDesc:"Composite industrial activity index (0–1) derived from permitted facility counts and production volumes. Higher values correlate strongly with PM2.5 readings and incident frequency." },
      ]
    },
    sensors: {
      rows:832, domain:"Operational",
      tableDesc: "Registry of all active and decommissioned environmental sensors. Each sensor is deployed at a specific site and monitors one pollutant type. Source of all readings in the readings table.",
      columns:[
        { name:"sensor_id",   type:"integer", pk:true,         null_pct:0, cardinality:832,
          llmDesc:"Primary key. Referenced by all 49,302 readings rows." },
        { name:"site_id",     type:"integer", fk:"sites",      null_pct:0, cardinality:500,
          llmDesc:"Foreign key to sites. 99% referential integrity — 1% of sensors reference decommissioned sites not yet removed from the registry." },
        { name:"sensor_type", type:"varchar",                  null_pct:0, cardinality:4, top_values:["PM2.5","ozone","NOx","temp"],
          llmDesc:"Type of pollutant or environmental parameter this sensor measures. PM2.5 sensors are most numerous (38%). Determines how readings should be interpreted and which EPA standards apply." },
        { name:"installed_at",type:"timestamp",                null_pct:0, cardinality:603,
          llmDesc:"Date the sensor was deployed and activated. Used to calculate sensor age, which correlates with calibration drift risk." },
        { name:"is_active",   type:"boolean",                  null_pct:0, cardinality:2,
          llmDesc:"Whether the sensor is currently operational. Deactivated sensors (is_active=false) still have historical readings and should be included in trend analysis." },
        { name:"last_reading",type:"timestamp",                null_pct:2.8, cardinality:712,
          llmDesc:"Timestamp of the most recent reading from this sensor. 2.8% null for sensors that have never successfully transmitted data — likely installation failures." },
      ]
    },
    inspections: {
      rows:1243, domain:"Compliance",
      tableDesc: "Regulatory inspections of facilities and sites. Each row is a single inspection event with a score and outcome. Used to identify non-compliant sites and track remediation progress.",
      columns:[
        { name:"inspection_id", type:"integer", pk:true,       null_pct:0, cardinality:1243,
          llmDesc:"Unique identifier for each inspection record." },
        { name:"site_id",       type:"integer", fk:"sites",    null_pct:0, cardinality:487,
          llmDesc:"Foreign key to the inspected facility. 100% referential integrity. 487 of 500 sites have been inspected at least once." },
        { name:"inspected_at",  type:"timestamp",              null_pct:0, cardinality:891,
          llmDesc:"Date and time the inspection was conducted. Multiple inspections per site are common — average 2.5 inspections per inspected site." },
        { name:"score",         type:"float",                  null_pct:0, min:1.2, p50:6.8, p95:9.4, max:10.0,
          llmDesc:"Regulatory compliance score from 0–10. Sites below 5.0 are flagged for mandatory remediation. 14 sites currently below threshold. Industrial sites average 5.2 vs. 8.1 for municipal sites." },
        { name:"outcome",       type:"varchar",                null_pct:0, cardinality:3, top_values:["pass","conditional","fail"],
          llmDesc:"Categorical inspection outcome. pass: score ≥ 7.0. conditional: 5.0–6.9. fail: < 5.0. Fail outcomes trigger a 90-day remediation window." },
      ]
    },
    complaints: {
      rows:3000, domain:"Compliance",
      tableDesc: "Citizen-submitted environmental complaints via the public reporting portal. Captures public perception of environmental issues and complements sensor-based monitoring.",
      columns:[
        { name:"complaint_id", type:"integer", pk:true,        null_pct:0, cardinality:3000,
          llmDesc:"Unique identifier for each complaint submission." },
        { name:"zone_id",      type:"integer", fk:"zones",     null_pct:1.7, cardinality:24,
          llmDesc:"Zone where the complaint originated. 98% referential integrity. 1.7% null for complaints submitted without location data." },
        { name:"complaint_date",type:"timestamp",              null_pct:0, cardinality:874,
          llmDesc:"Submission date of the complaint. Strong correlation with PM2.5 spike events — 72% of hazardous-air-quality days see complaint volume 2.8× baseline." },
        { name:"category",     type:"varchar",                 null_pct:0, cardinality:5, top_values:["air quality","odor","noise","dust","other"],
          llmDesc:"Complaint category. Air quality is the dominant category (44%), followed by odor (28%). Noise and dust complaints are strongly site-specific." },
        { name:"status",       type:"varchar",                 null_pct:0, cardinality:3, top_values:["open","investigating","closed"],
          llmDesc:"Current processing status. 18% remain open. Average time to close: 14 days. Status transitions are timestamped in the audit log." },
      ]
    },
    programs: {
      rows:10, domain:"Environmental",
      tableDesc: "Intervention and remediation programs operating within zones. Small lookup table — 10 active programs targeting air quality improvement and compliance.",
      columns:[
        { name:"program_id",   type:"integer", pk:true,        null_pct:0, cardinality:10,
          llmDesc:"Primary key for intervention programs." },
        { name:"zone_id",      type:"integer", fk:"zones",     null_pct:0, cardinality:8,
          llmDesc:"Zone where the program operates. 8 of 25 zones have active programs — concentrated in high-industrial-index zones." },
        { name:"name",         type:"varchar",                 null_pct:0, cardinality:10,
          llmDesc:"Program name (e.g., 'Industrial North Emission Reduction', 'East Harbor Air Quality Initiative')." },
        { name:"start_date",   type:"timestamp",               null_pct:0, cardinality:10,
          llmDesc:"Program launch date. Use with readings data to assess whether PM2.5 levels declined after program start in the associated zone." },
        { name:"budget_usd",   type:"integer",                 null_pct:0, min:50000, p50:280000, p95:890000, max:1200000,
          llmDesc:"Annual program budget in USD. Budget correlates moderately with program effectiveness (r=0.61)." },
      ]
    },
    sites: {
      rows:500, domain:"Operational",
      tableDesc: "Registry of monitored facilities and measurement sites across all zones. Central operational entity — sensors are deployed here, inspections happen here, and incidents are attributed here.",
      columns:[
        { name:"site_id",      type:"integer", pk:true,        null_pct:0, cardinality:500,
          llmDesc:"Primary key. Referenced by sensors (832 rows), inspections (1,243 rows), and incidents (4,790 non-null rows)." },
        { name:"zone_id",      type:"integer", fk:"zones",     null_pct:0, cardinality:25,
          llmDesc:"Zone this site belongs to. 100% referential integrity. Used as the primary geographic aggregation path: readings → sensors → sites → zones." },
        { name:"name",         type:"varchar",                 null_pct:0, cardinality:500,
          llmDesc:"Facility or site name. Used in inspection reports and public disclosures." },
        { name:"site_type",    type:"varchar",                 null_pct:0, cardinality:4, top_values:["industrial","municipal","monitoring","residential"],
          llmDesc:"Classification of the site. Industrial sites (42%) have significantly higher incident rates and lower inspection scores than municipal (31%) or monitoring-only (18%) sites." },
        { name:"is_regulated", type:"boolean",                 null_pct:0, cardinality:2,
          llmDesc:"Whether the site is subject to mandatory environmental reporting requirements. Regulated sites (67%) must file quarterly reports with the state environmental agency." },
      ]
    },
  },

  sampleData: {
    table: "readings",
    columns: ["reading_id","sensor_id","timestamp","pm25_value","ozone_level","temperature","humidity","quality_flag"],
    rows: [
      [1001, 42, "2023-01-15 08:22", 12.4,  0.048, 62.1, 71, "good"],
      [1002, 17, "2023-01-15 08:25", 8.2,   0.031, 58.4, 74, "good"],
      [1003, 89, "2023-01-15 08:27", null,  0.055, 71.2, 68, null],
      [1004, 42, "2023-01-15 08:30", 156.3, 0.187, 63.0, 69, "hazardous"],
      [1005, 23, "2023-01-15 08:31", 22.1,  0.062, 66.8, 72, "moderate"],
      [1006, 67, "2023-01-15 08:33", 7.8,   0.029, 59.1, 75, "good"],
      [1007, 11, "2023-01-15 08:35", 31.4,  0.091, 68.3, 67, "unhealthy_sg"],
      [1008, 42, "2023-01-15 08:38", 14.1,  0.051, 62.8, 70, "good"],
      [1009, 55, "2023-01-15 08:40", 9.3,   0.038, 61.4, 73, "good"],
      [1010, 17, "2023-01-15 08:42", null,  null,  null, null, null],
    ]
  },

  queryResults: {
    default: {
      columns:["reading_id","sensor_id","timestamp","pm25_value","quality_flag"],
      rows:[
        [1001,42,"2023-01-15 08:22",12.4,"good"],[1002,17,"2023-01-15 08:25",8.2,"good"],
        [1003,89,"2023-01-15 08:27",null,null],[1004,42,"2023-01-15 08:30",156.3,"hazardous"],
        [1005,23,"2023-01-15 08:31",22.1,"moderate"],[1006,67,"2023-01-15 08:33",7.8,"good"],
        [1007,11,"2023-01-15 08:35",31.4,"unhealthy_sg"],[1008,42,"2023-01-15 08:38",14.1,"good"],
        [1009,55,"2023-01-15 08:40",9.3,"good"],[1010,17,"2023-01-15 08:42",null,null],
      ]
    },
    zones: {
      columns:["zone_id","name","region","population","industrial_index"],
      rows:[
        [1,"Industrial North","North",14200,0.94],[2,"East Harbor","East",28400,0.71],
        [3,"Downtown Core","Central",81200,0.32],[4,"Westside Residential","West",62400,0.09],
        [5,"South District","South",44800,0.51],[6,"River District","Central",31200,0.18],
      ]
    },
    incidents: {
      columns:["incident_id","zone_id","incident_date","severity_tier","resolution_days"],
      rows:[
        [1001,1,"2023-03-12 14:22","high",42],[1002,2,"2023-03-14 09:10","medium",8],
        [1003,1,"2023-03-15 11:30",null,null],[1004,5,"2023-03-16 16:45","low",3],
        [1005,3,"2023-03-17 08:00","medium",12],[1006,1,"2023-03-18 13:20",null,null],
      ]
    }
  },

  insightsData: {
    healthScore: 87,
    keyFindings: [
      { id:"kf1", type:"error",   icon:"⚠", title:"23% severity data missing", detail:"incidents.severity_tier is null for 1,150 of 5,000 rows. Likely upstream reporting gap — affects compliance model accuracy.", table:"incidents", action:"Review source" },
      { id:"kf2", type:"warning", icon:"↑", title:"PM2.5 correlates with complaints", detail:"Zones with avg PM2.5 > 35 μg/m³ generate 2.8× more complaints per month. Strong signal for resource allocation.", table:"readings", action:"View correlation" },
      { id:"kf3", type:"info",    icon:"⏱", title:"18% of incidents unresolved >30d", detail:"921 of 5,000 incidents remain open after 30 days. Concentrated in Industrial North (zone 1) and East Harbor (zone 2).", table:"incidents", action:"Explore" },
      { id:"kf4", type:"success", icon:"✓", title:"100% schema integrity on zones", detail:"All 7 foreign keys referencing zones.zone_id resolve perfectly. Zones table is a reliable hub for cross-domain analysis.", table:"zones", action:"View model" },
    ],
    anomalies: [
      { sensor:"Sensor #89",   value:"14 readings > 3σ above baseline", zone:"Industrial North", severity:"high" },
      { sensor:"Sensor #204",  value:"11 anomalous readings detected",  zone:"East Harbor",      severity:"high" },
      { sensor:"Sensor #17",   value:"8 readings with null quality_flag", zone:"Downtown Core",  severity:"medium" },
      { sensor:"Zone 1 avg",   value:"PM2.5 = 47.3 μg/m³ (3.8× median)", zone:"Industrial North",severity:"high" },
      { sensor:"Resolution",   value:"182-day outlier incident (#4471)", zone:"South District",  severity:"medium" },
    ],
    didYouKnow: [
      { stat:"r = 0.72",  label:"PM2.5 × complaint correlation", sub:"Strongest predictor of public complaints in the dataset" },
      { stat:"3.8×",      label:"Industrial North PM2.5 vs. median", sub:"Highest-polluting zone is nearly 4× the zone median" },
      { stat:"2.5 insp.", label:"Average inspections per site", sub:"Most-inspected sites are in Compliance zones" },
      { stat:"78%",       label:"Readings classified 'good'", sub:"Despite anomalies, most air quality is within safe ranges" },
    ],
    trends: [
      { month:"Aug", pm25:18.2 }, { month:"Sep", pm25:14.1 }, { month:"Oct", pm25:12.8 },
      { month:"Nov", pm25:19.4 }, { month:"Dec", pm25:22.7 }, { month:"Jan", pm25:16.9 },
    ],
    zoneScores: [
      { zone:"Industrial North", score:34, color:"#dc2626" },
      { zone:"East Harbor",      score:58, color:"#d97706" },
      { zone:"South District",   score:71, color:"#d97706" },
      { zone:"Downtown Core",    score:82, color:"#16a34a" },
      { zone:"Westside Res.",    score:91, color:"#16a34a" },
      { zone:"River District",   score:94, color:"#16a34a" },
    ],
  },

  activity: [
    { msg:"Discovery complete · 8 tables, 59.9K rows, 90 columns profiled",  time:"2h ago", type:"success" },
    { msg:"193 quality contracts generated and baselined",                    time:"2h ago", type:"success" },
    { msg:"3 mart model proposals generated — review required",               time:"2h ago", type:"info" },
    { msg:"Semantic enrichment: 2 low-confidence columns flagged",            time:"2h ago", type:"warning" },
    { msg:"FK detection: 12 relationships confirmed (8 high, 4 partial)",     time:"2h ago", type:"info" },
  ],

  domainColors: {
    Environmental: "#4f46e5",
    Operational:   "#0891b2",
    Compliance:    "#d97706",
    Geographic:    "#16a34a",
  },
};
