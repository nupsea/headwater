// Headwater 2 — Readiness ledger (stage 4) + Answer & Share (stage 5).
// Answer now surfaces MANY questions; user picks one to draft / run / chart.

// ─── Readiness ──────────────────────────────────────────────────────────────
function HW2Readiness({ project, readiness, onAnswer, onImprove }) {
  const certified = project.trust >= 90;
  return (
    <div style={{ maxWidth: 960, margin: "0 auto", padding: "32px 32px 80px" }}>
      <span style={{
        font: "600 11px 'DM Sans'", color: HW2_COLOR.blue,
        letterSpacing: "0.08em", textTransform: "uppercase",
      }}>Step 4 of 5 · Readiness</span>
      <h2 style={{
        font: "600 26px 'DM Sans'", letterSpacing: "-0.02em",
        color: HW2_COLOR.ink, lineHeight: 1.25, marginTop: 8, marginBottom: 4,
      }}>The verdict.</h2>
      <p style={{ font: "400 14px 'DM Sans'", color: HW2_COLOR.muted, marginBottom: 24, lineHeight: 1.5 }}>
        Scoped to your goal and the questions you&rsquo;re asking. The truth, not a score for its own sake.
      </p>

      <HW2Card style={{ padding: "24px 28px", marginBottom: 18 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 22 }}>
          <HW2TrustRing value={project.trust} size={84} stroke={6} showLabel={false} />
          <div style={{ flex: 1 }}>
            <div style={{ font: "600 11px 'DM Sans'", color: HW2_COLOR.muted, letterSpacing: "0.06em", textTransform: "uppercase", marginBottom: 6 }}>
              Goal-anchored verdict
            </div>
            <p style={{ font: "500 17px 'DM Sans'", color: HW2_COLOR.ink, lineHeight: 1.45, letterSpacing: "-0.01em", textWrap: "pretty" }}>
              {readiness.verdict}
            </p>
          </div>
        </div>
      </HW2Card>

      <div style={{ display: "grid", gap: 10, marginBottom: 24 }}>
        {readiness.buckets.map(b => <ReadinessRow key={b.key} bucket={b} />)}
      </div>

      <div style={{
        padding: "14px 18px", marginBottom: 24,
        background: HW2_COLOR.chip, borderRadius: 10,
        border: `1px solid ${HW2_COLOR.rule2}`,
        font: "400 12px 'DM Sans'", color: HW2_COLOR.ink2, lineHeight: 1.55,
      }}>
        <strong style={{ color: HW2_COLOR.ink }}>The rule:</strong>{" "}
        You can always proceed to Answer. Uncertified output is allowed — it just carries a
        <em> Draft / Uncertified</em> stamp. The trust badge only appears when every bucket clears.
        The badge is sacred.
      </div>

      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", gap: 8 }}>
        <HW2Btn onClick={onImprove}>← Improve readiness</HW2Btn>
        <HW2Btn kind="accent" size="lg" onClick={onAnswer}>
          {certified ? "Generate certified answer" : "Go to Answer →"}
        </HW2Btn>
      </div>
    </div>
  );
}

function ReadinessRow({ bucket }) {
  const [open, setOpen] = React.useState(false);
  const tones = {
    good:  { color: HW2_COLOR.good, bg: HW2_COLOR.goodSoft, sym: "✓" },
    warn:  { color: HW2_COLOR.warn, bg: HW2_COLOR.warnSoft, sym: "!" },
    muted: { color: HW2_COLOR.muted, bg: HW2_COLOR.chip,    sym: "○" },
    bad:   { color: HW2_COLOR.bad,  bg: HW2_COLOR.badSoft,  sym: "△" },
  }[bucket.tone];
  return (
    <div style={{ background: HW2_COLOR.surface, border: `1px solid ${HW2_COLOR.rule}`, borderRadius: 12, overflow: "hidden" }}>
      <button onClick={() => setOpen(v => !v)} style={{
        appearance: "none", background: "transparent", border: "none", cursor: "pointer",
        width: "100%", padding: "14px 18px", textAlign: "left",
        display: "flex", alignItems: "center", gap: 14, fontFamily: "'DM Sans', sans-serif",
      }}>
        <span style={{
          width: 26, height: 26, borderRadius: "50%",
          background: tones.bg, color: tones.color,
          display: "inline-flex", alignItems: "center", justifyContent: "center",
          font: "700 13px 'DM Sans'", flexShrink: 0,
        }}>{tones.sym}</span>
        <span style={{ font: "600 14px 'DM Sans'", color: HW2_COLOR.ink, minWidth: 140 }}>{bucket.label}</span>
        <span style={{ font: "400 13px 'DM Sans'", color: HW2_COLOR.muted, flex: 1, lineHeight: 1.45 }}>
          {bucket.items[0]}
          {bucket.items.length > 1 && <span style={{ color: HW2_COLOR.faint }}> +{bucket.items.length - 1} more</span>}
        </span>
        <span style={{ color: HW2_COLOR.faint, font: "500 11px 'DM Mono'" }}>{open ? "▾" : "▸"}</span>
      </button>
      {open && (
        <div style={{ padding: "0 18px 16px 58px", display: "grid", gap: 8 }}>
          {bucket.items.map((it, i) => (
            <div key={i} style={{
              padding: "10px 14px", background: HW2_COLOR.paper, borderRadius: 8,
              border: `1px solid ${HW2_COLOR.rule}`,
              font: "400 13px 'DM Sans'", color: HW2_COLOR.ink2, lineHeight: 1.5,
              display: "flex", alignItems: "flex-start", gap: 10,
            }}>
              <span style={{ font: "500 12px 'DM Mono'", color: tones.color, marginTop: 1, flexShrink: 0 }}>{tones.sym}</span>
              <span>{it}</span>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

// ─── Answer & Share (multi-question) ────────────────────────────────────────
function HW2Answer({ project, chartData, onCertify, onExportReport }) {
  const questions = project.questions || [];
  const [activeQ, setActiveQ] = React.useState(questions[0]?.id || null);
  const [running, setRunning] = React.useState(false);
  const [view, setView]       = React.useState("chart");
  const [sqlEdit, setSqlEdit] = React.useState(false);
  const [localSql, setLocalSql] = React.useState(() =>
    Object.fromEntries(questions.map(q => [q.id, q.sql || ""]))
  );
  const certified = project.trust >= 90;

  const q = questions.find(x => x.id === activeQ);

  const run = () => {
    setRunning(true);
    setTimeout(() => setRunning(false), 700);
  };

  return (
    <div style={{ maxWidth: 1180, margin: "0 auto", padding: "32px 32px 80px" }}>
      <div style={{ display: "flex", alignItems: "baseline", justifyContent: "space-between", marginBottom: 6 }}>
        <span style={{
          font: "600 11px 'DM Sans'", color: HW2_COLOR.blue,
          letterSpacing: "0.08em", textTransform: "uppercase",
        }}>Step 5 of 5 · Answer & Share</span>
        {certified ? (
          <span style={badgeStyle("good")}>
            <span style={{ width: 6, height: 6, borderRadius: "50%", background: HW2_COLOR.good }} />
            Certified
          </span>
        ) : (
          <span style={badgeStyle("bad")}>
            <span style={{ width: 6, height: 6, borderRadius: "50%", background: HW2_COLOR.bad }} />
            Draft · Uncertified
          </span>
        )}
      </div>
      <h2 style={{
        font: "600 26px 'DM Sans'", letterSpacing: "-0.02em",
        color: HW2_COLOR.ink, lineHeight: 1.25, marginTop: 8, marginBottom: 4,
      }}>Answer your questions.</h2>
      <p style={{ font: "400 14px 'DM Sans'", color: HW2_COLOR.muted, marginBottom: 24, lineHeight: 1.5 }}>
        Each question gets a draft query, grounded in columns Headwater has vouched for.
      </p>

      {/* Empty state */}
      {questions.length === 0 && (
        <HW2Card style={{ textAlign: "center", padding: "60px 24px" }}>
          <div style={{ font: "500 14px 'DM Sans'", color: HW2_COLOR.muted, marginBottom: 12 }}>
            No questions yet. Add some on the Frame step.
          </div>
        </HW2Card>
      )}

      {q && (
        <div style={{ display: "grid", gridTemplateColumns: "260px 1fr", gap: 18 }}>
          {/* Question list sidebar */}
          <aside style={{ display: "flex", flexDirection: "column", gap: 8, alignSelf: "flex-start" }}>
            <div style={{ font: "600 10px 'DM Sans'", color: HW2_COLOR.faint, letterSpacing: "0.08em", textTransform: "uppercase", padding: "0 4px" }}>
              Questions
            </div>
            {questions.map((qq, i) => (
              <QuestionItem key={qq.id} idx={i} q={qq} active={qq.id === activeQ} onClick={() => setActiveQ(qq.id)} />
            ))}
            <button style={{
              appearance: "none", cursor: "pointer",
              background: HW2_COLOR.chip, border: `1px dashed ${HW2_COLOR.rule2}`,
              borderRadius: 8, padding: "9px 12px", textAlign: "left",
              color: HW2_COLOR.muted, font: "500 12px 'DM Sans'",
              fontFamily: "'DM Sans', sans-serif",
            }}>+ Add another question</button>
          </aside>

          {/* Active question content */}
          <div style={{ display: "grid", gap: 16, minWidth: 0 }}>
            {/* Question header */}
            <div>
              <div style={{ font: "500 11px 'DM Mono'", color: HW2_COLOR.faint, marginBottom: 4 }}>
                Question {questions.findIndex(x => x.id === activeQ) + 1}
              </div>
              <h3 style={{ font: "600 20px 'DM Sans'", letterSpacing: "-0.015em", color: HW2_COLOR.ink, lineHeight: 1.3 }}>
                {q.title}
              </h3>
              {q.warning && (
                <div style={{
                  marginTop: 10, padding: "8px 12px",
                  background: HW2_COLOR.warnSoft, borderRadius: 8,
                  font: "500 12px 'DM Sans'", color: HW2_COLOR.warn,
                  display: "inline-flex", alignItems: "center", gap: 6,
                }}>
                  <span style={{ font: "700 12px 'DM Sans'" }}>!</span> {q.warning}
                </div>
              )}
            </div>

            {/* Query card */}
            <HW2Card padded={false}>
              <div style={{
                display: "flex", alignItems: "center", justifyContent: "space-between",
                padding: "10px 14px", borderBottom: `1px solid ${HW2_COLOR.rule}`,
              }}>
                <span style={{ font: "600 12px 'DM Sans'", color: HW2_COLOR.ink }}>Draft query</span>
                <div style={{ display: "flex", gap: 6 }}>
                  {q.vouched.length > 0 && (
                    <HW2Chip tone="good" mono>
                      {q.vouched.length} vouched cols
                    </HW2Chip>
                  )}
                  <HW2Btn size="sm" onClick={() => setSqlEdit(v => !v)}>{sqlEdit ? "Done" : "Edit"}</HW2Btn>
                  <HW2Btn size="sm" kind="accent" onClick={run}>{running ? "Running…" : "▶ Run"}</HW2Btn>
                </div>
              </div>
              {sqlEdit ? (
                <textarea
                  value={localSql[q.id] || ""}
                  onChange={(e) => setLocalSql(p => ({ ...p, [q.id]: e.target.value }))}
                  spellCheck={false}
                  style={{
                    width: "100%", minHeight: 140, padding: "12px 16px",
                    background: HW2_COLOR.paper, border: "none", resize: "vertical",
                    font: "500 12.5px 'DM Mono'", color: HW2_COLOR.ink, lineHeight: 1.55,
                    outline: "none", fontFamily: "'DM Mono', monospace",
                  }}
                />
              ) : (
                <pre style={{
                  margin: 0, padding: "14px 16px",
                  font: "400 12.5px 'DM Mono'", color: HW2_COLOR.ink2, lineHeight: 1.55,
                  background: HW2_COLOR.paper, overflowX: "auto",
                }}>{localSql[q.id] || "-- No query drafted yet."}</pre>
              )}
            </HW2Card>

            {/* Result card */}
            <HW2Card padded={false} style={{ position: "relative" }}>
              <div style={{
                display: "flex", alignItems: "center", justifyContent: "space-between",
                padding: "10px 14px", borderBottom: `1px solid ${HW2_COLOR.rule}`,
              }}>
                <span style={{ font: "600 12px 'DM Sans'", color: HW2_COLOR.ink }}>Result</span>
                <div style={{ display: "inline-flex", gap: 2, padding: 3, background: HW2_COLOR.chip, borderRadius: 7 }}>
                  {["chart", "table"].map(v => (
                    <button key={v} onClick={() => setView(v)} style={{
                      appearance: "none", cursor: "pointer", border: "none",
                      padding: "4px 10px", borderRadius: 5,
                      background: view === v ? "#fff" : "transparent",
                      color: view === v ? HW2_COLOR.ink : HW2_COLOR.muted,
                      font: "500 11px 'DM Sans'", fontFamily: "'DM Sans', sans-serif",
                    }}>{v}</button>
                  ))}
                </div>
              </div>

              {running ? (
                <div style={{ padding: 60, textAlign: "center", color: HW2_COLOR.muted, font: "500 13px 'DM Sans'" }}>
                  Executing…
                </div>
              ) : view === "chart" ? (
                <QChart q={q} chartData={chartData} />
              ) : (
                <QTable q={q} chartData={chartData} />
              )}

              {!certified && view === "chart" && (
                <div style={{
                  position: "absolute", inset: 0, pointerEvents: "none",
                  display: "flex", alignItems: "center", justifyContent: "center",
                }}>
                  <span style={{
                    font: "700 56px 'DM Sans'", color: HW2_COLOR.bad,
                    opacity: 0.07, letterSpacing: "0.15em",
                    transform: "rotate(-12deg)", textTransform: "uppercase",
                  }}>Draft</span>
                </div>
              )}
            </HW2Card>

            {/* Vouched + share / export */}
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
              <HW2Card>
                <div style={{ font: "600 11px 'DM Sans'", color: HW2_COLOR.muted, letterSpacing: "0.06em", textTransform: "uppercase", marginBottom: 8 }}>
                  Vouched columns
                </div>
                {q.vouched.length === 0 ? (
                  <div style={{ font: "400 13px 'DM Sans'", color: HW2_COLOR.faint }}>
                    No columns vouched for this question yet.
                  </div>
                ) : (
                  <div style={{ display: "grid", gap: 6 }}>
                    {q.vouched.map(c => (
                      <div key={c} style={{
                        display: "flex", alignItems: "center", gap: 8,
                        font: "500 13px 'DM Mono'", color: HW2_COLOR.ink2,
                      }}>
                        <span style={{ color: HW2_COLOR.good, font: "700 12px 'DM Sans'" }}>✓</span>
                        {c}
                      </div>
                    ))}
                  </div>
                )}
              </HW2Card>
              <HW2Card>
                <div style={{ font: "600 11px 'DM Sans'", color: HW2_COLOR.muted, letterSpacing: "0.06em", textTransform: "uppercase", marginBottom: 8 }}>
                  Share
                </div>
                <div style={{ display: "grid", gap: 8 }}>
                  <HW2Btn size="md">Save dashboard {certified ? "" : "(as Draft)"}</HW2Btn>
                  <HW2Btn size="md" onClick={onExportReport}>Export audit report (.md)</HW2Btn>
                  <HW2Btn size="md">Export dbt models</HW2Btn>
                  {!certified && (
                    <HW2Btn size="sm" kind="ghost" onClick={onCertify}>
                      Resolve open gaps to certify →
                    </HW2Btn>
                  )}
                </div>
              </HW2Card>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function QuestionItem({ idx, q, active, onClick }) {
  const statusTone = {
    answered: { color: HW2_COLOR.good, bg: HW2_COLOR.goodSoft, label: "Answered" },
    drafted:  { color: HW2_COLOR.blue, bg: HW2_COLOR.blueSoft, label: "Drafted" },
    draft:    { color: HW2_COLOR.muted, bg: HW2_COLOR.chip,    label: "Draft" },
  }[q.status || "draft"];
  return (
    <button onClick={onClick} style={{
      appearance: "none", cursor: "pointer", textAlign: "left",
      background: active ? "#fff" : "transparent",
      border: `1px solid ${active ? HW2_COLOR.blue : HW2_COLOR.rule}`,
      borderRadius: 10, padding: "10px 12px",
      boxShadow: active ? "0 1px 0 rgba(20,20,30,0.02)" : "none",
      fontFamily: "'DM Sans', sans-serif",
    }}>
      <div style={{ font: "500 11px 'DM Mono'", color: HW2_COLOR.faint, marginBottom: 4 }}>Q{idx + 1}</div>
      <div style={{ font: `${active ? 600 : 500} 13px 'DM Sans'`, color: active ? HW2_COLOR.ink : HW2_COLOR.ink2, lineHeight: 1.35, marginBottom: 6 }}>
        {q.title}
      </div>
      <span style={{
        display: "inline-block", padding: "2px 8px", borderRadius: 4,
        background: statusTone.bg, color: statusTone.color,
        font: "700 9px 'DM Sans'", letterSpacing: "0.07em", textTransform: "uppercase",
      }}>{statusTone.label}</span>
    </button>
  );
}

// ─── Per-question chart renderers ───────────────────────────────────────────
function QChart({ q, chartData }) {
  if (q.id === "q1") return <LineChart data={chartData.waitByHour} />;
  if (q.id === "q2") return <BarChart data={chartData.waitByPatientType} unit="min" />;
  if (q.id === "q3") return <BarChart data={chartData.stepDurations} unit="min" tone="amber" />;
  return (
    <div style={{ padding: 56, textAlign: "center", color: HW2_COLOR.muted, font: "500 13px 'DM Sans'" }}>
      No chart drafted yet. Edit the query and run it.
    </div>
  );
}
function QTable({ q, chartData }) {
  let rows = [];
  if (q.id === "q1") rows = chartData.waitByHour.map(d => ({ hour: d.hour, avg_wait_min: d.wait, visits: d.visits }));
  else if (q.id === "q2") rows = chartData.waitByPatientType.map(d => ({ patient_type: d.label, avg_wait_min: d.value, visits: d.n }));
  else if (q.id === "q3") rows = chartData.stepDurations.map(d => ({ activity: d.label, avg_step_min: d.value }));
  if (rows.length === 0) {
    return <div style={{ padding: 40, color: HW2_COLOR.faint, font: "500 13px 'DM Sans'", textAlign: "center" }}>No data.</div>;
  }
  return (
    <div style={{ overflowX: "auto", maxHeight: 320 }}>
      <table style={{ width: "100%", borderCollapse: "collapse", font: "400 12px 'DM Mono'" }}>
        <thead><tr>{Object.keys(rows[0]).map(k => (
          <th key={k} style={{
            padding: "10px 14px", textAlign: "left",
            font: "600 10px 'DM Sans'", color: HW2_COLOR.muted,
            textTransform: "uppercase", letterSpacing: "0.06em",
            borderBottom: `1px solid ${HW2_COLOR.rule}`,
          }}>{k}</th>
        ))}</tr></thead>
        <tbody>
          {rows.map((r, i) => (
            <tr key={i}>{Object.values(r).map((v, j) => (
              <td key={j} style={{
                padding: "8px 14px", color: HW2_COLOR.ink2,
                borderBottom: `1px solid ${HW2_COLOR.rule}`,
              }}>{v}</td>
            ))}</tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

function LineChart({ data }) {
  const w = 540, h = 220, pad = { l: 38, r: 16, t: 16, b: 28 };
  const maxY = Math.max(...data.map(d => d.wait));
  const x = (hour) => pad.l + (hour / 23) * (w - pad.l - pad.r);
  const y = (v) => h - pad.b - (v / maxY) * (h - pad.t - pad.b);
  const path = data.map((d, i) => `${i === 0 ? "M" : "L"} ${x(d.hour).toFixed(1)} ${y(d.wait).toFixed(1)}`).join(" ");
  const area = path + ` L ${x(23).toFixed(1)} ${h - pad.b} L ${x(0).toFixed(1)} ${h - pad.b} Z`;
  const peakIdx = data.reduce((best, d, i) => d.wait > data[best].wait ? i : best, 0);
  return (
    <div style={{ padding: "14px 12px 10px" }}>
      <svg width="100%" viewBox={`0 0 ${w} ${h}`} style={{ display: "block" }}>
        {[0, maxY / 2, maxY].map((v, i) => (
          <g key={i}>
            <line x1={pad.l} x2={w - pad.r} y1={y(v)} y2={y(v)} stroke={HW2_COLOR.rule} strokeWidth="1" />
            <text x={pad.l - 6} y={y(v) + 3} textAnchor="end" style={{ font: "500 10px 'DM Mono'", fill: HW2_COLOR.faint }}>{v.toFixed(0)}m</text>
          </g>
        ))}
        <path d={area} fill={HW2_COLOR.blueSoft} />
        <path d={path} fill="none" stroke={HW2_COLOR.blue} strokeWidth="2" />
        <circle cx={x(data[peakIdx].hour)} cy={y(data[peakIdx].wait)} r="4" fill={HW2_COLOR.blue} />
        <text x={x(data[peakIdx].hour)} y={y(data[peakIdx].wait) - 10} textAnchor="middle" style={{ font: "600 11px 'DM Sans'", fill: HW2_COLOR.blue }}>
          peak {data[peakIdx].wait}m @ {data[peakIdx].hour}:00
        </text>
        {[0, 6, 12, 18, 23].map(h => (
          <text key={h} x={x(h)} y={h === 0 ? 218 : 218} textAnchor="middle" style={{ font: "500 10px 'DM Mono'", fill: HW2_COLOR.muted }}>
            {String(h).padStart(2, "0")}:00
          </text>
        ))}
      </svg>
      <div style={{ font: "400 11px 'DM Sans'", color: HW2_COLOR.muted, textAlign: "center", marginTop: 4 }}>
        Avg wait (minutes) by hour of arrival
      </div>
    </div>
  );
}
function BarChart({ data, unit = "", tone = "blue" }) {
  const max = Math.max(...data.map(d => d.value));
  const color = tone === "amber" ? HW2_COLOR.warn : HW2_COLOR.blue;
  const bg = tone === "amber" ? HW2_COLOR.warnSoft : HW2_COLOR.blueSoft;
  return (
    <div style={{ padding: "16px 22px", display: "grid", gap: 10 }}>
      {data.map(d => (
        <div key={d.label} style={{ display: "flex", alignItems: "center", gap: 14 }}>
          <span style={{ width: 110, font: "500 12px 'DM Mono'", color: HW2_COLOR.ink2 }}>{d.label}</span>
          <div style={{ flex: 1, height: 22, background: bg, borderRadius: 6, position: "relative" }}>
            <div style={{
              position: "absolute", left: 0, top: 0, height: "100%",
              width: `${(d.value / max) * 100}%`, background: color, borderRadius: 6,
              transition: "width 600ms cubic-bezier(0.4,0,0.2,1)",
            }} />
          </div>
          <span style={{ width: 80, textAlign: "right", font: "600 12px 'DM Mono'", color: HW2_COLOR.ink }}>
            {d.value}{unit}
          </span>
        </div>
      ))}
    </div>
  );
}

function badgeStyle(tone) {
  const c = tone === "good"
    ? { bg: HW2_COLOR.goodSoft, fg: HW2_COLOR.good }
    : { bg: HW2_COLOR.badSoft,  fg: HW2_COLOR.bad };
  return {
    display: "inline-flex", alignItems: "center", gap: 6,
    padding: "4px 10px", borderRadius: 4,
    background: c.bg, color: c.fg,
    font: "700 10px 'DM Sans'", letterSpacing: "0.08em", textTransform: "uppercase",
  };
}

Object.assign(window, { HW2Readiness, HW2Answer });
