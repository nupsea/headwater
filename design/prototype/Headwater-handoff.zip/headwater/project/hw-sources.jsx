// hw-sources.jsx — Multi-source connector panel + Briefing mode dashboard

const { useState: useStateS } = React;
const D_S = window.HW;
const { SectionLabel: SL_S, PanelCard: PC_S, Btn: Btn_S } = window;

// ─── Source registry data ────────────────────────────────────────────────────

const SOURCE_TYPES = [
  { id:"postgres",   name:"PostgreSQL",  color:"#336791", glyph:"P",  category:"OLTP" },
  { id:"mysql",      name:"MySQL",       color:"#4479a1", glyph:"M",  category:"OLTP" },
  { id:"snowflake",  name:"Snowflake",   color:"#29b5e8", glyph:"S",  category:"Warehouse" },
  { id:"bigquery",   name:"BigQuery",    color:"#4285f4", glyph:"BQ", category:"Warehouse" },
  { id:"redshift",   name:"Redshift",    color:"#cc2b5e", glyph:"R",  category:"Warehouse" },
  { id:"databricks", name:"Databricks",  color:"#ff3621", glyph:"DB", category:"Lakehouse" },
  { id:"sqlserver",  name:"SQL Server",  color:"#a91d22", glyph:"SQ", category:"OLTP" },
  { id:"duckdb",     name:"DuckDB",      color:"#fff100", glyph:"D",  category:"Embedded", lightGlyph:true },
  { id:"oracle",     name:"Oracle",      color:"#f80000", glyph:"O",  category:"OLTP" },
  { id:"clickhouse", name:"ClickHouse",  color:"#ffcc00", glyph:"CH", category:"OLAP", lightGlyph:true },
  { id:"sqlite",     name:"SQLite",      color:"#003b57", glyph:"SL", category:"Embedded" },
  { id:"trino",      name:"Trino",       color:"#dd00a1", glyph:"T",  category:"Federated" },
];

const CONNECTED_SOURCES = [
  { id:"src-1", type:"postgres",  name:"prod-environmental",  host:"db-prod.us-east.aws", db:"environmental_health", schemas:3, tables:24, rows:"2.4M",  lastSync:"4m ago",  status:"healthy",  drift:0,  health:98 },
  { id:"src-2", type:"snowflake", name:"warehouse-analytics", host:"acme.snowflakecomputing.com", db:"ANALYTICS", schemas:6, tables:142, rows:"840M", lastSync:"22m ago", status:"healthy",  drift:2,  health:94 },
  { id:"src-3", type:"postgres",  name:"compliance-staging",  host:"db-stage.us-east.aws", db:"compliance",       schemas:2, tables:18, rows:"412K", lastSync:"2h ago",  status:"warning", drift:5,  health:81 },
  { id:"src-4", type:"bigquery",  name:"public-epa-mirror",   host:"acme-data:us-central1", db:"epa_mirror",       schemas:1, tables:8,  rows:"12.8M",lastSync:"1h ago",  status:"healthy",  drift:0,  health:96 },
  { id:"src-5", type:"mysql",     name:"legacy-inspections",  host:"legacy.internal:3306", db:"inspections_v2",     schemas:1, tables:6,  rows:"148K", lastSync:"failed",   status:"error",    drift:0,  health:0  },
  { id:"src-6", type:"duckdb",    name:"sandbox-explorer",    host:"local",                db:"sandbox.duckdb",     schemas:1, tables:11, rows:"58K",  lastSync:"yesterday",status:"idle",     drift:0,  health:88 },
];

const CONN_HISTORY = [
  { time:"4m ago",  src:"prod-environmental",  event:"Sync complete · 2 new columns detected on incidents", type:"info" },
  { time:"22m ago", src:"warehouse-analytics", event:"Drift detected · readings.pm25_value distribution shifted 12%", type:"warning" },
  { time:"1h ago",  src:"public-epa-mirror",   event:"Sync complete · 0 schema changes", type:"success" },
  { time:"2h ago",  src:"compliance-staging",  event:"Schema change · 1 column added, 1 column type changed", type:"warning" },
  { time:"3h ago",  src:"legacy-inspections",  event:"Connection failed · authentication timeout", type:"error" },
];

// ─── Sources Page ─────────────────────────────────────────────────────────────

function ASources() {
  const [showAdd, setShowAdd] = useStateS(false);
  const [filter, setFilter] = useStateS("all");
  const [selected, setSelected] = useStateS(null);

  const filtered = filter === "all" ? CONNECTED_SOURCES : CONNECTED_SOURCES.filter(s => s.status === filter);

  const counts = {
    all:      CONNECTED_SOURCES.length,
    healthy:  CONNECTED_SOURCES.filter(s => s.status==="healthy").length,
    warning:  CONNECTED_SOURCES.filter(s => s.status==="warning").length,
    error:    CONNECTED_SOURCES.filter(s => s.status==="error").length,
    idle:     CONNECTED_SOURCES.filter(s => s.status==="idle").length,
  };

  return (
    <div style={{ maxWidth:980 }}>
      {/* Header */}
      <div style={{ display:"flex", alignItems:"flex-start", justifyContent:"space-between", marginBottom:24, gap:16 }}>
        <div>
          <SL_S>Sources</SL_S>
          <h1 style={{ fontSize:24, fontWeight:700, letterSpacing:"-0.03em", color:"#0f172a" }}>Connected data sources</h1>
          <p style={{ fontSize:14, color:"#64748b", marginTop:6, lineHeight:1.6 }}>{CONNECTED_SOURCES.length} sources · {CONNECTED_SOURCES.reduce((a,s)=>a+s.tables,0)} tables · syncing continuously</p>
        </div>
        <Btn_S onClick={() => setShowAdd(true)}>+ Connect source</Btn_S>
      </div>

      {/* Status summary bar */}
      <div style={{ display:"flex", gap:8, marginBottom:18, padding:"12px 14px", background:"#fff", border:"1px solid #e2e8f0", borderRadius:10, alignItems:"center" }}>
        {[
          { key:"all",     label:"All",     count:counts.all,     color:"#64748b" },
          { key:"healthy", label:"Healthy", count:counts.healthy, color:"#16a34a" },
          { key:"warning", label:"Drift",   count:counts.warning, color:"#d97706" },
          { key:"error",   label:"Errors",  count:counts.error,   color:"#dc2626" },
          { key:"idle",    label:"Idle",    count:counts.idle,    color:"#94a3b8" },
        ].map(f => (
          <button key={f.key} onClick={() => setFilter(f.key)} style={{
            display:"flex", alignItems:"center", gap:6, padding:"5px 12px", borderRadius:6, border:"none", cursor:"pointer", fontFamily:"inherit",
            background: filter===f.key ? `${f.color}14` : "transparent", color: filter===f.key ? f.color : "#64748b", fontSize:12, fontWeight: filter===f.key?600:400 }}>
            {f.label} <span style={{ background: filter===f.key ? f.color : "#f1f5f9", color: filter===f.key ? "#fff" : "#64748b", padding:"1px 6px", borderRadius:9, fontSize:10, fontWeight:700 }}>{f.count}</span>
          </button>
        ))}
        <div style={{ marginLeft:"auto", fontSize:11, color:"#94a3b8" }}>Auto-sync every 15 min</div>
      </div>

      {/* Source cards */}
      <div style={{ display:"grid", gridTemplateColumns:"repeat(2, 1fr)", gap:10, marginBottom:24 }}>
        {filtered.map(src => {
          const type = SOURCE_TYPES.find(t => t.id === src.type);
          const isSel = selected === src.id;
          const sCfg = {
            healthy: { label:"Healthy", c:"#16a34a", bg:"#f0fdf4", b:"#bbf7d0" },
            warning: { label:"Drift",   c:"#d97706", bg:"#fffbeb", b:"#fde68a" },
            error:   { label:"Failed",  c:"#dc2626", bg:"#fef2f2", b:"#fecaca" },
            idle:    { label:"Idle",    c:"#94a3b8", bg:"#f8fafc", b:"#e2e8f0" },
          }[src.status];

          return (
            <div key={src.id} onClick={() => setSelected(isSel ? null : src.id)} style={{
              padding:"16px 18px", background:"#fff", border:`1px solid ${isSel?"#c7d2fe":"#e2e8f0"}`, borderRadius:12, cursor:"pointer", transition:"all 0.15s",
              boxShadow: isSel ? "0 0 0 3px #eef2ff" : "none"
            }}>
              <div style={{ display:"flex", alignItems:"flex-start", justifyContent:"space-between", marginBottom:12 }}>
                <div style={{ display:"flex", gap:12, alignItems:"center" }}>
                  <div style={{ width:40, height:40, borderRadius:10, background:type.color, display:"flex", alignItems:"center", justifyContent:"center", color: type.lightGlyph?"#0f172a":"#fff", fontWeight:800, fontSize:type.glyph.length>1?12:15, fontFamily:"'DM Mono',monospace" }}>{type.glyph}</div>
                  <div>
                    <div style={{ fontSize:14, fontWeight:600, color:"#0f172a", fontFamily:"'DM Mono',monospace" }}>{src.name}</div>
                    <div style={{ fontSize:11, color:"#94a3b8", marginTop:1 }}>{type.name} · {src.host}</div>
                  </div>
                </div>
                <span style={{ fontSize:10, fontWeight:700, padding:"3px 8px", borderRadius:5, background:sCfg.bg, color:sCfg.c, border:`1px solid ${sCfg.b}`, textTransform:"uppercase", letterSpacing:"0.04em", flexShrink:0 }}>{sCfg.label}</span>
              </div>

              <div style={{ display:"grid", gridTemplateColumns:"repeat(4,1fr)", gap:8, marginBottom:10 }}>
                {[["Schemas", src.schemas],["Tables", src.tables],["Rows", src.rows],["Last sync", src.lastSync]].map(([l,v]) => (
                  <div key={l}>
                    <div style={{ fontSize:9, color:"#94a3b8", textTransform:"uppercase", letterSpacing:"0.06em", fontWeight:600 }}>{l}</div>
                    <div style={{ fontSize:12, color:"#0f172a", fontWeight:500, marginTop:1, fontFamily: typeof v === "number" ? "'DM Mono',monospace" : "inherit" }}>{v}</div>
                  </div>
                ))}
              </div>

              {/* Health bar */}
              <div style={{ display:"flex", alignItems:"center", gap:10 }}>
                <div style={{ flex:1, height:4, background:"#f1f5f9", borderRadius:2, overflow:"hidden" }}>
                  <div style={{ height:"100%", width:`${src.health}%`, background: src.health>90?"#16a34a":src.health>70?"#d97706":"#dc2626", borderRadius:2 }} />
                </div>
                <span style={{ fontSize:10, fontFamily:"'DM Mono',monospace", color:"#94a3b8" }}>{src.health}% health</span>
                {src.drift > 0 && <span style={{ fontSize:10, color:"#d97706", fontWeight:600, background:"#fffbeb", padding:"2px 6px", borderRadius:3 }}>↗ {src.drift} drift</span>}
              </div>

              {isSel && (
                <div style={{ marginTop:12, paddingTop:12, borderTop:"1px solid #f1f5f9", display:"flex", gap:8, flexWrap:"wrap" }}>
                  <Btn_S style={{ fontSize:11 }}>Sync now</Btn_S>
                  <Btn_S variant="ghost" style={{ fontSize:11 }}>Edit credentials</Btn_S>
                  <Btn_S variant="ghost" style={{ fontSize:11 }}>View schema</Btn_S>
                  <Btn_S variant="ghost" style={{ fontSize:11 }}>Run pipeline</Btn_S>
                  <Btn_S variant="danger" style={{ fontSize:11 }}>Disconnect</Btn_S>
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* Connection history */}
      <PC_S style={{ padding:"16px 20px" }}>
        <SL_S>Connection activity</SL_S>
        {CONN_HISTORY.map((h,i) => (
          <div key={i} style={{ display:"flex", gap:12, padding: i<CONN_HISTORY.length-1 ? "0 0 10px" : "0", borderBottom: i<CONN_HISTORY.length-1 ? "1px solid #f1f5f9" : "none", marginBottom: i<CONN_HISTORY.length-1 ? 10 : 0, alignItems:"flex-start" }}>
            <div style={{ width:7, height:7, borderRadius:"50%", marginTop:5, flexShrink:0, background: h.type==="error"?"#dc2626":h.type==="warning"?"#d97706":h.type==="success"?"#16a34a":"#4f46e5" }} />
            <div style={{ flex:1 }}>
              <div style={{ fontSize:12, color:"#0f172a", lineHeight:1.5 }}>{h.event}</div>
              <div style={{ fontSize:10, color:"#94a3b8", fontFamily:"'DM Mono',monospace", marginTop:2 }}>{h.src}</div>
            </div>
            <div style={{ fontSize:11, color:"#94a3b8", flexShrink:0 }}>{h.time}</div>
          </div>
        ))}
      </PC_S>

      {/* Add source modal */}
      {showAdd && <AddSourceModal onClose={() => setShowAdd(false)} />}
    </div>
  );
}

function AddSourceModal({ onClose }) {
  const [step, setStep] = useStateS(1);
  const [chosenType, setChosenType] = useStateS(null);
  const [search, setSearch] = useStateS("");

  const filtered = SOURCE_TYPES.filter(t => t.name.toLowerCase().includes(search.toLowerCase()));
  const grouped = filtered.reduce((acc, t) => { (acc[t.category] ||= []).push(t); return acc; }, {});

  return (
    <div style={{ position:"fixed", inset:0, background:"rgba(15,23,42,0.5)", zIndex:9000, display:"flex", alignItems:"center", justifyContent:"center", padding:20, backdropFilter:"blur(2px)" }}
      onClick={onClose}>
      <div style={{ background:"#fff", borderRadius:14, width:"100%", maxWidth:640, maxHeight:"85vh", overflow:"hidden", display:"flex", flexDirection:"column", boxShadow:"0 20px 60px rgba(0,0,0,0.25)" }}
        onClick={e => e.stopPropagation()}>
        <div style={{ padding:"18px 24px", borderBottom:"1px solid #e2e8f0", display:"flex", alignItems:"center", justifyContent:"space-between" }}>
          <div>
            <div style={{ fontSize:11, color:"#94a3b8", fontWeight:600, textTransform:"uppercase", letterSpacing:"0.07em" }}>Step {step} of 2</div>
            <div style={{ fontSize:17, fontWeight:700, color:"#0f172a", marginTop:2 }}>{step===1 ? "Choose a connector" : `Configure ${SOURCE_TYPES.find(t=>t.id===chosenType)?.name}`}</div>
          </div>
          <button onClick={onClose} style={{ width:28, height:28, border:"none", borderRadius:6, background:"#f1f5f9", color:"#64748b", cursor:"pointer", fontSize:14 }}>×</button>
        </div>

        <div style={{ padding:"20px 24px", overflowY:"auto", flex:1 }}>
          {step === 1 && (
            <>
              <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search connectors…" style={{ width:"100%", padding:"9px 12px", border:"1px solid #e2e8f0", borderRadius:8, fontSize:13, fontFamily:"'DM Sans',sans-serif", color:"#0f172a", background:"#f8fafc", outline:"none", marginBottom:18 }} />

              {Object.entries(grouped).map(([cat, types]) => (
                <div key={cat} style={{ marginBottom:18 }}>
                  <div style={{ fontSize:10, fontWeight:700, color:"#94a3b8", textTransform:"uppercase", letterSpacing:"0.07em", marginBottom:8 }}>{cat}</div>
                  <div style={{ display:"grid", gridTemplateColumns:"repeat(3, 1fr)", gap:8 }}>
                    {types.map(t => (
                      <button key={t.id} onClick={() => { setChosenType(t.id); setStep(2); }} style={{ display:"flex", alignItems:"center", gap:10, padding:"10px 12px", border:"1px solid #e2e8f0", borderRadius:8, background:"#fff", cursor:"pointer", fontFamily:"inherit", textAlign:"left" }}>
                        <div style={{ width:32, height:32, borderRadius:7, background:t.color, display:"flex", alignItems:"center", justifyContent:"center", color:t.lightGlyph?"#0f172a":"#fff", fontWeight:800, fontSize:t.glyph.length>1?10:13, fontFamily:"'DM Mono',monospace", flexShrink:0 }}>{t.glyph}</div>
                        <span style={{ fontSize:13, color:"#0f172a", fontWeight:500 }}>{t.name}</span>
                      </button>
                    ))}
                  </div>
                </div>
              ))}
            </>
          )}

          {step === 2 && (
            <div style={{ display:"flex", flexDirection:"column", gap:14 }}>
              {[
                { l:"Connection name", v:"my-new-source", h:"Display name in Headwater" },
                { l:"Host",            v:"db.example.com" },
                { l:"Port",            v:"5432" },
                { l:"Database",        v:"" },
                { l:"Username",        v:"" },
                { l:"Password",        v:"", type:"password" },
              ].map(f => (
                <div key={f.l}>
                  <div style={{ display:"flex", gap:8, alignItems:"baseline", marginBottom:5 }}>
                    <label style={{ fontSize:13, color:"#0f172a", fontWeight:500 }}>{f.l}</label>
                    {f.h && <span style={{ fontSize:11, color:"#94a3b8" }}>{f.h}</span>}
                  </div>
                  <input type={f.type||"text"} defaultValue={f.v} style={{ width:"100%", padding:"8px 12px", border:"1px solid #e2e8f0", borderRadius:7, fontSize:13, fontFamily:"'DM Sans',sans-serif", color:"#0f172a", background:"#f8fafc", outline:"none" }} />
                </div>
              ))}
              <label style={{ display:"flex", gap:8, alignItems:"center", marginTop:6, fontSize:12, color:"#475569" }}>
                <input type="checkbox" defaultChecked /> Auto-sync every 15 minutes
              </label>
              <label style={{ display:"flex", gap:8, alignItems:"center", fontSize:12, color:"#475569" }}>
                <input type="checkbox" defaultChecked /> Run discovery + LLM enrichment after first sync
              </label>
            </div>
          )}
        </div>

        <div style={{ padding:"14px 24px", borderTop:"1px solid #e2e8f0", display:"flex", justifyContent:"space-between", gap:8 }}>
          <Btn_S variant="ghost" onClick={step===2 ? () => setStep(1) : onClose}>{step===2 ? "← Back" : "Cancel"}</Btn_S>
          {step === 2 && <Btn_S onClick={onClose}>Test &amp; Connect</Btn_S>}
        </div>
      </div>
    </div>
  );
}

// ─── Briefing Mode Dashboard ─────────────────────────────────────────────────

function ABriefing({ setPage, appState }) {
  const today = new Date(2026, 3, 27).toLocaleDateString("en-US", { weekday:"long", month:"long", day:"numeric" });
  const confirmed = appState.confirmedDescs.length;
  const approved = appState.approvedModels.length;

  const priorities = [
    {
      n:1, urgency:"high",
      headline:"Severity data is missing on 23% of incidents",
      detail:"This blocks the compliance summary mart. The gap originates upstream in the manual review portal — recommend remediation before Q2 reports.",
      action:"Review incidents.severity_tier",
      route:"discover",
    },
    {
      n:2, urgency:"medium",
      headline:"PM2.5 distribution shifted 12% on warehouse-analytics",
      detail:"Detected during the 22-minute sync. Distribution mean moved from 14.1 to 18.7 µg/m³. Could be a real environmental change or a unit mismatch — worth a glance.",
      action:"Open drift report",
      route:"insights",
    },
    {
      n:3, urgency:"medium",
      headline:`${Math.max(0, 3 - approved)} mart models awaiting approval`,
      detail: approved >= 3 ? "All caught up — no models pending." : "Generated SQL is ready. Each model materializes a key analytical view; review before they run on schedule.",
      action: approved >= 3 ? "View executed models" : "Review queue",
      route:"model-data",
    },
    {
      n:4, urgency:"low",
      headline:"legacy-inspections connection failed",
      detail:"Authentication timed out at 03:14 UTC. Last successful sync was 2 days ago. Likely an expired credential — quick fix.",
      action:"Reconnect source",
      route:"sources",
    },
  ];

  const wins = [
    "100% schema integrity confirmed across all FK relationships on zones",
    "193 quality contracts passing — no regressions since last week",
    `Catalog confidence climbed to ${Math.min(99, 72 + confirmed*4)}% ${confirmed > 0 ? "after your edits" : ""}`,
    "Anomaly detector caught 14 PM2.5 spikes in Industrial North — alerted ops",
  ];

  return (
    <div style={{ maxWidth:760 }}>
      {/* Hero briefing header */}
      <div style={{ marginBottom:32, paddingBottom:24, borderBottom:"1px solid #e2e8f0" }}>
        <div style={{ fontSize:11, fontWeight:700, color:"#94a3b8", textTransform:"uppercase", letterSpacing:"0.1em", marginBottom:8 }}>{today} · Continuous briefing</div>
        <h1 style={{ fontSize:30, fontWeight:700, letterSpacing:"-0.03em", color:"#0f172a", lineHeight:1.2, marginBottom:14 }}>
          {priorities.filter(p=>p.urgency==="high").length > 0
            ? <>You have <span style={{ color:"#dc2626" }}>{priorities.filter(p=>p.urgency==="high").length} thing{priorities.filter(p=>p.urgency==="high").length!==1?"s":""}</span> worth your attention<br/>and <span style={{ color:"#64748b" }}>{priorities.filter(p=>p.urgency!=="high").length} that can wait</span>.</>
            : <>All clear. Your data is healthy<br/>and improving steadily.</>}
        </h1>
        <p style={{ fontSize:14, color:"#64748b", lineHeight:1.6, maxWidth:560 }}>
          Headwater watched <strong style={{ color:"#0f172a", fontWeight:600 }}>6 sources</strong>, ran <strong style={{ color:"#0f172a", fontWeight:600 }}>27 quality checks</strong>, and detected <strong style={{ color:"#0f172a", fontWeight:600 }}>2 schema changes</strong> since your last visit. Everything below — health, models, insights — reflects the latest state.
        </p>
      </div>

      {/* Priority list */}
      <div style={{ marginBottom:36 }}>
        {priorities.map((p, i) => {
          const colors = { high:["#dc2626","#fef2f2"], medium:["#d97706","#fffbeb"], low:["#64748b","#f8fafc"] };
          const [c, bg] = colors[p.urgency];
          return (
            <div key={i} style={{ display:"flex", gap:18, padding:"22px 0", borderBottom: i<priorities.length-1?"1px solid #f1f5f9":"none" }}>
              <div style={{ width:48, flexShrink:0 }}>
                <div style={{ width:36, height:36, borderRadius:"50%", background:bg, color:c, display:"flex", alignItems:"center", justifyContent:"center", fontWeight:800, fontSize:14, fontFamily:"'DM Mono',monospace" }}>{p.n}</div>
                <div style={{ fontSize:9, color:c, fontWeight:700, textTransform:"uppercase", letterSpacing:"0.07em", marginTop:6, textAlign:"center" }}>{p.urgency}</div>
              </div>
              <div style={{ flex:1 }}>
                <h3 style={{ fontSize:17, fontWeight:600, color:"#0f172a", letterSpacing:"-0.01em", lineHeight:1.35, marginBottom:8 }}>{p.headline}</h3>
                <p style={{ fontSize:13, color:"#475569", lineHeight:1.7, marginBottom:12 }}>{p.detail}</p>
                <button onClick={() => setPage(p.route)} style={{ padding:"6px 14px", background:"#fff", border:"1px solid #e2e8f0", borderRadius:7, fontSize:12, color:"#0f172a", fontWeight:500, cursor:"pointer", fontFamily:"inherit" }}>{p.action} →</button>
              </div>
            </div>
          );
        })}
      </div>

      {/* Wins / quiet section */}
      <div style={{ background:"#f0fdf4", border:"1px solid #bbf7d0", borderRadius:12, padding:"20px 22px", marginBottom:24 }}>
        <div style={{ display:"flex", alignItems:"center", gap:8, marginBottom:12 }}>
          <span style={{ width:20, height:20, borderRadius:"50%", background:"#16a34a", color:"#fff", display:"flex", alignItems:"center", justifyContent:"center", fontSize:11, fontWeight:700 }}>✓</span>
          <span style={{ fontSize:13, fontWeight:700, color:"#166534" }}>What's going well</span>
        </div>
        {wins.map((w, i) => (
          <div key={i} style={{ display:"flex", gap:10, alignItems:"flex-start", paddingLeft:28, marginBottom: i<wins.length-1?8:0 }}>
            <span style={{ color:"#16a34a", fontSize:11, marginTop:1 }}>·</span>
            <span style={{ fontSize:13, color:"#166534", lineHeight:1.5 }}>{w}</span>
          </div>
        ))}
      </div>

      {/* Footer stats */}
      <div style={{ display:"grid", gridTemplateColumns:"repeat(4,1fr)", gap:0, padding:"16px 0", borderTop:"1px solid #e2e8f0" }}>
        {[["6","sources"],["192","tables"],["1.2K","quality checks"],["87%","health"]].map(([v,l]) => (
          <div key={l} style={{ borderRight:"1px solid #f1f5f9", paddingLeft:18, paddingRight:18 }}>
            <div style={{ fontSize:22, fontWeight:700, color:"#0f172a", letterSpacing:"-0.03em" }}>{v}</div>
            <div style={{ fontSize:11, color:"#94a3b8", marginTop:2 }}>{l}</div>
          </div>
        ))}
      </div>
    </div>
  );
}

Object.assign(window, { ASources, ABriefing });
