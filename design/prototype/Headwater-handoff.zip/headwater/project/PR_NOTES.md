# PR — Briefing-led nav, multi-source connectors, continuous updates

## Branch
`design/briefing-and-sources`

## Summary
Three changes to make Headwater feel like a *continuous* data improvement tool rather than a one-shot pipeline:

1. **Nav restructured** into 5 logical groups: Today / Catalog / Build / Analyze / Configure. The previous flat list (where "Model · Data · Query" was bloated as one item) is now split into Model, Data & Query, and Review Queue under **Build**. "Overview" renamed to **Project Health** — clearer that it's a live state view, not a generic landing.
2. **Briefing** is the new homepage under **Today**. Narrative-led: "You have N things worth your attention and M that can wait." Each priority deep-links to the relevant page.
3. **Sources** (under **Catalog**) — first-class multi-source connector list with health, drift indicators, and a 2-step "+ Connect source" wizard supporting 12 connectors.

## Continuous-update contract

Every page reflects the latest state. When *anything* changes — a column description confirmed, a model approved, a relationship modified, source data drifts — the following must update:

| Trigger | Updates |
|---|---|
| Column description confirmed | Catalog confidence (Project Health, Insights, Briefing); re-run banner shown |
| Model approved | Pipeline stepper (Project Health); maturity bar (sidebar); drops out of Briefing priorities |
| Source sync detects schema change | Sync events log (Sources); new Briefing priority; affected table flagged on Discover |
| Source sync detects drift | Drift badge on Sources card; new Briefing priority; Insights anomaly list |
| Relationship modified | ERD diagram (Model tab); referential integrity recomputed; affected Discover profiles re-rendered |

Implementation: a single `appState` reducer in the shell + a `hw-navigate` event bus. Server-side, the pattern is one events table (`sync_events`) feeding both the Briefing aggregator and per-page invalidations via SWR / React Query keys.

## Files changed in prototype
- `hw-pages-a.jsx` — nav groups, Briefing route, Project Health rename
- `hw-model-query.jsx` — accepts `initialTab` so Build/Model, Build/Data, Build/Review each open the right tab
- `hw-sources.jsx` — Sources list, connector wizard, Briefing component
- `Headwater Design System.html` — default page = `briefing`

## Files to add to `nupsea/headwater`
See `INTEGRATION_NOTES.md` for full mapping. Summary:

```
headwater/ui/src/app/
  briefing/page.tsx              NEW
  sources/page.tsx               NEW
  sources/new/page.tsx           NEW
  health/page.tsx                NEW (was Overview/page.tsx)

headwater/ui/src/components/
  briefing-priorities.tsx        NEW
  briefing-wins.tsx              NEW
  source-card.tsx                NEW
  connector-picker.tsx           NEW

headwater/headwater/connectors/
  base.py                        NEW (Connector protocol)
  postgres.py                    REFACTOR existing
  mysql.py                       NEW
  snowflake.py                   NEW
  bigquery.py                    NEW
  duckdb.py                      NEW

headwater/migrations/
  0XX_sources.sql                NEW
  0XX_sync_events.sql            NEW
```

## How to open the PR

I have read-only GitHub access from this environment, so I can't push or open the PR for you. Easiest path:

```bash
# 1. Clone if you haven't
git clone https://github.com/nupsea/headwater.git
cd headwater

# 2. New branch
git checkout -b design/briefing-and-sources

# 3. Copy the prototype + integration notes from this Claude project
#    (download from the project sidebar, or right-click → Save)
mkdir -p design-prototype
cp ~/Downloads/Headwater\ Design\ System.html design-prototype/
cp ~/Downloads/hw-*.{js,jsx} design-prototype/
cp ~/Downloads/INTEGRATION_NOTES.md .

# 4. Commit & push
git add design-prototype INTEGRATION_NOTES.md PR_NOTES.md
git commit -m "design: briefing-led nav + multi-source connectors

- Adds Briefing as new homepage (narrative priorities)
- Splits Model·Data·Query nav item into Model / Data & Query / Review
- Adds Sources page with 12-connector wizard
- Renames Overview → Project Health
- Documents continuous-update contract across all pages

See PR_NOTES.md and INTEGRATION_NOTES.md for backend/schema work needed."
git push -u origin design/briefing-and-sources

# 5. Open PR
gh pr create --title "design: briefing-led nav + multi-source connectors" \
             --body-file PR_NOTES.md
```

Or use the GitHub web UI after the push — branch link will be printed.

## Review checklist
- [ ] Nav groups feel right: Today / Catalog / Build / Analyze / Configure
- [ ] "Project Health" reads better than "Overview"
- [ ] Briefing copy lands on the continuous-improvement promise
- [ ] Sources connector list covers your priority targets
- [ ] Continuous-update contract above matches your backend's event model
- [ ] Integration notes' SQL + connector protocol look reasonable
