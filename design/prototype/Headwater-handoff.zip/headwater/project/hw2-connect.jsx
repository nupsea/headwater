// Headwater 2 — Connect Source. Multi-step modal:
//   1. Pick connector
//   2. Connection details
//   3. Browse schemas → pick tables across schemas (the key step)
//   4. Profile & done

function HW2Connect({ connectors, sampleSchemas, onClose, onComplete }) {
  const [step, setStep] = React.useState(0);
  const [connector, setConnector] = React.useState("postgres");
  const [details, setDetails] = React.useState({
    host: "pg.hospital.internal", port: "5432",
    database: "hospital_db", user: "analyst", password: "",
  });
  const [profiling, setProfiling] = React.useState(false);

  // Selected tables — fqn -> true
  const [picks, setPicks] = React.useState(() => {
    const out = {};
    for (const s of sampleSchemas) {
      for (const t of s.tables) {
        if (t.selected) out[`${s.name}.${t.name}`] = true;
      }
    }
    return out;
  });
  const togglePick = (fqn) => setPicks(p => ({ ...p, [fqn]: !p[fqn] }));
  const pickCount = Object.values(picks).filter(Boolean).length;

  const steps = ["Connector", "Connection", "Pick tables", "Profile"];

  return (
    <div style={{
      position: "fixed", inset: 0, zIndex: 100,
      background: "rgba(20,20,25,0.36)",
      display: "grid", placeItems: "center",
      padding: 32,
    }}>
      <div onClick={(e) => e.stopPropagation()} style={{
        width: "min(880px, 100%)", maxHeight: "min(720px, 92vh)",
        background: "#fff", borderRadius: 14,
        boxShadow: "0 20px 60px rgba(20,20,30,0.18)",
        display: "flex", flexDirection: "column", overflow: "hidden",
      }}>
        {/* Header */}
        <div style={{ padding: "18px 24px", borderBottom: `1px solid ${HW2_COLOR.rule}`, display: "flex", alignItems: "center", justifyContent: "space-between" }}>
          <div>
            <h3 style={{ font: "600 17px 'DM Sans'", letterSpacing: "-0.01em", color: HW2_COLOR.ink }}>
              Connect a source
            </h3>
            <p style={{ font: "400 12px 'DM Sans'", color: HW2_COLOR.muted, marginTop: 2 }}>
              Profile data once, reuse across projects.
            </p>
          </div>
          <button onClick={onClose} style={{
            appearance: "none", background: "transparent", border: "none", cursor: "pointer",
            font: "300 22px 'DM Sans'", color: HW2_COLOR.muted, padding: 4,
          }}>×</button>
        </div>

        {/* Step indicator */}
        <div style={{ padding: "12px 24px", borderBottom: `1px solid ${HW2_COLOR.rule}`, display: "flex", gap: 0, alignItems: "center" }}>
          {steps.map((s, i) => (
            <React.Fragment key={s}>
              <div style={{ display: "inline-flex", alignItems: "center", gap: 6 }}>
                <span style={{
                  width: 20, height: 20, borderRadius: "50%",
                  background: i < step ? HW2_COLOR.good : i === step ? HW2_COLOR.ink : "transparent",
                  border: i > step ? `1.5px solid ${HW2_COLOR.rule2}` : "none",
                  color: i <= step ? "#fff" : HW2_COLOR.faint,
                  font: "600 11px 'DM Mono'", display: "inline-flex", alignItems: "center", justifyContent: "center",
                }}>{i < step ? "✓" : i + 1}</span>
                <span style={{
                  font: `${i === step ? 600 : 500} 12px 'DM Sans'`,
                  color: i === step ? HW2_COLOR.ink : i < step ? HW2_COLOR.ink2 : HW2_COLOR.faint,
                }}>{s}</span>
              </div>
              {i < steps.length - 1 && <span style={{ flex: 1, height: 1, background: HW2_COLOR.rule, margin: "0 12px" }} />}
            </React.Fragment>
          ))}
        </div>

        {/* Body */}
        <div style={{ flex: 1, overflowY: "auto", padding: "24px 28px" }}>
          {step === 0 && <ConnStepConnector connectors={connectors} value={connector} onChange={setConnector} />}
          {step === 1 && <ConnStepDetails connector={connector} details={details} onChange={setDetails} />}
          {step === 2 && <ConnStepPickTables schemas={sampleSchemas} picks={picks} onToggle={togglePick} />}
          {step === 3 && <ConnStepProfile profiling={profiling} pickCount={pickCount} />}
        </div>

        {/* Footer */}
        <div style={{ padding: "14px 24px", borderTop: `1px solid ${HW2_COLOR.rule}`, display: "flex", justifyContent: "space-between", alignItems: "center" }}>
          <span style={{ font: "400 12px 'DM Sans'", color: HW2_COLOR.muted }}>
            {step === 2 && `${pickCount} table${pickCount === 1 ? "" : "s"} selected`}
            {step < 2 && "We never write to your source. Read-only."}
            {step === 3 && (profiling ? "Profiling…" : "Ready to use.")}
          </span>
          <div style={{ display: "flex", gap: 8 }}>
            <HW2Btn onClick={onClose}>Cancel</HW2Btn>
            {step > 0 && step < 3 && (
              <HW2Btn onClick={() => setStep(s => s - 1)}>← Back</HW2Btn>
            )}
            {step < 2 && (
              <HW2Btn kind="accent" onClick={() => setStep(s => s + 1)}>Continue →</HW2Btn>
            )}
            {step === 2 && (
              <HW2Btn kind="accent" disabled={pickCount === 0}
                onClick={() => { setStep(3); setProfiling(true); setTimeout(() => { setProfiling(false); }, 1600); }}>
                Profile {pickCount} tables →
              </HW2Btn>
            )}
            {step === 3 && (
              <HW2Btn kind="accent" disabled={profiling} onClick={onComplete}>
                {profiling ? "Profiling…" : "Done"}
              </HW2Btn>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

// ─── Step 1: connector grid ──────────────────────────────────────────────────
function ConnStepConnector({ connectors, value, onChange }) {
  return (
    <div>
      <div style={{ font: "500 13px 'DM Sans'", color: HW2_COLOR.ink2, marginBottom: 14 }}>
        Where is your data?
      </div>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 10 }}>
        {connectors.map(c => {
          const sel = c.id === value;
          return (
            <button key={c.id} onClick={() => onChange(c.id)} style={{
              appearance: "none", cursor: "pointer", textAlign: "left",
              padding: "14px 14px",
              background: sel ? HW2_COLOR.blueSoft : "#fff",
              border: `1.5px solid ${sel ? HW2_COLOR.blue : HW2_COLOR.rule2}`,
              borderRadius: 10, fontFamily: "'DM Sans', sans-serif",
            }}>
              <div style={{
                width: 28, height: 28, borderRadius: 7, marginBottom: 10,
                background: sel ? HW2_COLOR.blue : HW2_COLOR.chip,
                color: sel ? "#fff" : HW2_COLOR.ink2,
                display: "grid", placeItems: "center",
                font: "700 12px 'DM Mono'",
              }}>{c.name[0]}</div>
              <div style={{ font: "600 13px 'DM Sans'", color: sel ? HW2_COLOR.blue : HW2_COLOR.ink }}>{c.name}</div>
              <div style={{ font: "400 11px 'DM Sans'", color: HW2_COLOR.muted, marginTop: 2 }}>{c.blurb}</div>
            </button>
          );
        })}
      </div>
    </div>
  );
}

// ─── Step 2: connection details ──────────────────────────────────────────────
function ConnStepDetails({ connector, details, onChange }) {
  const fields = ({
    postgres:  [["host", "Host"], ["port", "Port"], ["database", "Database"], ["user", "Username"], ["password", "Password", "password"]],
    snowflake: [["host", "Account"], ["database", "Database"], ["user", "Username"], ["password", "Password", "password"]],
    bigquery:  [["database", "Project ID"], ["user", "Service account"], ["password", "Key file path"]],
    duckdb:    [["host", "DuckDB file path"]],
    mysql:     [["host", "Host"], ["port", "Port"], ["database", "Database"], ["user", "Username"], ["password", "Password", "password"]],
    redshift:  [["host", "Cluster endpoint"], ["port", "Port"], ["database", "Database"], ["user", "Username"], ["password", "Password", "password"]],
    sqlite:    [["host", "SQLite file path"]],
    csv:       [["host", "Folder path or upload"]],
  })[connector] || [["host", "Host"]];
  return (
    <div style={{ maxWidth: 520 }}>
      <div style={{ font: "500 13px 'DM Sans'", color: HW2_COLOR.ink2, marginBottom: 14 }}>
        Connection details for <span style={{ font: "500 13px 'DM Mono'" }}>{connector}</span>
      </div>
      <div style={{ display: "grid", gap: 12 }}>
        {fields.map(([k, label, type = "text"]) => (
          <div key={k}>
            <label style={{ font: "600 11px 'DM Sans'", color: HW2_COLOR.muted, display: "block", marginBottom: 5 }}>
              {label}
            </label>
            <input
              type={type}
              value={details[k] || ""}
              onChange={(e) => onChange({ ...details, [k]: e.target.value })}
              style={{
                width: "100%", appearance: "none",
                padding: "9px 12px",
                background: "#fff", border: `1px solid ${HW2_COLOR.rule2}`, borderRadius: 8,
                font: "500 13px 'DM Mono'", color: HW2_COLOR.ink,
                outline: "none",
              }}
            />
          </div>
        ))}
      </div>
      <div style={{
        marginTop: 20, padding: "10px 14px",
        background: HW2_COLOR.chip, borderRadius: 8,
        font: "400 12px 'DM Sans'", color: HW2_COLOR.muted, lineHeight: 1.5,
      }}>
        Headwater connects read-only. Credentials never leave this workspace.
      </div>
    </div>
  );
}

// ─── Step 3: pick tables across schemas (the key step) ──────────────────────
function ConnStepPickTables({ schemas, picks, onToggle }) {
  const [search, setSearch] = React.useState("");
  const filterMatch = (s, t) => {
    if (!search) return true;
    const q = search.toLowerCase();
    return s.name.toLowerCase().includes(q) || t.name.toLowerCase().includes(q);
  };
  const pickedCount = Object.values(picks).filter(Boolean).length;
  const allCount = schemas.reduce((a, s) => a + s.tables.length, 0);

  return (
    <div>
      <div style={{ display: "flex", alignItems: "flex-end", justifyContent: "space-between", marginBottom: 12, gap: 12 }}>
        <div>
          <div style={{ font: "500 13px 'DM Sans'", color: HW2_COLOR.ink2 }}>
            Choose which tables to bring in.
          </div>
          <div style={{ font: "400 12px 'DM Sans'", color: HW2_COLOR.muted, marginTop: 2 }}>
            You can pick across schemas. We&rsquo;ll profile only what you pick.
          </div>
        </div>
        <input
          placeholder="Search…"
          value={search} onChange={(e) => setSearch(e.target.value)}
          style={{
            width: 220, padding: "7px 12px",
            background: "#fff", border: `1px solid ${HW2_COLOR.rule2}`, borderRadius: 7,
            font: "400 13px 'DM Sans'", color: HW2_COLOR.ink, outline: "none",
          }}
        />
      </div>

      <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 12, font: "400 12px 'DM Sans'", color: HW2_COLOR.muted }}>
        <span><strong style={{ color: HW2_COLOR.ink }}>{pickedCount}</strong> selected · {allCount} available</span>
        <span>·</span>
        <button onClick={() => {
          for (const s of schemas) for (const t of s.tables) onToggle(`${s.name}.${t.name}`);
        }} style={anchorBtn}>toggle all</button>
      </div>

      <div style={{ display: "grid", gap: 18, maxHeight: 380, overflowY: "auto", paddingRight: 4 }}>
        {schemas.map(s => {
          const visible = s.tables.filter(t => filterMatch(s, t));
          if (visible.length === 0) return null;
          const allChecked = visible.every(t => picks[`${s.name}.${t.name}`]);
          return (
            <div key={s.name}>
              <div style={{
                display: "flex", alignItems: "center", justifyContent: "space-between",
                padding: "0 4px 6px", marginBottom: 4, borderBottom: `1px solid ${HW2_COLOR.rule}`,
              }}>
                <span style={{ font: "600 12px 'DM Mono'", color: HW2_COLOR.ink }}>{s.name}</span>
                <button onClick={() => {
                  for (const t of visible) {
                    if (allChecked === !!picks[`${s.name}.${t.name}`]) {
                      onToggle(`${s.name}.${t.name}`);
                    }
                  }
                }} style={anchorBtn}>
                  {allChecked ? "deselect all" : "select all"}
                </button>
              </div>
              <div style={{ display: "grid", gap: 4 }}>
                {visible.map(t => {
                  const fqn = `${s.name}.${t.name}`;
                  const sel = !!picks[fqn];
                  return (
                    <label key={t.name} style={{
                      display: "flex", alignItems: "center", gap: 10,
                      padding: "8px 10px", borderRadius: 7, cursor: "pointer",
                      background: sel ? HW2_COLOR.blueSoft : "transparent",
                      border: `1px solid ${sel ? HW2_COLOR.blueSoft : "transparent"}`,
                    }}>
                      <input type="checkbox" checked={sel} onChange={() => onToggle(fqn)}
                        style={{ accentColor: HW2_COLOR.blue, cursor: "pointer" }} />
                      <span style={{ font: "500 13px 'DM Mono'", color: sel ? HW2_COLOR.blue : HW2_COLOR.ink2, minWidth: 140 }}>
                        {t.name}
                      </span>
                      <span style={{ flex: 1, font: "400 12px 'DM Sans'", color: HW2_COLOR.muted, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
                        {t.description}
                      </span>
                      <span style={{ font: "400 11px 'DM Mono'", color: HW2_COLOR.faint, whiteSpace: "nowrap" }}>
                        {t.rows >= 1000 ? `${(t.rows/1000).toFixed(1)}k` : t.rows} rows
                      </span>
                    </label>
                  );
                })}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

// ─── Step 4: profile ─────────────────────────────────────────────────────────
function ConnStepProfile({ profiling, pickCount }) {
  return (
    <div style={{ padding: "32px 20px", display: "grid", placeItems: "center" }}>
      <div style={{ textAlign: "center", maxWidth: 400 }}>
        {profiling ? (
          <>
            <div style={{
              width: 48, height: 48, margin: "0 auto 16px",
              border: `3px solid ${HW2_COLOR.rule2}`,
              borderTopColor: HW2_COLOR.blue, borderRadius: "50%",
              animation: "hw2-spin 0.8s linear infinite",
            }} />
            <div style={{ font: "600 14px 'DM Sans'", color: HW2_COLOR.ink }}>
              Profiling {pickCount} tables…
            </div>
            <div style={{ font: "400 12px 'DM Sans'", color: HW2_COLOR.muted, marginTop: 4 }}>
              Computing columns, types, keys, relationships. This runs once per source.
            </div>
          </>
        ) : (
          <>
            <div style={{
              width: 48, height: 48, margin: "0 auto 16px",
              borderRadius: "50%", background: HW2_COLOR.goodSoft, color: HW2_COLOR.good,
              display: "grid", placeItems: "center",
              font: "700 24px 'DM Sans'",
            }}>✓</div>
            <div style={{ font: "600 14px 'DM Sans'", color: HW2_COLOR.ink }}>
              Source connected.
            </div>
            <div style={{ font: "400 12px 'DM Sans'", color: HW2_COLOR.muted, marginTop: 4 }}>
              {pickCount} tables profiled. Available in Catalog, Query, and any new project.
            </div>
          </>
        )}
      </div>
      <style>{`@keyframes hw2-spin { from { transform: rotate(0deg); } to { transform: rotate(360deg); } }`}</style>
    </div>
  );
}

const anchorBtn = {
  appearance: "none", background: "transparent", border: "none", cursor: "pointer",
  padding: 0, color: HW2_COLOR.blue, font: "500 12px 'DM Sans'",
  fontFamily: "'DM Sans', sans-serif",
};

Object.assign(window, { HW2Connect });
