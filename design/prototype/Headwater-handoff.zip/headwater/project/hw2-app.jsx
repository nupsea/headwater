// Headwater 2 — root app. Holds the workspace + project state, routes the
// main area between Catalog / Query / Project flow / (modal) Connect.

const { useState, useEffect, useMemo } = React;

function HW2App() {
  // --- Data ---
  const initial = useMemo(() => JSON.parse(JSON.stringify(window.HW2)), []);
  const [sources]                 = useState(initial.sources);
  const [source]                  = useState(initial.sources[0]);
  const [projects, setProjects]   = useState(initial.projects);
  const [data]                    = useState(initial);

  // --- Routing ---
  // route.kind:
  //   "catalog" | "query" | "project"
  // for project: route.projectId, route.stage
  const [route, setRoute] = useState({ kind: "catalog" });
  const [pendingSql, setPendingSql] = useState("");
  const project = route.kind === "project" ? projects.find(p => p.id === route.projectId) : null;
  const stage = route.kind === "project" ? route.stage : null;

  // --- Connect modal ---
  const [connectOpen, setConnectOpen] = useState(false);

  // --- Project mutators ---
  const updateProject = (id, patch) =>
    setProjects(ps => ps.map(p => p.id === id ? { ...p, ...patch, lastTouched: "Just now" } : p));

  const newProject = () => {
    const id = "p_" + Date.now();
    const p = {
      id, title: "Untitled goal", goal: "", sourceId: source.id,
      selectedTables: [], stage: "frame", trust: 0, trustLabel: "Not started",
      lastTouched: "Just now", resolved: 0, resolveTotal: 0, questions: [],
    };
    setProjects(ps => [...ps, p]);
    setRoute({ kind: "project", projectId: id, stage: "frame" });
  };

  const openProject = (id) => {
    const p = projects.find(x => x.id === id);
    setRoute({ kind: "project", projectId: id, stage: p?.stage || "frame" });
  };

  const jumpStage = (k) => setRoute(r => ({ ...r, stage: k }));

  const goRoute = (r) => setRoute(r);

  const openQueryWith = (sql) => {
    setPendingSql(sql);
    setRoute({ kind: "query" });
  };

  // --- Tweaks ---
  const t  = useTweaks(TWEAK_DEFAULTS);
  const [tweaksOpen, setTweaksOpen] = useState(false);
  useEffect(() => {
    const onMsg = (e) => {
      if (e.data?.type === "__activate_edit_mode")   setTweaksOpen(true);
      if (e.data?.type === "__deactivate_edit_mode") setTweaksOpen(false);
    };
    window.addEventListener("message", onMsg);
    window.parent.postMessage({ type: "__edit_mode_available" }, "*");
    return () => window.removeEventListener("message", onMsg);
  }, []);

  // ─── Render main area by route ─────────────────────────────────────────────
  let main = null;

  if (route.kind === "catalog") {
    main = <HW2Catalog
      source={source}
      catalogColumns={data.catalogColumns}
      sampleRows={data.sampleRows}
      onOpenQuery={openQueryWith}
    />;
  } else if (route.kind === "query") {
    main = <HW2Query source={source} sampleRows={data.sampleRows} initialSQL={pendingSql} />;
  } else if (project) {
    main = <ProjectFlow
      project={project} source={source} data={data}
      stage={stage}
      onUpdate={(patch) => updateProject(project.id, patch)}
      onJumpStage={jumpStage}
    />;
  }

  return (
    <>
      <HW2Shell
        source={source} sources={sources} projects={projects}
        route={route} onRoute={goRoute}
        project={project} stage={stage} onJumpStage={jumpStage}
        onConnectSource={() => setConnectOpen(true)}
        onNewProject={newProject}>
        {main}
      </HW2Shell>

      {connectOpen && (
        <HW2Connect
          connectors={data.connectors}
          sampleSchemas={source.schemas}
          onClose={() => setConnectOpen(false)}
          onComplete={() => setConnectOpen(false)}
        />
      )}

      {tweaksOpen && <Hw2Tweaks t={t} onClose={() => setTweaksOpen(false)} />}
    </>
  );
}

// ─── ProjectFlow — the guided workflow ──────────────────────────────────────
function ProjectFlow({ project, source, data, stage, onUpdate, onJumpStage }) {
  if (stage === "frame") {
    return <HW2Frame
      project={project} source={source}
      onGenerate={(spec) => {
        onUpdate({
          goal: spec.goal, questions: spec.questions,
          selectedTables: spec.selectedTables,
          title: spec.goal ? truncate(spec.goal, 64) : project.title,
          stage: "generate", trust: 25,
        });
        onJumpStage("generate");
      }}
    />;
  }
  if (stage === "generate") {
    return <HW2Generate
      project={project} source={source}
      onDone={() => { onUpdate({ stage: "understand", trust: 42 }); onJumpStage("understand"); }}
    />;
  }
  if (stage === "understand") {
    return <HW2Understand
      project={project} data={data}
      onConfirm={() => {
        onUpdate({
          stage: "resolve",
          trust: Math.max(project.trust, 55),
          resolveTotal: data.resolveCards.length,
        });
        onJumpStage("resolve");
      }}
      onSomethingOff={() => onJumpStage("frame")}
    />;
  }
  if (stage === "resolve") {
    return <HW2Resolve
      project={project}
      cards={data.resolveCards}
      onResolveOne={(card, choice) => {
        const gain = choice?.kind === "confirm" ? card.trustGain : 0;
        onUpdate({
          trust: Math.min(95, project.trust + gain),
          resolved: project.resolved + 1,
        });
      }}
      onAllDone={() => {
        onUpdate({ stage: "readiness", trust: Math.max(project.trust, 78) });
        onJumpStage("readiness");
      }}
    />;
  }
  if (stage === "readiness") {
    return <HW2Readiness
      project={project} readiness={data.readiness}
      onAnswer={() => { onUpdate({ stage: "answer" }); onJumpStage("answer"); }}
      onImprove={() => onJumpStage("resolve")}
    />;
  }
  if (stage === "answer") {
    return <HW2Answer
      project={project} chartData={data.chartData}
      onCertify={() => onJumpStage("resolve")}
      onExportReport={() => alert("Audit report export — would write Markdown in production.")}
    />;
  }
  return null;
}

function truncate(s, n) { return s.length > n ? s.slice(0, n - 1) + "…" : s; }

// ─── Tweaks ─────────────────────────────────────────────────────────────────
const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "showWorkflowNumbers": true,
  "density": "comfy"
}/*EDITMODE-END*/;

function Hw2Tweaks({ t, onClose }) {
  return (
    <TweaksPanel title="Tweaks" onClose={onClose}>
      <TweakSection title="Display">
        <TweakRadio label="Density" value={t.density} onChange={v => t.set("density", v)}
          options={[{ value: "comfy", label: "Comfy" }, { value: "compact", label: "Compact" }]} />
        <TweakToggle label="Stepper numbers" value={t.showWorkflowNumbers}
          onChange={v => t.set("showWorkflowNumbers", v)} />
      </TweakSection>
      <TweakSection title="About">
        <div style={{ font: "400 12px 'DM Sans'", color: HW2_COLOR.muted, lineHeight: 1.5 }}>
          The workflow stage stepper appears only when you&rsquo;re inside a project.
          Catalog and Query are workspace-level power tools, available alongside.
        </div>
      </TweakSection>
    </TweaksPanel>
  );
}

// Mount
const root = ReactDOM.createRoot(document.getElementById("root"));
root.render(<HW2App />);
