// Headwater 2 — workspace shell with persistent left rail.
//
// Layout:
//   ┌────────────────────────────────────────────────────────────────┐
//   │ Top bar (logo · source switcher · account)                      │
//   ├──────────────┬──────────────────────────────────────────────────┤
//   │              │                                                  │
//   │ Left rail    │  Contextual main area                            │
//   │ (source +    │  (Catalog · Query · Project guided flow)         │
//   │  workspace + │                                                  │
//   │  projects)   │                                                  │
//   │              │                                                  │
//   └──────────────┴──────────────────────────────────────────────────┘

function HW2Shell({
  source, sources, projects, route, onRoute, project, stage, onJumpStage,
  onConnectSource, onNewProject, children,
}) {
  return (
    <div style={{
      height: "100vh", display: "flex", flexDirection: "column",
      background: HW2_COLOR.paper, color: HW2_COLOR.ink,
      fontFamily: "'DM Sans', sans-serif", overflow: "hidden",
    }}>
      {/* Top bar */}
      <header style={{
        height: 48, flexShrink: 0,
        display: "flex", alignItems: "center", justifyContent: "space-between",
        padding: "0 18px",
        background: "rgba(250, 249, 246, 0.85)",
        backdropFilter: "saturate(140%) blur(8px)",
        borderBottom: `1px solid ${HW2_COLOR.rule}`,
        zIndex: 10,
      }}>
        <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
          <span style={{
            width: 16, height: 16, borderRadius: 4,
            background: `linear-gradient(135deg, ${HW2_COLOR.blue}, #4980f0)`,
          }} />
          <span style={{ font: "700 14px 'DM Sans'", letterSpacing: "-0.02em" }}>Headwater</span>
          <span style={{ font: "500 11px 'DM Mono'", color: HW2_COLOR.faint, marginLeft: 2 }}>v2</span>
        </div>
        <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
          {/* Live project + trust pill (when inside a project) */}
          {project && (
            <div style={{
              display: "inline-flex", alignItems: "center", gap: 8,
              padding: "5px 10px", borderRadius: 999,
              background: HW2_COLOR.chip, border: `1px solid ${HW2_COLOR.rule2}`,
            }}>
              <HW2TrustRing value={project.trust} size={22} stroke={2.5} showLabel={false} animate={false} />
              <span style={{ font: "500 12px 'DM Sans'", color: HW2_COLOR.ink2 }}>{project.title}</span>
            </div>
          )}
          <button style={{
            appearance: "none", background: "#fff", cursor: "pointer",
            border: `1px solid ${HW2_COLOR.rule2}`, borderRadius: 999,
            padding: "5px 12px", font: "500 12px 'DM Sans'", color: HW2_COLOR.ink,
            display: "inline-flex", alignItems: "center", gap: 6,
          }}>
            <span style={{ width: 18, height: 18, borderRadius: "50%", background: HW2_COLOR.chip, display: "grid", placeItems: "center", color: HW2_COLOR.muted, font: "600 10px 'DM Sans'" }}>N</span>
            Nupul
          </button>
        </div>
      </header>

      {/* Body: rail + main */}
      <div style={{ flex: 1, display: "flex", overflow: "hidden", minHeight: 0 }}>
        <HW2Rail
          source={source} sources={sources}
          projects={projects} route={route} onRoute={onRoute}
          onConnectSource={onConnectSource} onNewProject={onNewProject}
        />
        <main style={{ flex: 1, overflowY: "auto", background: HW2_COLOR.paper, minWidth: 0 }}>
          {/* If a project is active, mount the project banner + stepper */}
          {project ? (
            <div>
              <ProjectBanner project={project} stage={stage} onJumpStage={onJumpStage} />
              <div>{children}</div>
            </div>
          ) : children}
        </main>
      </div>
    </div>
  );
}

// ─── Left rail ───────────────────────────────────────────────────────────────
function HW2Rail({ source, sources, projects, route, onRoute, onConnectSource, onNewProject }) {
  return (
    <aside style={{
      width: 240, flexShrink: 0,
      background: "#f3f1ea",
      borderRight: `1px solid ${HW2_COLOR.rule}`,
      display: "flex", flexDirection: "column",
      overflowY: "auto",
    }}>
      {/* Source switcher */}
      <div style={{ padding: "16px 14px 8px" }}>
        <div style={{ font: "600 10px 'DM Sans'", color: HW2_COLOR.faint, letterSpacing: "0.08em", textTransform: "uppercase", marginBottom: 6, padding: "0 4px" }}>
          Source
        </div>
        <button onClick={() => onRoute({ kind: "catalog" })} style={{
          appearance: "none", cursor: "pointer", width: "100%",
          background: "#fff", border: `1px solid ${HW2_COLOR.rule2}`, borderRadius: 8,
          padding: "8px 10px", textAlign: "left",
          display: "flex", alignItems: "center", gap: 8,
          fontFamily: "'DM Sans', sans-serif",
        }}>
          <span style={{ width: 6, height: 6, borderRadius: "50%", background: HW2_COLOR.good }} />
          <span style={{ flex: 1, minWidth: 0 }}>
            <div style={{ font: "600 13px 'DM Sans'", color: HW2_COLOR.ink, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
              {source.name}
            </div>
            <div style={{ font: "500 10px 'DM Mono'", color: HW2_COLOR.muted, marginTop: 1 }}>
              {source.kind}
            </div>
          </span>
          <span style={{ color: HW2_COLOR.faint, font: "500 10px 'DM Sans'" }}>▾</span>
        </button>
        <button onClick={onConnectSource} style={{
          appearance: "none", cursor: "pointer", width: "100%",
          background: "transparent", border: "none",
          padding: "6px 4px", textAlign: "left", marginTop: 4,
          font: "500 12px 'DM Sans'", color: HW2_COLOR.muted,
        }}>
          + Connect source
        </button>
      </div>

      <Divider />

      {/* Workspace tools */}
      <RailSection label="Workspace">
        <RailItem
          active={route.kind === "catalog"}
          onClick={() => onRoute({ kind: "catalog" })}
          icon={<TableIcon />} label="Catalog"
          hint={`${source.schemas.length} schemas`} />
        <RailItem
          active={route.kind === "query"}
          onClick={() => onRoute({ kind: "query" })}
          icon={<QueryIcon />} label="Query"
          hint="SQL console" />
      </RailSection>

      <Divider />

      {/* Projects */}
      <RailSection label="Projects" action={
        <button onClick={onNewProject} style={{
          appearance: "none", background: "transparent", border: "none", cursor: "pointer",
          padding: "0 2px", color: HW2_COLOR.muted, font: "600 14px 'DM Sans'",
          lineHeight: 1,
        }} title="New project">+</button>
      }>
        {projects.length === 0 && (
          <div style={{ padding: "6px 12px", font: "400 12px 'DM Sans'", color: HW2_COLOR.faint }}>
            No projects yet.
          </div>
        )}
        {projects.map(p => (
          <RailItem
            key={p.id}
            active={route.kind === "project" && route.projectId === p.id}
            onClick={() => onRoute({ kind: "project", projectId: p.id, stage: p.stage })}
            icon={<HW2TrustRing value={p.trust} size={16} stroke={2.5} showLabel={false} animate={false} />}
            label={p.title}
            hint={`${p.questions?.length || 0} questions · ${p.trust}%`} />
        ))}
      </RailSection>

      <div style={{ flex: 1 }} />

      {/* Footer tip */}
      <div style={{ padding: "12px 14px", borderTop: `1px solid ${HW2_COLOR.rule}` }}>
        <div style={{ font: "400 11px 'DM Sans'", color: HW2_COLOR.faint, lineHeight: 1.45 }}>
          Catalog & Query are <em>power tools</em>. Projects are the guided workflow.
        </div>
      </div>
    </aside>
  );
}

function RailSection({ label, action, children }) {
  return (
    <div style={{ padding: "10px 8px 6px" }}>
      <div style={{
        display: "flex", alignItems: "center", justifyContent: "space-between",
        padding: "0 8px", marginBottom: 4,
      }}>
        <span style={{ font: "600 10px 'DM Sans'", color: HW2_COLOR.faint, letterSpacing: "0.08em", textTransform: "uppercase" }}>{label}</span>
        {action}
      </div>
      <div style={{ display: "grid", gap: 1 }}>{children}</div>
    </div>
  );
}

function RailItem({ active, onClick, icon, label, hint }) {
  return (
    <button onClick={onClick} style={{
      appearance: "none", cursor: "pointer", width: "100%",
      background: active ? "#fff" : "transparent",
      border: active ? `1px solid ${HW2_COLOR.rule2}` : "1px solid transparent",
      borderRadius: 7, padding: "7px 9px", textAlign: "left",
      display: "flex", alignItems: "center", gap: 9,
      fontFamily: "'DM Sans', sans-serif",
      boxShadow: active ? "0 1px 0 rgba(20,20,30,0.02)" : "none",
    }}>
      <span style={{ width: 18, height: 18, display: "inline-flex", alignItems: "center", justifyContent: "center", color: active ? HW2_COLOR.ink : HW2_COLOR.muted, flexShrink: 0 }}>{icon}</span>
      <span style={{ flex: 1, minWidth: 0 }}>
        <div style={{ font: `${active ? 600 : 500} 13px 'DM Sans'`, color: active ? HW2_COLOR.ink : HW2_COLOR.ink2, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{label}</div>
        {hint && <div style={{ font: "400 10.5px 'DM Sans'", color: HW2_COLOR.muted, marginTop: 1, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{hint}</div>}
      </span>
    </button>
  );
}

function Divider() {
  return <div style={{ height: 1, background: HW2_COLOR.rule, margin: "4px 14px" }} />;
}

// ─── Project banner (only when project is open) ──────────────────────────────
function ProjectBanner({ project, stage, onJumpStage }) {
  return (
    <section style={{
      padding: "22px 32px 14px",
      background: HW2_COLOR.paper,
      borderBottom: `1px solid ${HW2_COLOR.rule}`,
      position: "sticky", top: 0, zIndex: 5,
    }}>
      <div style={{ display: "flex", alignItems: "center", gap: 22, marginBottom: 16 }}>
        <HW2TrustRing value={project.trust} size={60} stroke={5} showLabel={false} />
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 4 }}>
            <span style={{ font: "600 10px 'DM Sans'", color: HW2_COLOR.muted, letterSpacing: "0.07em", textTransform: "uppercase" }}>Project goal</span>
            <HW2Chip tone={trustChipTone(project.trust)} style={{ padding: "2px 8px" }}>
              {project.trust}% · {trustTone(project.trust).label}
            </HW2Chip>
            <span style={{ font: "500 11px 'DM Mono'", color: HW2_COLOR.faint }}>
              {project.questions?.length || 0} {project.questions?.length === 1 ? "question" : "questions"}
            </span>
          </div>
          <h1 style={{
            font: "600 22px 'DM Sans'", letterSpacing: "-0.02em",
            color: HW2_COLOR.ink, lineHeight: 1.25,
          }}>{project.goal}</h1>
        </div>
        <div style={{ display: "flex", flexDirection: "column", alignItems: "flex-end", gap: 4 }}>
          <span style={{ font: "500 11px 'DM Mono'", color: HW2_COLOR.faint }}>
            {project.selectedTables.length} tables
          </span>
          <span style={{ font: "400 11px 'DM Sans'", color: HW2_COLOR.muted }}>
            {project.lastTouched}
          </span>
        </div>
      </div>
      <HW2Stepper current={stage} onJump={onJumpStage} project={project} />
    </section>
  );
}

function trustChipTone(v) {
  if (v >= 75) return "good";
  if (v >= 50) return "blue";
  if (v >= 20) return "warn";
  return "muted";
}

// ─── Tiny icons (1-color SVG strokes) ────────────────────────────────────────
const stroke = HW2_COLOR.muted;
function TableIcon() {
  return (
    <svg width="14" height="14" viewBox="0 0 16 16" fill="none">
      <rect x="2" y="3" width="12" height="10" rx="1.2" stroke="currentColor" strokeWidth="1.3" />
      <line x1="2" y1="6.5" x2="14" y2="6.5" stroke="currentColor" strokeWidth="1.3" />
      <line x1="6" y1="6.5" x2="6" y2="13" stroke="currentColor" strokeWidth="1.3" />
    </svg>
  );
}
function QueryIcon() {
  return (
    <svg width="14" height="14" viewBox="0 0 16 16" fill="none">
      <path d="M3 5l3 3-3 3" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round" />
      <line x1="8.5" y1="11.2" x2="13" y2="11.2" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" />
    </svg>
  );
}

Object.assign(window, { HW2Shell, trustChipTone, ProjectBanner });
