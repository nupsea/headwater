// hw-model-query.jsx — Model ERD diagram + Data & Query tab

const { useState, useRef } = React;
const D = window.HW;
const { TypeBadge, NullBar, SectionLabel, PanelCard, Btn } = window;

// ─── Node layout for relationship diagram ─────────────────────────────────────

const ERD_NODES = [
  { id:"zones",       cx:140,  cy:200, w:150, h:82, label:"zones",       pk:"zone_id",    rows:25,    domain:"Geographic"    },
  { id:"sites",       cx:340,  cy:100, w:150, h:82, label:"sites",       pk:"site_id",    rows:500,   domain:"Operational"   },
  { id:"sensors",     cx:560,  cy:100, w:150, h:82, label:"sensors",     pk:"sensor_id",  rows:832,   domain:"Operational"   },
  { id:"readings",    cx:730,  cy:240, w:150, h:82, label:"readings",    pk:"reading_id", rows:49302, domain:"Environmental" },
  { id:"inspections", cx:340,  cy:310, w:150, h:82, label:"inspections", pk:"insp_id",    rows:1243,  domain:"Compliance"    },
  { id:"incidents",   cx:560,  cy:310, w:150, h:82, label:"incidents",   pk:"incident_id",rows:5000,  domain:"Compliance"    },
  { id:"complaints",  cx:80,   cy:360, w:150, h:72, label:"complaints",  pk:"complaint_id",rows:3000, domain:"Compliance"    },
  { id:"programs",    cx:730,  cy:80,  w:150, h:72, label:"programs",    pk:"program_id", rows:10,    domain:"Environmental" },
];

const ERD_EDGES = [
  { from:"sites",       to:"zones",   fk:"zone_id",   integrity:1.00 },
  { from:"sensors",     to:"sites",   fk:"site_id",   integrity:0.99 },
  { from:"readings",    to:"sensors", fk:"sensor_id", integrity:1.00 },
  { from:"inspections", to:"sites",   fk:"site_id",   integrity:1.00 },
  { from:"incidents",   to:"zones",   fk:"zone_id",   integrity:1.00 },
  { from:"incidents",   to:"sites",   fk:"site_id",   integrity:0.96 },
  { from:"complaints",  to:"zones",   fk:"zone_id",   integrity:0.98 },
  { from:"programs",    to:"zones",   fk:"zone_id",   integrity:1.00 },
];

function nodeById(id) { return ERD_NODES.find(n => n.id === id); }

// Compute edge endpoint: choose the face of each box closest to the other node
function edgePoints(fromId, toId) {
  const a = nodeById(fromId), b = nodeById(toId);
  if (!a || !b) return { x1:0,y1:0,x2:0,y2:0 };
  const ax1=a.cx-a.w/2, ax2=a.cx+a.w/2, ay1=a.cy-a.h/2, ay2=a.cy+a.h/2;
  const bx1=b.cx-b.w/2, bx2=b.cx+b.w/2, by1=b.cy-b.h/2, by2=b.cy+b.h/2;
  // Horizontal separation
  let x1,y1,x2,y2;
  if (a.cx < b.cx - 10) { x1=ax2; x2=bx1; }
  else if (a.cx > b.cx + 10) { x1=ax1; x2=bx2; }
  else { x1=a.cx; x2=b.cx; }
  if (a.cy < b.cy - 10) { y1=ay2; y2=by1; }
  else if (a.cy > b.cy + 10) { y1=ay1; y2=by2; }
  else { y1=a.cy; y2=b.cy; }
  // Refine: use center Y if horizontally separated
  if (a.cx < b.cx - 10 || a.cx > b.cx + 10) { y1=a.cy; y2=b.cy; }
  if (a.cy < b.cy - 10 || a.cy > b.cy + 10) { x1=a.cx; x2=b.cx; }
  return { x1,y1,x2,y2 };
}

// ─── Model Tab: ERD ───────────────────────────────────────────────────────────

function ModelTab({ onNavigateTable }) {
  const [hovered, setHovered] = useState(null);
  const [tooltip, setTooltip] = useState(null);
  const W = 860, H = 460;

  return (
    <div style={{ maxWidth:900 }}>
      <div style={{ marginBottom:16 }}>
        <SectionLabel>Model · relationship diagram</SectionLabel>
        <h1 style={{ fontSize:22, fontWeight:700, letterSpacing:"-0.03em" }}>Table relationships</h1>
        <p style={{ fontSize:13, color:"#64748b", marginTop:5 }}>Foreign key connections across 8 tables. Click any table to open its profile in Discover &amp; Assess.</p>
      </div>

      {/* Legend */}
      <div style={{ display:"flex", gap:14, marginBottom:14, flexWrap:"wrap" }}>
        {Object.entries(D.domainColors).map(([d,c]) => (
          <div key={d} style={{ display:"flex", alignItems:"center", gap:5 }}>
            <div style={{ width:10, height:10, borderRadius:2, background:c }} />
            <span style={{ fontSize:11, color:"#64748b" }}>{d}</span>
          </div>
        ))}
        <div style={{ display:"flex", alignItems:"center", gap:5, marginLeft:8 }}>
          <div style={{ width:20, height:2, background:"#4f46e5" }} />
          <span style={{ fontSize:11, color:"#64748b" }}>100% integrity</span>
        </div>
        <div style={{ display:"flex", alignItems:"center", gap:5 }}>
          <div style={{ width:20, height:2, background:"#d97706", borderTop:"2px dashed #d97706", height:0 }} />
          <span style={{ fontSize:11, color:"#64748b" }}>&lt;100% integrity</span>
        </div>
      </div>

      <PanelCard style={{ overflow:"hidden", position:"relative" }}>
        <svg width="100%" viewBox={`0 0 ${W} ${H}`} style={{ display:"block" }}>
          {/* Edges */}
          {ERD_EDGES.map((e, i) => {
            const { x1,y1,x2,y2 } = edgePoints(e.from, e.to);
            const mx = (x1+x2)/2, my = (y1+y2)/2;
            const isWeak = e.integrity < 1;
            const col = isWeak ? "#d97706" : "#4f46e5";
            return (
              <g key={i}
                onMouseEnter={() => setTooltip({ x:mx, y:my, edge:e })}
                onMouseLeave={() => setTooltip(null)}>
                <line x1={x1} y1={y1} x2={x2} y2={y2}
                  stroke={col} strokeWidth={isWeak ? 1.5 : 2}
                  strokeDasharray={isWeak ? "5 3" : "none"} opacity={0.5} />
                {/* FK label */}
                <text x={mx} y={my-5} textAnchor="middle" fontSize={9} fill={col} opacity={0.8} fontFamily="DM Mono, monospace">{e.fk}</text>
                {/* Integrity badge */}
                {isWeak && <text x={mx} y={my+12} textAnchor="middle" fontSize={8} fill={col} opacity={0.7} fontFamily="DM Mono, monospace">{Math.round(e.integrity*100)}%</text>}
              </g>
            );
          })}

          {/* Nodes */}
          {ERD_NODES.map(node => {
            const isHov = hovered === node.id;
            const col = D.domainColors[node.domain] || "#64748b";
            const x = node.cx - node.w/2, y = node.cy - node.h/2;
            return (
              <g key={node.id}
                style={{ cursor:"pointer" }}
                onMouseEnter={() => setHovered(node.id)}
                onMouseLeave={() => setHovered(null)}
                onClick={() => onNavigateTable(node.id)}>
                {/* Shadow */}
                <rect x={x+2} y={y+2} width={node.w} height={node.h} rx={8} fill="rgba(0,0,0,0.06)" />
                {/* Card */}
                <rect x={x} y={y} width={node.w} height={node.h} rx={8}
                  fill={isHov ? "#f8faff" : "#fff"}
                  stroke={isHov ? col : "#e2e8f0"}
                  strokeWidth={isHov ? 2 : 1} />
                {/* Color accent top bar */}
                <rect x={x} y={y} width={node.w} height={4} rx={4} fill={col} />
                <rect x={x} y={y+2} width={node.w} height={2} fill={col} />
                {/* Table name */}
                <text x={node.cx} y={y+22} textAnchor="middle" fontSize={12} fontWeight="700" fill={isHov ? col : "#0f172a"} fontFamily="DM Mono, monospace">{node.label}</text>
                {/* PK */}
                <text x={x+10} y={y+38} fontSize={9} fill="#a16207" fontFamily="DM Mono, monospace">🔑 {node.pk}</text>
                {/* Row count */}
                <text x={node.cx} y={y+node.h-12} textAnchor="middle" fontSize={9} fill="#94a3b8" fontFamily="DM Sans, sans-serif">{node.rows.toLocaleString()} rows</text>
                {/* Domain badge */}
                <rect x={node.cx + node.w/2 - 56} y={y+node.h-22} width={52} height={14} rx={3} fill={col} opacity={0.12} />
                <text x={node.cx + node.w/2 - 30} y={y+node.h-12} textAnchor="middle" fontSize={8} fill={col} fontWeight="600" fontFamily="DM Sans, sans-serif">{node.domain}</text>
              </g>
            );
          })}

          {/* Hover tooltip */}
          {tooltip && (
            <g>
              <rect x={tooltip.x-70} y={tooltip.y-26} width={140} height={34} rx={5} fill="#0f172a" opacity={0.88} />
              <text x={tooltip.x} y={tooltip.y-13} textAnchor="middle" fontSize={10} fill="#fff" fontFamily="DM Mono, monospace">{tooltip.edge.from} → {tooltip.edge.to}</text>
              <text x={tooltip.x} y={tooltip.y+2} textAnchor="middle" fontSize={9} fill="#94a3b8" fontFamily="DM Sans, sans-serif">via {tooltip.edge.fk} · {Math.round(tooltip.edge.integrity*100)}% integrity</text>
            </g>
          )}
        </svg>
      </PanelCard>

      {/* Edge table */}
      <PanelCard style={{ marginTop:16 }}>
        <table style={{ width:"100%", borderCollapse:"collapse" }}>
          <thead>
            <tr style={{ borderBottom:"2px solid #f1f5f9" }}>
              {["From","Via FK","To","Integrity"].map(h => (
                <th key={h} style={{ padding:"9px 14px", textAlign:"left", fontSize:10, fontWeight:700, color:"#94a3b8", textTransform:"uppercase", letterSpacing:"0.06em" }}>{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {ERD_EDGES.map((e, i) => (
              <tr key={i} style={{ borderBottom: i<ERD_EDGES.length-1?"1px solid #f1f5f9":"none" }}>
                <td style={{ padding:"9px 14px", fontFamily:"'DM Mono',monospace", fontSize:12, color:"#0f172a" }}>{e.from}</td>
                <td style={{ padding:"9px 14px", fontFamily:"'DM Mono',monospace", fontSize:11, color:"#64748b" }}>{e.fk}</td>
                <td style={{ padding:"9px 14px", fontFamily:"'DM Mono',monospace", fontSize:12, color:"#0f172a" }}>{e.to}</td>
                <td style={{ padding:"9px 14px" }}>
                  <div style={{ display:"flex", alignItems:"center", gap:8 }}>
                    <div style={{ width:60, height:4, background:"#f1f5f9", borderRadius:2, overflow:"hidden" }}>
                      <div style={{ height:"100%", width:`${e.integrity*100}%`, background: e.integrity===1?"#16a34a":"#d97706", borderRadius:2 }} />
                    </div>
                    <span style={{ fontSize:11, fontFamily:"'DM Mono',monospace", color: e.integrity===1?"#16a34a":"#d97706" }}>{(e.integrity*100).toFixed(0)}%</span>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </PanelCard>
    </div>
  );
}

// ─── Data & Query Tab ─────────────────────────────────────────────────────────

const CANNED_SQL = {
  readings:    "SELECT reading_id, sensor_id, timestamp,\n       pm25_value, quality_flag\nFROM readings\nLIMIT 10;",
  zones:       "SELECT zone_id, name, region, population,\n       industrial_index\nFROM zones\nORDER BY industrial_index DESC;",
  incidents:   "SELECT incident_id, zone_id, incident_date,\n       severity_tier, resolution_days\nFROM incidents\nWHERE severity_tier IS NOT NULL\nLIMIT 10;",
  sensors:     "SELECT sensor_id, site_id, sensor_type,\n       is_active, last_reading\nFROM sensors\nLIMIT 10;",
};

function DataQueryTab() {
  const [expandedSchema, setExpandedSchema] = useState(true);
  const [activeTable, setActiveTable] = useState("readings");
  const [sql, setSql] = useState(CANNED_SQL.readings);
  const [result, setResult] = useState(D.queryResults.default);
  const [running, setRunning] = useState(false);

  const runQuery = () => {
    setRunning(true);
    setTimeout(() => {
      const lower = sql.toLowerCase();
      const res = lower.includes("zones") ? D.queryResults.zones
                : lower.includes("incident") ? D.queryResults.incidents
                : D.queryResults.default;
      setResult(res);
      setRunning(false);
    }, 600);
  };

  const selectTable = (tbl) => {
    setActiveTable(tbl);
    setSql(CANNED_SQL[tbl] || `SELECT *\nFROM ${tbl}\nLIMIT 10;`);
    setResult(D.queryResults[tbl] || D.queryResults.default);
  };

  return (
    <div style={{ display:"flex", gap:0, height:"100%", minHeight:600 }}>
      {/* Catalog tree sidebar */}
      <div style={{ width:196, flexShrink:0, borderRight:"1px solid #e2e8f0", paddingRight:0 }}>
        <div style={{ fontSize:10, fontWeight:700, color:"#94a3b8", textTransform:"uppercase", letterSpacing:"0.08em", padding:"0 2px", marginBottom:8 }}>Catalog</div>

        {/* Project node */}
        <div style={{ fontSize:12, fontWeight:600, color:"#0f172a", marginBottom:4, display:"flex", alignItems:"center", gap:6 }}>
          <span style={{ fontSize:10 }}>📁</span>
          <span>Env Health DB</span>
        </div>

        {/* Schema node */}
        <div style={{ paddingLeft:14 }}>
          <button onClick={() => setExpandedSchema(p=>!p)} style={{ display:"flex", alignItems:"center", gap:5, fontSize:12, color:"#475569", background:"none", border:"none", cursor:"pointer", fontFamily:"inherit", marginBottom:4, padding:"2px 0" }}>
            <span style={{ fontSize:10, transform: expandedSchema?"rotate(90deg)":"none", display:"inline-block", transition:"transform 0.15s" }}>▶</span>
            <span style={{ fontSize:10 }}>📂</span>
            <span>public (schema)</span>
          </button>

          {expandedSchema && (
            <div style={{ paddingLeft:16 }}>
              {D.tables.map(t => (
                <button key={t.name} onClick={() => selectTable(t.name)} style={{ display:"flex", alignItems:"center", justifyContent:"space-between", width:"100%", padding:"5px 8px", borderRadius:6, border:"none", cursor:"pointer", fontFamily:"inherit", background: activeTable===t.name ? "#eef2ff" : "transparent", marginBottom:1 }}>
                  <div style={{ display:"flex", alignItems:"center", gap:5 }}>
                    <span style={{ fontSize:10 }}>📄</span>
                    <span style={{ fontFamily:"'DM Mono',monospace", fontSize:11, color: activeTable===t.name ? "#4f46e5" : "#475569" }}>{t.name}</span>
                  </div>
                  <span style={{ fontSize:9, color:"#94a3b8" }}>{t.rows >= 1000 ? (t.rows/1000).toFixed(0)+"K" : t.rows}</span>
                </button>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Editor + results */}
      <div style={{ flex:1, paddingLeft:20, display:"flex", flexDirection:"column", gap:14, overflow:"hidden" }}>
        {/* SQL editor */}
        <div>
          <div style={{ display:"flex", alignItems:"center", justifyContent:"space-between", marginBottom:8 }}>
            <div style={{ fontSize:11, fontWeight:700, color:"#94a3b8", textTransform:"uppercase", letterSpacing:"0.08em" }}>SQL Editor</div>
            <div style={{ display:"flex", gap:8 }}>
              <Btn onClick={runQuery} style={{ fontSize:11, background: running?"#818cf8":"#4f46e5" }}>{running ? "Running…" : "▶  Run"}</Btn>
              <Btn variant="ghost" style={{ fontSize:11 }}>Format</Btn>
            </div>
          </div>
          <div style={{ position:"relative", background:"#0f172a", borderRadius:10, overflow:"hidden", border:"1px solid #334155" }}>
            {/* Line numbers */}
            <div style={{ position:"absolute", left:0, top:0, bottom:0, width:32, background:"#0f1629", borderRight:"1px solid #1e293b", display:"flex", flexDirection:"column", alignItems:"center", paddingTop:12, userSelect:"none" }}>
              {sql.split("\n").map((_, i) => (
                <div key={i} style={{ fontSize:11, color:"#475569", lineHeight:"22px", fontFamily:"'DM Mono',monospace" }}>{i+1}</div>
              ))}
            </div>
            <textarea
              value={sql}
              onChange={e => setSql(e.target.value)}
              onKeyDown={e => { if (e.key==="Tab"){e.preventDefault(); const s=e.target.selectionStart; setSql(p => p.slice(0,s)+"  "+p.slice(e.target.selectionEnd));} }}
              spellCheck={false}
              style={{ display:"block", width:"100%", minHeight:130, paddingLeft:44, paddingTop:12, paddingRight:16, paddingBottom:12, background:"transparent", border:"none", outline:"none", fontSize:13, fontFamily:"'DM Mono',monospace", color:"#e2e8f0", lineHeight:"22px", resize:"vertical" }}
            />
          </div>
        </div>

        {/* Results */}
        {result && (
          <div style={{ flex:1, overflowY:"auto" }}>
            <div style={{ display:"flex", alignItems:"center", justifyContent:"space-between", marginBottom:8 }}>
              <div style={{ fontSize:11, fontWeight:700, color:"#94a3b8", textTransform:"uppercase", letterSpacing:"0.08em" }}>Results</div>
              <div style={{ fontSize:11, color:"#94a3b8" }}>{result.rows.length} rows</div>
            </div>
            <PanelCard>
              <div style={{ overflowX:"auto" }}>
                <table style={{ width:"100%", borderCollapse:"collapse", minWidth:500 }}>
                  <thead>
                    <tr style={{ background:"#f8fafc", borderBottom:"2px solid #e2e8f0" }}>
                      {result.columns.map(col => (
                        <th key={col} style={{ padding:"8px 12px", textAlign:"left", fontSize:10, fontWeight:700, color:"#64748b", fontFamily:"'DM Mono',monospace", whiteSpace:"nowrap", textTransform:"uppercase", letterSpacing:"0.05em" }}>{col}</th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {result.rows.map((row, ri) => (
                      <tr key={ri} style={{ background: ri%2===0?"#fff":"#f8fafc", borderBottom:"1px solid #f1f5f9" }}>
                        {row.map((cell, ci) => (
                          <td key={ci} style={{ padding:"8px 12px", fontSize:12, fontFamily:"'DM Mono',monospace", color: cell===null?"#cbd5e1": cell==="hazardous"?"#dc2626": cell==="unhealthy_sg"?"#d97706": "inherit", background: cell===null?"#fef2f2":"inherit", fontStyle: cell===null?"italic":"normal", whiteSpace:"nowrap" }}>
                            {cell===null ? "null" : String(cell)}
                          </td>
                        ))}
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </PanelCard>
          </div>
        )}
      </div>
    </div>
  );
}

// ─── Page: Model · Data · Query (tabbed) ─────────────────────────────────────

function AModelDataQuery({ appState, onApproveModel, initialTab }) {
  const [tab, setTab] = useState(initialTab || "model");
  React.useEffect(() => { if (initialTab) setTab(initialTab); }, [initialTab]);
  const [navigatedTable, setNavigatedTable] = useState(null);

  // If user clicks a node on ERD, navigate to discover page for that table
  const handleNavigate = (tableId) => {
    setNavigatedTable(tableId);
    // Signal parent to switch to discover page — done via global event
    window.dispatchEvent(new CustomEvent("hw-navigate", { detail:{ page:"discover", table:tableId } }));
  };

  const tabs = [
    { key:"model",     label:"Model" },
    { key:"data-query",label:"Data & Query" },
    { key:"review",    label:"Review Queue" },
  ];

  return (
    <div style={{ maxWidth:"100%" }}>
      {/* Tab bar */}
      <div style={{ display:"flex", gap:0, borderBottom:"2px solid #e2e8f0", marginBottom:24 }}>
        {tabs.map(t => (
          <button key={t.key} onClick={() => setTab(t.key)} style={{ padding:"9px 20px", border:"none", background:"transparent", cursor:"pointer", fontFamily:"inherit", fontSize:13, fontWeight: tab===t.key?600:400, color: tab===t.key?"#4f46e5":"#64748b", borderBottom: tab===t.key?"2px solid #4f46e5":"2px solid transparent", marginBottom:-2, transition:"all 0.15s" }}>
            {t.label}
          </button>
        ))}
      </div>

      {tab === "model"      && <ModelTab onNavigateTable={handleNavigate} />}
      {tab === "data-query" && <DataQueryTab />}
      {tab === "review"     && <ReviewTab appState={appState} onApproveModel={onApproveModel} />}
    </div>
  );
}

function ReviewTab({ appState, onApproveModel }) {
  const [rejected, setRejected] = useState([]);
  const models = D.queue.filter(q => q.type === "model");

  const SQL = {
    1: "SELECT z.zone_id, z.name,\n  COUNT(i.id)           AS incident_count,\n  AVG(i.severity_score) AS avg_severity\nFROM incidents i\nJOIN zones z ON i.zone_id = z.zone_id\nGROUP BY z.zone_id, z.name",
    2: "SELECT date_trunc('month', timestamp) AS month,\n  AVG(pm25_value) AS avg_pm25,\n  MAX(pm25_value) AS peak_pm25\nFROM readings\nWHERE pm25_value IS NOT NULL\nGROUP BY 1 ORDER BY 1",
    3: "SELECT z.zone_id, z.name,\n  COUNT(DISTINCT i.id) AS inspections,\n  AVG(i.score)         AS avg_score,\n  COUNT(inc.id)        AS incidents\nFROM zones z\nLEFT JOIN inspections i ON i.site_id IN (SELECT site_id FROM sites WHERE zone_id=z.zone_id)\nLEFT JOIN incidents inc ON inc.zone_id=z.zone_id\nGROUP BY z.zone_id, z.name",
  };

  return (
    <div style={{ maxWidth:760 }}>
      <div style={{ marginBottom:20 }}>
        <SectionLabel>Review Queue · mart models</SectionLabel>
        <h2 style={{ fontSize:20, fontWeight:700, letterSpacing:"-0.02em" }}>Approve proposed mart models</h2>
        <p style={{ fontSize:13, color:"#64748b", marginTop:5 }}>Individual approval required. Review SQL and generated assumptions before execution.</p>
      </div>

      {appState.approvedModels.length === 3 && (
        <div style={{ padding:"12px 16px", background:"#f0fdf4", border:"1px solid #bbf7d0", borderRadius:10, marginBottom:16, fontSize:13, color:"#166534" }}>✓ All models approved. Execute when ready.</div>
      )}

      {models.map(m => {
        const approved = appState.approvedModels.includes(m.id);
        const isRejected = rejected.includes(m.id);
        return (
          <PanelCard key={m.id} style={{ padding:"16px 20px", marginBottom:10, borderColor: approved?"#bbf7d0":isRejected?"#fecaca":"#e2e8f0" }}>
            <div style={{ display:"flex", alignItems:"flex-start", justifyContent:"space-between", gap:12 }}>
              <div>
                <span style={{ fontFamily:"'DM Mono',monospace", fontSize:14, fontWeight:600, color:"#0f172a" }}>{m.label}</span>
                <div style={{ fontSize:12, color:"#94a3b8", marginTop:4 }}>{m.note}</div>
              </div>
              {approved && <span style={{ fontSize:11, color:"#16a34a", padding:"5px 12px", background:"#f0fdf4", border:"1px solid #bbf7d0", borderRadius:6, flexShrink:0 }}>✓ Approved</span>}
              {isRejected && <span style={{ fontSize:11, color:"#dc2626", padding:"5px 12px", background:"#fef2f2", border:"1px solid #fecaca", borderRadius:6, flexShrink:0 }}>✗ Rejected</span>}
              {!approved && !isRejected && (
                <div style={{ display:"flex", gap:8, flexShrink:0 }}>
                  <Btn onClick={() => onApproveModel(m.id)}>Approve</Btn>
                  <Btn variant="ghost">View SQL</Btn>
                  <Btn variant="danger" onClick={() => setRejected(p => [...p, m.id])}>Reject</Btn>
                </div>
              )}
            </div>
            {!approved && !isRejected && SQL[m.id] && (
              <pre style={{ marginTop:12, padding:"12px 14px", background:"#0f172a", borderRadius:8, fontFamily:"'DM Mono',monospace", fontSize:11, color:"#94a3b8", lineHeight:1.7, overflowX:"auto" }}>{SQL[m.id]}</pre>
            )}
          </PanelCard>
        );
      })}
    </div>
  );
}

Object.assign(window, { AModelDataQuery });
