# Headwater UI — Integration Notes for `nupsea/headwater`

This document maps the design prototype additions onto your existing Next.js codebase at `headwater/ui/` so you can wire them into your real backend.

---

## 1. New routes to add

Mirror the prototype's structure under `headwater/ui/src/app/`:

```
src/app/
├── briefing/page.tsx        # NEW — narrative dashboard, default landing
├── sources/
│   ├── page.tsx             # NEW — connected sources list
│   └── new/page.tsx         # NEW — add source wizard
├── data/page.tsx            # existing
├── ...
```

Recommended: make `briefing/page.tsx` the new homepage (replace the redirect on `/`).

---

## 2. Backend endpoints needed

These don't exist yet in `headwater/` — you'll need to add them. Suggested REST shape:

```
GET  /api/sources                  → list of connected sources
POST /api/sources                  → register a new source
GET  /api/sources/:id              → source detail
POST /api/sources/:id/sync         → trigger sync
DEL  /api/sources/:id              → disconnect

GET  /api/briefing/today           → priorities + wins for today's briefing
```

The `briefing` endpoint should aggregate signals you already compute:
- pending review queue counts (already in your status response)
- drift events (new — needs a drift-detection job)
- failed syncs (new — needs sync history table)
- recent quality contract failures (already computed)

---

## 3. Database schema additions

Two new tables in your headwater meta-database:

```sql
CREATE TABLE sources (
  id          UUID PRIMARY KEY,
  name        TEXT NOT NULL,
  type        TEXT NOT NULL,       -- postgres | mysql | snowflake | bigquery | ...
  config      JSONB NOT NULL,      -- DSN, host, schema filter, etc. (encrypt creds)
  status      TEXT NOT NULL,       -- healthy | warning | error | idle
  health      INTEGER,             -- 0–100
  last_sync_at TIMESTAMPTZ,
  created_at  TIMESTAMPTZ DEFAULT now()
);

CREATE TABLE sync_events (
  id          UUID PRIMARY KEY,
  source_id   UUID REFERENCES sources(id),
  event_type  TEXT NOT NULL,       -- sync_complete | drift | schema_change | error
  detail      JSONB,
  created_at  TIMESTAMPTZ DEFAULT now()
);
```

Your existing project context becomes scoped *per source* — every table/column profile should now carry a `source_id` FK.

---

## 4. Connector abstraction

In your Python backend (`headwater/headwater/`), generalize the existing PostgreSQL connector:

```python
# headwater/connectors/base.py
class Connector(Protocol):
    def list_schemas(self) -> list[str]: ...
    def list_tables(self, schema: str) -> list[Table]: ...
    def profile_column(self, schema, table, column) -> ColumnProfile: ...
    def execute_sql(self, sql: str) -> ResultSet: ...

# headwater/connectors/postgres.py   ← refactor existing code here
# headwater/connectors/mysql.py      ← new (use sqlalchemy + pymysql)
# headwater/connectors/snowflake.py  ← new (snowflake-connector-python)
# headwater/connectors/bigquery.py   ← new (google-cloud-bigquery)
# headwater/connectors/duckdb.py     ← new (already easy)
```

A factory (`get_connector(source.type, source.config)`) keeps the rest of your pipeline unchanged.

---

## 5. Drift detection (powers Briefing #2)

Run on every sync. Compare current profile against the locked baseline:

```python
def detect_drift(prev: ColumnProfile, curr: ColumnProfile) -> DriftEvent | None:
    # numeric: compare p50 / p95 / null_pct movements
    # categorical: compare top_values distribution
    # threshold: > 10% shift in any moment → emit drift event
```

Emitted events show up in `sync_events` and feed the Briefing's priority list.

---

## 6. Frontend wiring

The prototype JSX is plain React — port to Next.js by:

1. Copying the components from `hw-sources.jsx` and `hw-pages-a.jsx` (the briefing function `ABriefing`) into `src/components/`
2. Replacing `useState` mock data with `fetch` calls to your new endpoints (or use SWR / React Query for caching)
3. Replacing inline styles with Tailwind classes (your existing convention) — the design uses your CSS vars (`--background`, `--foreground`, `--card`, `--border`)

Quick mapping for Tailwind:
- `#0f172a` → `text-slate-900`
- `#64748b` → `text-slate-500`
- `#4f46e5` → `text-indigo-600` / `bg-indigo-600`
- `#16a34a` → `text-green-600`
- `#d97706` → `text-amber-600`
- `#dc2626` → `text-red-600`
- `'DM Mono'` → already loaded as `font-mono` if you import it in `layout.tsx`

---

## 7. Suggested rollout order

1. **Sources schema + connector abstraction** (backend, ~2 days). Multi-source is the foundation — everything else depends on it.
2. **Sources page UI** (~1 day). Port the JSX.
3. **Drift detection job** (~1 day). Cron or post-sync hook.
4. **Briefing endpoint + page** (~1 day). Aggregate from existing data.
5. **Make briefing the homepage** (~30 min). Add a "Switch to dashboard" link for power users.

You can ship Sources without Briefing, but not the other way around.

---

## 8. Testing locally

The prototype uses pure mock data — to test against the real backend:

1. Run `headwater/` services (compose up)
2. Replace fetches in the ported components with your API URLs (`/api/sources`, etc.)
3. Use your existing `seed.sql` for one source; add a second source manually (e.g. SQLite or DuckDB) to verify multi-source flows

---

## 9. What's intentionally left out

- **Auth on sources** — assumed your platform handles team access; encrypt `sources.config` server-side
- **Connector marketplace icons** — the prototype uses SVG placeholders; swap for official brand SVGs from each vendor's press kit
- **Real drift visualization** — the prototype shows the alert; the actual drift report (sparkline + before/after distributions) is a follow-on design

Ping back when you've stood up the Sources endpoint — I can iterate on the schema-change visualization and lineage view next.
