// Headwater 2 — Catalog browser (workspace-level power tool).
// Schema tree + per-table detail with editable metadata, locks, sample rows.

function HW2Catalog({ source, catalogColumns, sampleRows, onOpenQuery }) {
  // Auto-pick the first selected table
  const initialFqn = (() => {
    for (const s of source.schemas) {
      const t = s.tables.find(tt => tt.selected);
      if (t) return `${s.name}.${t.name}`;
    }
    return `${source.schemas[0].name}.${source.schemas[0].tables[0].name}`;
  })();
  const [active, setActive] = React.useState(initialFqn);
  const [openSchema, setOpenSchema] = React.useState(() =>
    Object.fromEntries(source.schemas.map(s => [s.name, true]))
  );

  const [schemaName, tableName] = active.split(".");
  const schema = source.schemas.find(s => s.name === schemaName);
  const table = schema?.tables.find(t => t.name === tableName);
  const cols = catalogColumns[active] || [];
  const samples = sampleRows[active] || null;

  return (
    <div style={{ display: "grid", gridTemplateColumns: "260px 1fr", minHeight: "calc(100vh - 48px)" }}>

      {/* Schema tree */}
      <aside style={{
        background: "#fff", borderRight: `1px solid ${HW2_COLOR.rule}`,
        padding: "18px 14px", overflowY: "auto",
      }}>
        <div style={{ display: "flex", alignItems: "baseline", justifyContent: "space-between", marginBottom: 8, padding: "0 4px" }}>
          <span style={{ font: "600 10px 'DM Sans'", color: HW2_COLOR.muted, letterSpacing: "0.08em", textTransform: "uppercase" }}>
            {source.name}
          </span>
          <span style={{ font: "500 10px 'DM Mono'", color: HW2_COLOR.faint }}>
            {source.schemas.reduce((a, s) => a + s.tables.length, 0)} tables
          </span>
        </div>
        {source.schemas.map(s => (
          <div key={s.name} style={{ marginBottom: 4 }}>
            <button onClick={() => setOpenSchema(p => ({ ...p, [s.name]: !p[s.name] }))} style={{
              appearance: "none", background: "transparent", border: "none", cursor: "pointer",
              width: "100%", textAlign: "left", padding: "5px 6px", borderRadius: 6,
              display: "flex", alignItems: "center", gap: 6,
              font: "600 12px 'DM Sans'", color: HW2_COLOR.ink,
              fontFamily: "'DM Sans', sans-serif",
            }}>
              <span style={{ width: 10, color: HW2_COLOR.faint, font: "500 10px 'DM Mono'" }}>
                {openSchema[s.name] ? "▾" : "▸"}
              </span>
              <span>{s.name}</span>
              <span style={{ marginLeft: "auto", font: "500 10px 'DM Mono'", color: HW2_COLOR.faint }}>
                {s.tables.filter(t => t.selected).length}/{s.tables.length}
              </span>
            </button>
            {openSchema[s.name] && (
              <div style={{ paddingLeft: 18, display: "grid", gap: 1 }}>
                {s.tables.map(t => {
                  const fqn = `${s.name}.${t.name}`;
                  const isActive = fqn === active;
                  return (
                    <button key={t.name} onClick={() => setActive(fqn)} style={{
                      appearance: "none", cursor: "pointer", width: "100%", textAlign: "left",
                      background: isActive ? HW2_COLOR.blueSoft : "transparent",
                      border: "none", borderRadius: 6, padding: "4px 8px",
                      display: "flex", alignItems: "center", gap: 7,
                      fontFamily: "'DM Sans', sans-serif",
                      color: isActive ? HW2_COLOR.blue : HW2_COLOR.ink2,
                    }}>
                      <span style={{
                        width: 6, height: 6, borderRadius: 2,
                        background: t.selected ? HW2_COLOR.good : HW2_COLOR.rule2,
                        flexShrink: 0,
                      }} />
                      <span style={{ font: "500 12px 'DM Mono'", flex: 1, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
                        {t.name}
                      </span>
                      <span style={{ font: "500 10px 'DM Mono'", color: isActive ? HW2_COLOR.blue : HW2_COLOR.faint }}>
                        {t.rows >= 1000 ? `${(t.rows/1000).toFixed(1)}k` : t.rows}
                      </span>
                    </button>
                  );
                })}
              </div>
            )}
          </div>
        ))}
      </aside>

      {/* Table detail */}
      <section style={{ padding: "28px 32px 60px", overflowY: "auto" }}>
        {!table ? (
          <div style={{ color: HW2_COLOR.muted, font: "500 14px 'DM Sans'" }}>Select a table</div>
        ) : (
          <div>
            <div style={{ display: "flex", alignItems: "flex-end", justifyContent: "space-between", marginBottom: 16 }}>
              <div>
                <div style={{ font: "500 11px 'DM Mono'", color: HW2_COLOR.muted }}>
                  {source.name} · {schemaName}
                </div>
                <h2 style={{ font: "600 26px 'DM Sans'", letterSpacing: "-0.02em", color: HW2_COLOR.ink, marginTop: 4 }}>
                  {tableName}
                </h2>
                <div style={{ display: "flex", gap: 8, marginTop: 8 }}>
                  <HW2Chip mono>{table.rows.toLocaleString()} rows</HW2Chip>
                  <HW2Chip mono>{table.cols} columns</HW2Chip>
                  {table.pk && <HW2Chip mono tone="blue">pk · {table.pk}</HW2Chip>}
                  {table.fk && <HW2Chip mono tone="muted">fk · {table.fk}</HW2Chip>}
                </div>
              </div>
              <div style={{ display: "flex", gap: 8 }}>
                <HW2Btn size="sm" onClick={() => onOpenQuery(`SELECT * FROM ${schemaName}.${tableName} LIMIT 100;`)}>
                  Query this →
                </HW2Btn>
                <HW2Btn size="sm">Regenerate metadata</HW2Btn>
              </div>
            </div>

            {table.description && (
              <p style={{ font: "400 13px 'DM Sans'", color: HW2_COLOR.muted, marginBottom: 24, maxWidth: 680 }}>
                {table.description}
              </p>
            )}

            {/* Columns table */}
            <HW2Card padded={false}>
              <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", padding: "12px 18px", borderBottom: `1px solid ${HW2_COLOR.rule}` }}>
                <span style={{ font: "600 12px 'DM Sans'", color: HW2_COLOR.ink }}>Columns</span>
                <span style={{ font: "400 11px 'DM Sans'", color: HW2_COLOR.muted }}>
                  Edit descriptions or types. <span style={{ color: HW2_COLOR.good, font: "600 11px 'DM Sans'" }}>Locked</span> edits persist across projects.
                </span>
              </div>
              <table style={{ width: "100%", borderCollapse: "collapse" }}>
                <thead>
                  <tr>
                    {["Column", "Type", "Semantic", "Description", "Nulls", "Lock"].map(h => (
                      <th key={h} style={{
                        textAlign: "left", padding: "10px 14px",
                        font: "600 10px 'DM Sans'", color: HW2_COLOR.muted,
                        textTransform: "uppercase", letterSpacing: "0.06em",
                        borderBottom: `1px solid ${HW2_COLOR.rule}`,
                      }}>{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {cols.length === 0 ? (
                    <tr><td colSpan={6} style={{ padding: "20px", color: HW2_COLOR.faint, font: "400 13px 'DM Sans'", textAlign: "center" }}>
                      Column metadata not loaded for this table in the demo.
                    </td></tr>
                  ) : cols.map((c, i) => <CatalogColumnRow key={c.name} col={c} />)}
                </tbody>
              </table>
            </HW2Card>

            {/* Sample rows */}
            {samples && (
              <div style={{ marginTop: 24 }}>
                <div style={{ display: "flex", alignItems: "baseline", justifyContent: "space-between", marginBottom: 8 }}>
                  <span style={{ font: "600 12px 'DM Sans'", color: HW2_COLOR.ink }}>Sample rows</span>
                  <span style={{ font: "400 11px 'DM Sans'", color: HW2_COLOR.faint }}>first {samples.length} of {table.rows.toLocaleString()}</span>
                </div>
                <HW2Card padded={false} style={{ overflow: "hidden" }}>
                  <div style={{ overflowX: "auto" }}>
                    <table style={{ width: "100%", borderCollapse: "collapse", font: "400 12px 'DM Mono'" }}>
                      <thead>
                        <tr>{Object.keys(samples[0]).map(k => (
                          <th key={k} style={{
                            textAlign: "left", padding: "8px 14px", whiteSpace: "nowrap",
                            font: "600 10px 'DM Sans'", color: HW2_COLOR.muted,
                            textTransform: "uppercase", letterSpacing: "0.06em",
                            borderBottom: `1px solid ${HW2_COLOR.rule}`,
                            background: HW2_COLOR.paper,
                          }}>{k}</th>
                        ))}</tr>
                      </thead>
                      <tbody>
                        {samples.map((r, i) => (
                          <tr key={i}>{Object.values(r).map((v, j) => (
                            <td key={j} style={{
                              padding: "7px 14px", whiteSpace: "nowrap",
                              color: HW2_COLOR.ink2, borderBottom: `1px solid ${HW2_COLOR.rule}`,
                            }}>{String(v)}</td>
                          ))}</tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </HW2Card>
              </div>
            )}
          </div>
        )}
      </section>
    </div>
  );
}

function CatalogColumnRow({ col }) {
  const [desc, setDesc]       = React.useState(col.desc);
  const [locked, setLocked]   = React.useState(col.locked);
  const [semantic, setSem]    = React.useState(col.semantic);

  return (
    <tr>
      <td style={{ padding: "10px 14px", borderBottom: `1px solid ${HW2_COLOR.rule}`, font: "500 13px 'DM Mono'", color: HW2_COLOR.ink, whiteSpace: "nowrap" }}>
        {col.pk && <span title="Primary key" style={{ color: HW2_COLOR.blue, marginRight: 5 }}>•</span>}
        {col.name}
      </td>
      <td style={{ padding: "10px 14px", borderBottom: `1px solid ${HW2_COLOR.rule}`, font: "400 12px 'DM Mono'", color: HW2_COLOR.muted, whiteSpace: "nowrap" }}>
        {col.type}
      </td>
      <td style={{ padding: "10px 14px", borderBottom: `1px solid ${HW2_COLOR.rule}` }}>
        <select value={semantic} onChange={(e) => setSem(e.target.value)} style={{
          appearance: "none", background: "#fff",
          border: `1px solid ${HW2_COLOR.rule2}`, borderRadius: 6,
          padding: "4px 22px 4px 8px", font: "500 12px 'DM Sans'", color: HW2_COLOR.ink2,
          fontFamily: "'DM Sans', sans-serif",
        }}>
          {["Identifier", "Timestamp", "Categorical", "Duration", "Quantity", "Flag", "Label", "Free text"].map(o => <option key={o}>{o}</option>)}
        </select>
      </td>
      <td style={{ padding: "10px 14px", borderBottom: `1px solid ${HW2_COLOR.rule}` }}>
        <input value={desc} onChange={(e) => setDesc(e.target.value)} style={{
          width: "100%", appearance: "none",
          background: "transparent", border: "none",
          padding: "2px 0", font: "400 13px 'DM Sans'", color: HW2_COLOR.ink2,
        }} />
      </td>
      <td style={{ padding: "10px 14px", borderBottom: `1px solid ${HW2_COLOR.rule}`, font: "500 11px 'DM Mono'" }}>
        {col.nulls === 0
          ? <span style={{ color: HW2_COLOR.good }}>0%</span>
          : <span style={{ color: HW2_COLOR.warn }}>{((col.nulls / 3193) * 100).toFixed(0)}%</span>}
      </td>
      <td style={{ padding: "10px 14px", borderBottom: `1px solid ${HW2_COLOR.rule}` }}>
        <button onClick={() => setLocked(v => !v)} title={locked ? "Locked — edits persist across projects" : "Unlocked — edits are project-scoped"} style={{
          appearance: "none", cursor: "pointer", background: "transparent", border: "none",
          padding: 0, color: locked ? HW2_COLOR.good : HW2_COLOR.faint,
        }}>
          <LockIcon locked={locked} />
        </button>
      </td>
    </tr>
  );
}

function LockIcon({ locked }) {
  return (
    <svg width="14" height="14" viewBox="0 0 14 14" fill="none">
      <rect x="3" y="6.5" width="8" height="6" rx="1" stroke="currentColor" strokeWidth="1.3" fill={locked ? "currentColor" : "none"} fillOpacity={locked ? 0.12 : 0} />
      <path d={locked ? "M5 6.5V5a2 2 0 0 1 4 0v1.5" : "M5 6.5V5a2 2 0 0 1 4 0"} stroke="currentColor" strokeWidth="1.3" fill="none" strokeLinecap="round" />
    </svg>
  );
}

Object.assign(window, { HW2Catalog });
