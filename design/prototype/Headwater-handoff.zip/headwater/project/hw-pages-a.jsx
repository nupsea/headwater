// hw-pages-a.jsx — Dashboard + Discover & Assess + VariantA shell

const { useState } = React;
const D = window.HW;

// ─── Shared primitives ────────────────────────────────────────────────────────

function TypeBadge({ type }) {
  const cfg = { integer:{bg:"#eff6ff",fg:"#2563eb"}, float:{bg:"#f5f3ff",fg:"#7c3aed"}, varchar:{bg:"#f8fafc",fg:"#64748b"}, timestamp:{bg:"#f0fdfa",fg:"#0d9488"}, boolean:{bg:"#fff7ed",fg:"#ea580c"} };
  const c = cfg[type] || cfg.varchar;
  return <span style={{ fontSize:10, fontWeight:600, padding:"2px 6px", borderRadius:4, background:c.bg, color:c.fg, fontFamily:"'DM Mono',monospace" }}>{type}</span>;
}

function NullBar({ pct }) {
  const color = pct===0?"#16a34a":pct<5?"#d97706":pct<20?"#ea580c":"#dc2626";
  const bg    = pct===0?"#dcfce7":pct<5?"#fef9c3":pct<20?"#ffedd5":"#fee2e2";
  return (
    <div style={{ display:"flex", alignItems:"center", gap:6 }}>
      <div style={{ width:36, height:4, background:"#e2e8f0", borderRadius:2, overflow:"hidden" }}>
        <div style={{ height:"100%", width:`${Math.min(pct*4,100)}%`, background:color, borderRadius:2 }} />
      </div>
      <span style={{ fontSize:10, color, fontFamily:"'DM Mono',monospace", background:bg, padding:"1px 5px", borderRadius:3 }}>{pct}%</span>
    </div>
  );
}

function SectionLabel({ children, style={} }) {
  return <div style={{ fontSize:10, fontWeight:700, color:"#94a3b8", textTransform:"uppercase", letterSpacing:"0.08em", marginBottom:10, ...style }}>{children}</div>;
}

function PanelCard({ children, style={} }) {
  return <div style={{ background:"#fff", border:"1px solid #e2e8f0", borderRadius:12, ...style }}>{children}</div>;
}

function Btn({ onClick, children, variant="primary", style={} }) {
  const s = variant==="primary" ? { background:"#4f46e5", color:"#fff", border:"none" }
          : variant==="danger"  ? { background:"#fff", color:"#dc2626", border:"1px solid #fecaca" }
          : { background:"#fff", color:"#64748b", border:"1px solid #e2e8f0" };
  return <button onClick={onClick} style={{ padding:"6px 16px", borderRadius:7, fontSize:12, fontWeight:500, cursor:"pointer", fontFamily:"'DM Sans',sans-serif", ...s, ...style }}>{children}</button>;
}

// ─── Re-run banner ────────────────────────────────────────────────────────────

function RerunBanner({ onRerun, onDismiss }) {
  const [running, setRunning] = useState(false);
  const [done, setDone] = useState(false);

  const handleRerun = () => {
    setRunning(true);
    setTimeout(() => { setRunning(false); setDone(true); setTimeout(onDismiss, 1800); }, 2200);
  };

  return (
    <div style={{ margin:"0 0 20px", padding:"12px 18px", background: done?"#f0fdf4":"#fffbeb", border:`1px solid ${done?"#bbf7d0":"#fde68a"}`, borderRadius:10, display:"flex", alignItems:"center", justifyContent:"space-between", gap:12 }}>
      <div style={{ display:"flex", alignItems:"center", gap:10 }}>
        {running && <div style={{ width:14, height:14, border:"2px solid #d97706", borderTopColor:"transparent", borderRadius:"50%", animation:"spin 0.7s linear infinite" }} />}
        {done && <span style={{ color:"#16a34a" }}>✓</span>}
        {!running && !done && <span style={{ color:"#d97706", fontSize:14 }}>↻</span>}
        <div>
          <div style={{ fontSize:13, fontWeight:600, color: done?"#16a34a":"#92400e" }}>
            {done ? "Pipeline complete — analysis updated" : running ? "Running pipeline…" : "Metadata changes detected"}
          </div>
          {!done && <div style={{ fontSize:11, color:"#a16207", marginTop:2 }}>Re-run Headwater to apply your edits and refine analysis across all pages.</div>}
        </div>
      </div>
      {!done && (
        <div style={{ display:"flex", gap:8, flexShrink:0 }}>
          <Btn onClick={handleRerun} variant="primary" style={{ background:"#d97706", fontSize:11 }}>{running?"Running…":"Re-run pipeline"}</Btn>
          <Btn onClick={onDismiss} variant="ghost" style={{ fontSize:11 }}>Dismiss</Btn>
        </div>
      )}
    </div>
  );
}

// ─── Page: Dashboard ─────────────────────────────────────────────────────────

function ADashboard({ setPage, appState }) {
  const confirmedCount  = appState.confirmedDescs.length;
  const approvedCount   = appState.approvedModels.length;
  const catalogConf     = Math.min(99, 72 + confirmedCount * 4);
  const pipelineDone    = approvedCount >= 3;
  const pendingModels   = Math.max(0, 3 - approvedCount);
  const pendingDescs    = Math.max(0, 2 - confirmedCount);

  const pipelinePhases = D.pipeline.map(ph => {
    if (ph.key === "models")     return { ...ph, status: pipelineDone ? "complete" : "active", detail: pipelineDone ? "3/3 approved" : `${pendingModels} pending` };
    if (ph.key === "dictionary") return { ...ph, status: pendingDescs===0 ? "complete" : "active", detail: pendingDescs===0 ? "all confirmed" : `${pendingDescs} pending` };
    return ph;
  });

  return (
    <div style={{ maxWidth:860 }}>
      <div style={{ marginBottom:24 }}>
        <SectionLabel>Overview</SectionLabel>
        <h1 style={{ fontSize:24, fontWeight:700, letterSpacing:"-0.03em", color:"#0f172a" }}>Project status</h1>
        <p style={{ fontSize:14, color:"#64748b", marginTop:6, lineHeight:1.6 }}>
          {pipelineDone && pendingDescs===0
            ? "All reviews complete. Your data warehouse is ready for production."
            : `${pendingModels + pendingDescs} item${pendingModels+pendingDescs!==1?"s":""} remaining before models can be materialized.`}
        </p>
      </div>

      {/* State-reactive health */}
      <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr 1fr", gap:12, marginBottom:24 }}>
        {[
          { label:"Completeness",         value:"87.3%", sub:"90 columns profiled", ok:true },
          { label:"Data Quality",         value:"94.1%", sub:"193/193 passing",     ok:true },
          { label:"Catalog Confidence",   value:`${catalogConf}%`, sub: confirmedCount>0 ? `+${confirmedCount*4}% from your edits` : "8 tables documented", ok:catalogConf>=80 },
        ].map(c => (
          <PanelCard key={c.label} style={{ padding:"16px 18px" }}>
            <SectionLabel>{c.label}</SectionLabel>
            <div style={{ fontSize:26, fontWeight:700, color:"#0f172a", letterSpacing:"-0.03em" }}>{c.value}</div>
            <div style={{ fontSize:11, color: c.ok ? "#16a34a" : "#d97706", marginTop:4 }}>{c.sub}</div>
          </PanelCard>
        ))}
      </div>

      {/* Review queue */}
      {(pendingModels > 0 || pendingDescs > 0) && (
        <PanelCard style={{ padding:"16px 20px", marginBottom:20 }}>
          <SectionLabel>Needs your review</SectionLabel>
          {pendingModels > 0 && (
            <button onClick={() => setPage("model-data")} style={{ display:"flex", alignItems:"center", justifyContent:"space-between", width:"100%", padding:"10px 14px", background:"#fef2f2", border:"1px solid #fecaca", borderRadius:8, cursor:"pointer", fontFamily:"inherit", marginBottom:8 }}>
              <div style={{ display:"flex", alignItems:"center", gap:10 }}>
                <div style={{ width:6, height:6, borderRadius:"50%", background:"#dc2626" }} />
                <span style={{ fontSize:13, fontWeight:500, color:"#0f172a" }}>{pendingModels} mart model{pendingModels!==1?"s":""} awaiting approval</span>
              </div>
              <span style={{ fontSize:12, color:"#94a3b8" }}>Review →</span>
            </button>
          )}
          <button onClick={() => setPage("review")} style={{display:"none"}} />
          <button onClick={() => setPage("model")} style={{display:"none"}} />
          <button onClick={() => setPage("data")} style={{display:"none"}} />
          {pendingDescs > 0 && (
            <button onClick={() => setPage("discover")} style={{ display:"flex", alignItems:"center", justifyContent:"space-between", width:"100%", padding:"10px 14px", background:"#fffbeb", border:"1px solid #fde68a", borderRadius:8, cursor:"pointer", fontFamily:"inherit" }}>
              <div style={{ display:"flex", alignItems:"center", gap:10 }}>
                <div style={{ width:6, height:6, borderRadius:"50%", background:"#d97706" }} />
                <span style={{ fontSize:13, fontWeight:500, color:"#0f172a" }}>{pendingDescs} column description{pendingDescs!==1?"s":""} need confirmation</span>
              </div>
              <span style={{ fontSize:12, color:"#94a3b8" }}>Review →</span>
            </button>
          )}
        </PanelCard>
      )}

      {/* Domain map */}
      <PanelCard style={{ padding:"18px 20px", marginBottom:20 }}>
        <SectionLabel>Domain map</SectionLabel>
        <div style={{ display:"grid", gridTemplateColumns:"repeat(4,1fr)", gap:10 }}>
          {[
            { domain:"Environmental", tables:["readings","programs"] },
            { domain:"Operational",   tables:["sites","sensors"] },
            { domain:"Compliance",    tables:["inspections","incidents","complaints"] },
            { domain:"Geographic",    tables:["zones"] },
          ].map(d => {
            const col = D.domainColors[d.domain] || "#64748b";
            return (
              <div key={d.domain} style={{ padding:"12px 14px", background:"#f8fafc", borderRadius:10, border:"1px solid #e2e8f0" }}>
                <div style={{ display:"flex", alignItems:"center", gap:6, marginBottom:8 }}>
                  <div style={{ width:8, height:8, borderRadius:"50%", background:col }} />
                  <span style={{ fontSize:11, fontWeight:600, color:"#0f172a" }}>{d.domain}</span>
                </div>
                {d.tables.map(t => (
                  <button key={t} onClick={() => setPage("discover")} style={{ display:"block", fontFamily:"'DM Mono',monospace", fontSize:11, color:"#475569", background:"none", border:"none", cursor:"pointer", padding:"2px 0", textAlign:"left" }}>{t}</button>
                ))}
              </div>
            );
          })}
        </div>
      </PanelCard>

      {/* Pipeline */}
      <PanelCard style={{ padding:"16px 20px", marginBottom:20 }}>
        <SectionLabel>Automated pipeline</SectionLabel>
        <div style={{ display:"flex", alignItems:"center" }}>
          {pipelinePhases.map((ph, i) => (
            <React.Fragment key={ph.key}>
              <div style={{ flex:1, textAlign:"center" }}>
                <div style={{ display:"inline-flex", alignItems:"center", gap:5, padding:"5px 12px", borderRadius:20,
                  background: ph.status==="complete" ? "#f0fdf4" : ph.status==="active" ? "#eef2ff" : "#f8fafc",
                  border:`1px solid ${ph.status==="complete" ? "#bbf7d0" : ph.status==="active" ? "#c7d2fe" : "#e2e8f0"}`
                }}>
                  <div style={{ width:6, height:6, borderRadius:"50%", background: ph.status==="complete" ? "#16a34a" : ph.status==="active" ? "#4f46e5" : "#cbd5e1" }} />
                  <span style={{ fontSize:11, fontWeight:600, color: ph.status==="complete" ? "#16a34a" : ph.status==="active" ? "#4f46e5" : "#94a3b8" }}>{ph.label}</span>
                </div>
                {ph.detail && <div style={{ fontSize:10, color:"#94a3b8", marginTop:3 }}>{ph.detail}</div>}
              </div>
              {i < pipelinePhases.length-1 && <div style={{ width:14, height:1, background:"#e2e8f0", flexShrink:0 }} />}
            </React.Fragment>
          ))}
        </div>
      </PanelCard>

      {/* Activity */}
      <PanelCard style={{ padding:"16px 20px" }}>
        <SectionLabel>Recent activity</SectionLabel>
        {D.activity.map((a, i) => (
          <div key={i} style={{ display:"flex", gap:12, alignItems:"flex-start", paddingBottom: i<D.activity.length-1?10:0, marginBottom: i<D.activity.length-1?10:0, borderBottom: i<D.activity.length-1?"1px solid #f1f5f9":"none" }}>
            <div style={{ width:7, height:7, borderRadius:"50%", flexShrink:0, marginTop:4, background: a.type==="success"?"#16a34a":a.type==="warning"?"#d97706":"#4f46e5" }} />
            <div style={{ flex:1, fontSize:12, color:"#475569", lineHeight:1.5 }}>{a.msg}</div>
            <div style={{ fontSize:11, color:"#94a3b8", flexShrink:0 }}>{a.time}</div>
          </div>
        ))}
      </PanelCard>
    </div>
  );
}

// ─── Page: Discover & Assess ──────────────────────────────────────────────────

function ADiscover({ appState, onConfirmDesc }) {
  const [selectedTable, setSelectedTable] = useState("readings");
  const [search, setSearch] = useState("");
  const [editingDesc, setEditingDesc] = useState({}); // colName → draft text
  const [editingTableDesc, setEditingTableDesc] = useState(false);
  const [tableDraft, setTableDraft] = useState("");
  const [editKeys, setEditKeys] = useState({}); // colName → {pk, fk}

  const profile = D.profiles[selectedTable];
  const filtered = D.tables.filter(t => t.name.includes(search.toLowerCase()));

  const handleConfirm = (colName) => {
    const key = `${selectedTable}.${colName}`;
    onConfirmDesc(key);
    setEditingDesc(p => { const n={...p}; delete n[colName]; return n; });
  };

  const isConfirmed = (colName) => appState.confirmedDescs.includes(`${selectedTable}.${colName}`);

  return (
    <div style={{ display:"flex", gap:0, height:"100%", minHeight:500 }}>
      {/* Left: table list */}
      <div style={{ width:196, flexShrink:0, borderRight:"1px solid #e2e8f0" }}>
        <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Filter tables…" style={{ width:"100%", padding:"7px 10px", border:"1px solid #e2e8f0", borderRadius:8, fontSize:12, fontFamily:"'DM Sans',sans-serif", color:"#0f172a", background:"#f8fafc", outline:"none", marginBottom:8 }} />
        {filtered.map(t => (
          <button key={t.name} onClick={() => setSelectedTable(t.name)} style={{ display:"flex", alignItems:"center", justifyContent:"space-between", width:"100%", padding:"9px 10px", borderRadius:8, border:"none", cursor:"pointer", textAlign:"left", background: selectedTable===t.name ? "#eef2ff" : "transparent", fontFamily:"inherit", marginBottom:2 }}>
            <div>
              <div style={{ fontSize:13, fontWeight:500, color: selectedTable===t.name ? "#4f46e5" : "#0f172a", fontFamily:"'DM Mono',monospace" }}>{t.name}</div>
              <div style={{ fontSize:10, color:"#94a3b8", marginTop:1 }}>{t.rows.toLocaleString()} rows</div>
            </div>
            <span style={{ fontSize:9, fontWeight:700, padding:"2px 5px", borderRadius:3, background: t.status==="documented"?"#f0fdf4":"#fff7ed", color: t.status==="documented"?"#16a34a":"#d97706" }}>{t.status==="documented"?"✓":"…"}</span>
          </button>
        ))}
      </div>

      {/* Right: detail */}
      {profile && (
        <div style={{ flex:1, paddingLeft:24, overflowY:"auto" }}>
          {/* Table header */}
          <div style={{ marginBottom:20 }}>
            <div style={{ display:"flex", alignItems:"baseline", gap:10, marginBottom:8 }}>
              <h2 style={{ fontSize:20, fontWeight:700, letterSpacing:"-0.02em", fontFamily:"'DM Mono',monospace", color:"#0f172a" }}>{selectedTable}</h2>
              <span style={{ fontSize:12, color:"#94a3b8" }}>{profile.rows.toLocaleString()} rows · {profile.columns.length} cols · {profile.domain}</span>
            </div>
            {/* Table description */}
            {editingTableDesc ? (
              <div>
                <textarea value={tableDraft} onChange={e => setTableDraft(e.target.value)} rows={3}
                  style={{ width:"100%", padding:"9px 12px", border:"1px solid #c7d2fe", borderRadius:8, fontSize:13, fontFamily:"'DM Sans',sans-serif", color:"#0f172a", background:"#f8fafc", outline:"none", resize:"vertical" }} />
                <div style={{ display:"flex", gap:8, marginTop:6 }}>
                  <Btn onClick={() => setEditingTableDesc(false)}>Save</Btn>
                  <Btn variant="ghost" onClick={() => setEditingTableDesc(false)}>Cancel</Btn>
                </div>
              </div>
            ) : (
              <div style={{ display:"flex", alignItems:"flex-start", gap:10 }}>
                <p style={{ fontSize:13, color:"#475569", lineHeight:1.65, flex:1 }}>{tableDraft || profile.tableDesc}</p>
                <button onClick={() => { setTableDraft(tableDraft||profile.tableDesc); setEditingTableDesc(true); }} style={{ fontSize:11, color:"#94a3b8", background:"none", border:"1px solid #e2e8f0", borderRadius:5, padding:"3px 8px", cursor:"pointer", flexShrink:0, fontFamily:"inherit" }}>Edit</button>
              </div>
            )}

            {/* Relationships */}
            {(() => {
              const rels = D.relationships.filter(r => r.from===selectedTable || r.to===selectedTable);
              if (!rels.length) return null;
              return (
                <div style={{ display:"flex", gap:6, flexWrap:"wrap", marginTop:10 }}>
                  {rels.map((r,i) => (
                    <span key={i} style={{ fontSize:10, padding:"2px 8px", background:"#f1f5f9", color:"#64748b", borderRadius:4, fontFamily:"'DM Mono',monospace" }}>
                      {r.from===selectedTable ? `→ ${r.to}.${r.toCol}` : `← ${r.from}.${r.fromCol}`}
                      {" "}<span style={{ color: r.integrity===1 ? "#16a34a" : "#d97706" }}>({Math.round(r.integrity*100)}%)</span>
                    </span>
                  ))}
                </div>
              );
            })()}
          </div>

          {/* Columns */}
          <div>
            <SectionLabel>Columns <span style={{ fontWeight:400, textTransform:"none", letterSpacing:"normal", fontSize:11, color:"#94a3b8" }}>— click any description to edit</span></SectionLabel>
            {profile.columns.map((col, i) => {
              const confirmed = isConfirmed(col.name);
              const isEditing = col.name in editingDesc;
              const curKey = editKeys[col.name] || { pk: !!col.pk, fk: col.fk || null };

              return (
                <PanelCard key={col.name} style={{ marginBottom:8, border: confirmed ? "1px solid #bbf7d0" : "1px solid #e2e8f0" }}>
                  <div style={{ padding:"14px 16px" }}>
                    {/* Row 1: name + badges + null rate */}
                    <div style={{ display:"flex", alignItems:"center", gap:8, marginBottom:8, flexWrap:"wrap" }}>
                      <span style={{ fontFamily:"'DM Mono',monospace", fontSize:13, fontWeight:600, color:"#0f172a" }}>{col.name}</span>
                      <TypeBadge type={col.type} />
                      {/* PK toggle */}
                      <button onClick={() => setEditKeys(p => ({...p, [col.name]:{...curKey, pk:!curKey.pk}}))}
                        style={{ fontSize:9, fontWeight:700, padding:"2px 6px", borderRadius:3, cursor:"pointer", fontFamily:"inherit", background: curKey.pk?"#fef9c3":"#f8fafc", color: curKey.pk?"#a16207":"#94a3b8", border: curKey.pk?"1px solid #fde68a":"1px solid #e2e8f0" }}>
                        PK
                      </button>
                      {/* FK display/edit */}
                      {curKey.fk && (
                        <span style={{ fontSize:9, fontWeight:700, padding:"2px 6px", borderRadius:3, background:"#dbeafe", color:"#1d4ed8", border:"1px solid #bfdbfe", fontFamily:"'DM Mono',monospace" }}>FK→{curKey.fk}</span>
                      )}
                      <div style={{ marginLeft:"auto", display:"flex", alignItems:"center", gap:10 }}>
                        <NullBar pct={col.null_pct} />
                        {col.min !== undefined && <span style={{ fontSize:10, color:"#94a3b8", fontFamily:"'DM Mono',monospace" }}>p50:{col.p50}</span>}
                        {confirmed && <span style={{ fontSize:10, color:"#16a34a", fontWeight:600 }}>🔒 Locked</span>}
                      </div>
                    </div>

                    {/* Row 2: LLM description */}
                    {isEditing ? (
                      <div>
                        <textarea value={editingDesc[col.name]} onChange={e => setEditingDesc(p => ({...p, [col.name]:e.target.value}))} rows={3}
                          style={{ width:"100%", padding:"8px 12px", border:"1px solid #c7d2fe", borderRadius:7, fontSize:12, fontFamily:"'DM Sans',sans-serif", color:"#0f172a", background:"#fafbff", outline:"none", resize:"vertical", lineHeight:1.55 }} />
                        <div style={{ display:"flex", gap:8, marginTop:8 }}>
                          <Btn onClick={() => handleConfirm(col.name)} style={{ fontSize:11 }}>Confirm &amp; lock</Btn>
                          <Btn variant="ghost" onClick={() => setEditingDesc(p => { const n={...p}; delete n[col.name]; return n; })} style={{ fontSize:11 }}>Cancel</Btn>
                        </div>
                      </div>
                    ) : (
                      <div style={{ display:"flex", alignItems:"flex-start", gap:8 }}>
                        <p onClick={() => !confirmed && setEditingDesc(p => ({...p, [col.name]:col.llmDesc||""}))}
                          style={{ fontSize:12, color: confirmed ? "#64748b" : "#475569", lineHeight:1.6, flex:1, cursor: confirmed ? "default" : "text", margin:0 }}>
                          {col.llmDesc || "No description yet."}
                        </p>
                        {!confirmed && (
                          <button onClick={() => setEditingDesc(p => ({...p, [col.name]:col.llmDesc||""}))}
                            style={{ fontSize:10, color:"#94a3b8", background:"none", border:"1px solid #e2e8f0", borderRadius:5, padding:"2px 8px", cursor:"pointer", flexShrink:0, fontFamily:"inherit" }}>Edit</button>
                        )}
                      </div>
                    )}
                  </div>
                </PanelCard>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
}

// ─── Page: Settings ───────────────────────────────────────────────────────────

function ASettings() {
  const [llm, setLlm] = useState("anthropic");
  const [saved, setSaved] = useState(null);
  const save = (s) => { setSaved(s); setTimeout(() => setSaved(null), 1800); };
  const F = { width:"100%", padding:"8px 12px", border:"1px solid #e2e8f0", borderRadius:7, fontSize:13, fontFamily:"'DM Sans',sans-serif", color:"#0f172a", background:"#f8fafc", outline:"none" };

  return (
    <div style={{ maxWidth:620 }}>
      <SectionLabel style={{ marginBottom:6 }}>Settings</SectionLabel>
      <h1 style={{ fontSize:22, fontWeight:700, letterSpacing:"-0.03em", marginBottom:28 }}>Configuration</h1>

      {[
        { id:"source", title:"Data Source", fields: (
          <>
            <SettField label="Connection DSN" hint="PostgreSQL DSN or path to JSON/CSV directory"><input defaultValue="postgresql://headwater:headwater@localhost:5434/headwater_dev" style={F} /></SettField>
            <SettField label="Connector type"><select defaultValue="postgres" style={F}><option value="postgres">PostgreSQL (generate mode)</option><option value="json">JSON / NDJSON</option><option value="csv">CSV</option></select></SettField>
            <SettField label="Sample size" hint="Rows fetched for SQL validation"><input defaultValue="10000" type="number" style={{...F, width:120}} /></SettField>
          </>
        )},
        { id:"llm", title:"LLM Enrichment", fields: (
          <>
            <SettField label="Provider">
              <div style={{ display:"flex", gap:8 }}>
                {["none","anthropic"].map(v => (
                  <button key={v} onClick={() => setLlm(v)} style={{ padding:"6px 16px", borderRadius:7, border:"1px solid", borderColor: llm===v?"#4f46e5":"#e2e8f0", background: llm===v?"#eef2ff":"#fff", color: llm===v?"#4f46e5":"#64748b", fontSize:13, fontWeight: llm===v?600:400, cursor:"pointer", fontFamily:"inherit", textTransform:"capitalize" }}>{v}</button>
                ))}
              </div>
            </SettField>
            {llm==="anthropic" && <>
              <SettField label="Model"><select defaultValue="claude-sonnet-4-6" style={F}><option value="claude-sonnet-4-6">claude-sonnet-4-6</option><option value="claude-haiku-4-5">claude-haiku-4-5 (faster)</option></select></SettField>
              <SettField label="API key"><input type="password" defaultValue="sk-ant-api03-••••••••" style={F} /></SettField>
            </>}
          </>
        )},
        { id:"project", title:"Project", fields: (
          <>
            <SettField label="Project name"><input defaultValue="Environmental Health DB" style={F} /></SettField>
            <SettField label="Description"><textarea defaultValue="EPA and NYC environmental health datasets for compliance and air quality analysis." rows={2} style={{...F, resize:"vertical", height:64}} /></SettField>
          </>
        )},
      ].map(section => (
        <div key={section.id} style={{ marginBottom:28, paddingBottom:28, borderBottom:"1px solid #f1f5f9" }}>
          <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:16 }}>
            <div style={{ fontSize:14, fontWeight:600, color:"#0f172a" }}>{section.title}</div>
            <button onClick={() => save(section.id)} style={{ padding:"5px 14px", background: saved===section.id?"#f0fdf4":"#fff", color: saved===section.id?"#16a34a":"#64748b", border:`1px solid ${saved===section.id?"#bbf7d0":"#e2e8f0"}`, borderRadius:6, fontSize:12, cursor:"pointer", fontFamily:"inherit" }}>
              {saved===section.id?"✓ Saved":"Save"}
            </button>
          </div>
          <div style={{ display:"flex", flexDirection:"column", gap:14 }}>{section.fields}</div>
        </div>
      ))}

      <div style={{ borderTop:"1px solid #fecaca", paddingTop:20 }}>
        <div style={{ fontSize:11, fontWeight:700, color:"#dc2626", textTransform:"uppercase", letterSpacing:"0.07em", marginBottom:10 }}>Danger zone</div>
        <div style={{ display:"flex", gap:10 }}>
          <Btn variant="danger">Reset project data</Btn>
          <Btn variant="danger">Delete project</Btn>
        </div>
        <div style={{ fontSize:11, color:"#94a3b8", marginTop:8 }}>The source database is never modified by Headwater.</div>
      </div>
    </div>
  );
}

function SettField({ label, hint, children }) {
  return (
    <div>
      <div style={{ display:"flex", alignItems:"baseline", gap:8, marginBottom:5 }}>
        <label style={{ fontSize:13, fontWeight:500, color:"#0f172a" }}>{label}</label>
        {hint && <span style={{ fontSize:11, color:"#94a3b8" }}>{hint}</span>}
      </div>
      {children}
    </div>
  );
}

// ─── Variant A shell ──────────────────────────────────────────────────────────

function VariantA({ page, setPage }) {
  const [appState, setAppState] = useState({ confirmedDescs:[], approvedModels:[], needsRerun:false });

  const onConfirmDesc   = (id) => setAppState(s => ({ ...s, confirmedDescs: s.confirmedDescs.includes(id) ? s.confirmedDescs : [...s.confirmedDescs, id], needsRerun:true }));
  const onApproveModel  = (id) => setAppState(s => ({ ...s, approvedModels: s.approvedModels.includes(id) ? s.approvedModels : [...s.approvedModels, id], needsRerun:true }));
  const dismissRerun    = ()   => setAppState(s => ({ ...s, needsRerun:false }));

  const pendingModels = Math.max(0, 3 - appState.approvedModels.length);
  const pendingDescs  = Math.max(0, 2 - appState.confirmedDescs.length);

  const navGroups = [
    { label:"Today", items:[
      { key:"briefing",  label:"Briefing" },
      { key:"dashboard", label:"Project Health" },
    ]},
    { label:"Catalog", items:[
      { key:"sources",   label:"Sources" },
      { key:"discover",  label:"Discover & Assess" },
    ]},
    { label:"Build", items:[
      { key:"model",     label:"Model" },
      { key:"data",      label:"Data & Query" },
      { key:"review",    label:"Review Queue" },
    ]},
    { label:"Analyze", items:[
      { key:"insights",  label:"Insights" },
    ]},
    { label:"Configure", items:[
      { key:"settings",  label:"Settings" },
    ]},
  ];

  return (
    <div style={{ display:"flex", flexDirection:"column", height:"100%", background:"#f8fafc", fontFamily:"'DM Sans',sans-serif", color:"#0f172a" }}>
      {/* Topbar */}
      <header style={{ display:"flex", alignItems:"center", justifyContent:"space-between", padding:"0 24px", height:48, background:"#fff", borderBottom:"1px solid #e2e8f0", flexShrink:0 }}>
        <div style={{ display:"flex", alignItems:"center", gap:10 }}>
          <svg width="20" height="20" viewBox="0 0 20 20" fill="none"><circle cx="10" cy="10" r="9" fill="#4f46e5" opacity="0.12"/><circle cx="10" cy="10" r="4" fill="#4f46e5"/></svg>
          <span style={{ fontWeight:700, fontSize:15, letterSpacing:"-0.02em" }}>Headwater</span>
          <span style={{ color:"#cbd5e1", fontSize:13 }}>·</span>
          <span style={{ fontSize:13, color:"#64748b" }}>{D.project.name}</span>
        </div>
        <div style={{ display:"flex", alignItems:"center", gap:10 }}>
          <span style={{ fontSize:12, color:"#94a3b8" }}>Last run 2h ago</span>
          <button style={{ padding:"5px 16px", background:"#4f46e5", color:"#fff", border:"none", borderRadius:6, fontSize:12, fontWeight:500, cursor:"pointer", fontFamily:"inherit" }}>Re-run pipeline</button>
        </div>
      </header>

      <div style={{ display:"flex", flex:1, overflow:"hidden" }}>
        {/* Sidebar */}
        <aside style={{ width:228, background:"#fff", borderRight:"1px solid #e2e8f0", display:"flex", flexDirection:"column", flexShrink:0, overflowY:"auto" }}>
          <div style={{ padding:"16px 14px 12px" }}>
            <SectionLabel>Review Queue</SectionLabel>
            <QueueItem label="Mart models" count={pendingModels} sub={pendingModels?"awaiting approval":"all approved"} active={page==="model-data"} countColor="#dc2626" countBg="#fef2f2" doneColor="#16a34a" onClick={() => setPage("model-data")} />
            <QueueItem label="Column descriptions" count={pendingDescs} sub={pendingDescs?"need confirmation":"all confirmed"} active={page==="discover"} countColor="#d97706" countBg="#fffbeb" doneColor="#16a34a" onClick={() => setPage("discover")} />
            <QueueItem label="Quality contracts" count={0} sub="193 passing · all clear" active={false} countColor="#16a34a" countBg="#f0fdf4" doneColor="#16a34a" onClick={() => setPage("insights")} />
          </div>

          <div style={{ height:1, background:"#f1f5f9", margin:"0 14px" }} />

          <nav style={{ padding:"14px 10px", flex:1 }}>
            {navGroups.map((g, gi) => (
              <div key={g.label} style={{ marginBottom: gi<navGroups.length-1 ? 12 : 0 }}>
                <SectionLabel style={{ padding:"0 6px", marginBottom:6 }}>{g.label}</SectionLabel>
                {g.items.map(n => (
                  <button key={n.key} onClick={() => setPage(n.key)} style={{ display:"block", width:"100%", textAlign:"left", padding:"7px 10px", borderRadius:7, fontSize:13, cursor:"pointer", border:"none", background: page===n.key?"#eef2ff":"transparent", color: page===n.key?"#4f46e5":"#64748b", fontWeight: page===n.key?500:400, fontFamily:"inherit", marginBottom:1 }}>
                    {n.label}
                  </button>
                ))}
              </div>
            ))}
          </nav>

          <div style={{ margin:"12px", padding:"12px 14px", background:"#f8fafc", border:"1px solid #e2e8f0", borderRadius:10 }}>
            <div style={{ display:"flex", justifyContent:"space-between", alignItems:"baseline", marginBottom:6 }}>
              <span style={{ fontSize:12, fontWeight:600, color:"#0f172a" }}>Env Health DB</span>
              <span style={{ fontSize:10, color:"#94a3b8", background:"#f1f5f9", padding:"2px 6px", borderRadius:4 }}>{D.project.maturity}</span>
            </div>
            <div style={{ height:4, background:"#e2e8f0", borderRadius:2, overflow:"hidden", marginBottom:5 }}>
              <div style={{ height:"100%", width:`${Math.min(80 + appState.approvedModels.length*6, 99)}%`, background:"#4f46e5", borderRadius:2, transition:"width 0.5s" }} />
            </div>
            <div style={{ fontSize:10, color:"#94a3b8" }}>{Math.min(80 + appState.approvedModels.length*6, 99)}% maturity</div>
          </div>
        </aside>

        {/* Main content */}
        <main style={{ flex:1, padding:"28px 32px", overflowY:"auto" }}>
          {appState.needsRerun && <RerunBanner onRerun={dismissRerun} onDismiss={dismissRerun} />}

          {page==="briefing"   && <window.ABriefing setPage={setPage} appState={appState} />}
          {page==="dashboard"  && <ADashboard setPage={setPage} appState={appState} />}
          {page==="sources"    && <window.ASources />}
          {page==="discover"   && <ADiscover appState={appState} onConfirmDesc={onConfirmDesc} />}
          {(page==="model"||page==="data"||page==="review"||page==="model-data") && <window.AModelDataQuery appState={appState} onApproveModel={onApproveModel} initialTab={page==="data"?"data-query":page==="review"?"review":"model"} />}
          {page==="insights"   && <window.AInsights appState={appState} />}
          {page==="settings"   && <ASettings />}
        </main>
      </div>
    </div>
  );
}

function QueueItem({ label, count, sub, active, countColor, countBg, doneColor, onClick }) {
  return (
    <button onClick={onClick} style={{ display:"flex", alignItems:"center", justifyContent:"space-between", width:"100%", padding:"9px 10px", borderRadius:8, cursor:"pointer", border:"none", textAlign:"left", background: active?"#eef2ff":"transparent", marginBottom:4, fontFamily:"inherit" }}>
      <div>
        <div style={{ fontSize:13, fontWeight:500, color: active?"#4f46e5":"#0f172a" }}>{label}</div>
        <div style={{ fontSize:11, color:"#94a3b8", marginTop:1 }}>{sub}</div>
      </div>
      {count > 0
        ? <span style={{ background:countBg, color:countColor, borderRadius:12, padding:"2px 8px", fontSize:11, fontWeight:700 }}>{count}</span>
        : <span style={{ fontSize:14, color:doneColor }}>✓</span>}
    </button>
  );
}

Object.assign(window, { VariantA, TypeBadge, NullBar, SectionLabel, PanelCard, Btn, QueueItem });
