// Headwater 2 — Query console (workspace-level power tool).
// SQL editor with schema sidebar (click columns to insert) and result panel.

function HW2Query({ source, sampleRows, initialSQL }) {
  const [sql, setSql]   = React.useState(initialSQL || defaultSQL());
  const [running, setRunning] = React.useState(false);
  const [result, setResult]   = React.useState(null);
  const [view, setView]       = React.useState("table");
  const taRef = React.useRef(null);

  // If parent changes initialSQL, refresh
  React.useEffect(() => { if (initialSQL) setSql(initialSQL); }, [initialSQL]);

  const insertAtCursor = (snippet) => {
    const ta = taRef.current;
    if (!ta) { setSql(s => s + snippet); return; }
    const start = ta.selectionStart, end = ta.selectionEnd;
    const next = sql.slice(0, start) + snippet + sql.slice(end);
    setSql(next);
    requestAnimationFrame(() => {
      ta.focus();
      ta.setSelectionRange(start + snippet.length, start + snippet.length);
    });
  };

  const runQuery = () => {
    setRunning(true);
    setResult(null);
    setTimeout(() => {
      setRunning(false);
      setResult(mockResultFor(sql, sampleRows));
    }, 700);
  };

  // Cmd/Ctrl + Enter to run
  React.useEffect(() => {
    const onKey = (e) => {
      if ((e.metaKey || e.ctrlKey) && e.key === "Enter") runQuery();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [sql]); // eslint-disable-line

  return (
    <div style={{ display: "grid", gridTemplateColumns: "240px 1fr", minHeight: "calc(100vh - 48px)" }}>
      {/* Schema browser */}
      <aside style={{
        background: "#fff", borderRight: `1px solid ${HW2_COLOR.rule}`,
        padding: "16px 12px", overflowY: "auto",
      }}>
        <div style={{ font: "600 10px 'DM Sans'", color: HW2_COLOR.muted, letterSpacing: "0.08em", textTransform: "uppercase", padding: "0 4px", marginBottom: 8 }}>
          Schema · click to insert
        </div>
        {source.schemas.map(s => (
          <div key={s.name} style={{ marginBottom: 8 }}>
            <button onClick={() => insertAtCursor(s.name)} style={{
              appearance: "none", cursor: "pointer", background: "transparent", border: "none",
              padding: "3px 6px", font: "600 12px 'DM Sans'", color: HW2_COLOR.ink,
              fontFamily: "'DM Sans', sans-serif",
            }}>{s.name}</button>
            <div style={{ paddingLeft: 8 }}>
              {s.tables.map(t => (
                <QueryTableNode key={t.name} schema={s.name} table={t} onInsert={insertAtCursor} />
              ))}
            </div>
          </div>
        ))}
      </aside>

      {/* Editor + result */}
      <section style={{ padding: "20px 28px 40px", display: "flex", flexDirection: "column", gap: 16 }}>
        <div>
          <h2 style={{ font: "600 20px 'DM Sans'", letterSpacing: "-0.02em", color: HW2_COLOR.ink, marginBottom: 2 }}>
            Query
          </h2>
          <p style={{ font: "400 12px 'DM Sans'", color: HW2_COLOR.muted }}>
            Multi-table SQL on {source.name}. <span style={{ font: "500 11px 'DM Mono'", color: HW2_COLOR.faint }}>{platformLabel(source.kind)}</span>
          </p>
        </div>

        {/* Editor */}
        <HW2Card padded={false}>
          <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", padding: "10px 14px", borderBottom: `1px solid ${HW2_COLOR.rule}` }}>
            <span style={{ font: "600 12px 'DM Sans'", color: HW2_COLOR.ink }}>SQL</span>
            <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
              <span style={{ font: "400 11px 'DM Sans'", color: HW2_COLOR.faint, display: "inline-flex", gap: 4, alignItems: "center" }}>
                <kbd style={kbdStyle}>⌘</kbd><kbd style={kbdStyle}>↵</kbd> run
              </span>
              <HW2Btn size="sm" onClick={() => setSql("")}>Clear</HW2Btn>
              <HW2Btn size="sm" kind="accent" onClick={runQuery}>
                {running ? "Running…" : "▶ Run"}
              </HW2Btn>
            </div>
          </div>
          <div style={{ display: "flex", background: HW2_COLOR.paper }}>
            <pre style={{
              padding: "12px 6px 12px 16px", margin: 0,
              font: "500 12px 'DM Mono'", color: HW2_COLOR.faint,
              lineHeight: 1.55, userSelect: "none",
            }}>
              {sql.split("\n").map((_, i) => String(i + 1).padStart(2, " ") + "\n").join("")}
            </pre>
            <textarea
              ref={taRef}
              value={sql}
              onChange={(e) => setSql(e.target.value)}
              spellCheck={false}
              style={{
                flex: 1, padding: "12px 16px 12px 6px",
                background: "transparent", border: "none", resize: "vertical",
                font: "500 13px 'DM Mono'", color: HW2_COLOR.ink, lineHeight: 1.55,
                minHeight: 200, outline: "none",
              }}
            />
          </div>
        </HW2Card>

        {/* Result */}
        {result && (
          <HW2Card padded={false}>
            <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", padding: "10px 14px", borderBottom: `1px solid ${HW2_COLOR.rule}` }}>
              <span style={{ font: "600 12px 'DM Sans'", color: HW2_COLOR.ink }}>
                {result.rows.length} rows
                <span style={{ font: "400 12px 'DM Mono'", color: HW2_COLOR.muted, marginLeft: 8 }}>
                  · {result.tookMs} ms
                </span>
              </span>
              <div style={{ display: "inline-flex", gap: 2, padding: 3, background: HW2_COLOR.chip, borderRadius: 7 }}>
                {["table", "chart"].map(v => (
                  <button key={v} onClick={() => setView(v)} style={{
                    appearance: "none", cursor: "pointer", border: "none",
                    padding: "4px 10px", borderRadius: 5,
                    background: view === v ? "#fff" : "transparent",
                    color: view === v ? HW2_COLOR.ink : HW2_COLOR.muted,
                    font: "500 11px 'DM Sans'", fontFamily: "'DM Sans', sans-serif",
                  }}>{v}</button>
                ))}
              </div>
            </div>
            {view === "table" ? (
              <div style={{ overflowX: "auto", maxHeight: 360 }}>
                <table style={{ width: "100%", borderCollapse: "collapse", font: "400 12px 'DM Mono'" }}>
                  <thead><tr>{result.cols.map(c => (
                    <th key={c} style={{
                      textAlign: "left", padding: "8px 14px", whiteSpace: "nowrap",
                      font: "600 10px 'DM Sans'", color: HW2_COLOR.muted,
                      textTransform: "uppercase", letterSpacing: "0.06em",
                      borderBottom: `1px solid ${HW2_COLOR.rule}`, position: "sticky", top: 0,
                      background: HW2_COLOR.paper,
                    }}>{c}</th>
                  ))}</tr></thead>
                  <tbody>
                    {result.rows.map((r, i) => (
                      <tr key={i}>{r.map((v, j) => (
                        <td key={j} style={{
                          padding: "7px 14px", whiteSpace: "nowrap",
                          color: HW2_COLOR.ink2, borderBottom: `1px solid ${HW2_COLOR.rule}`,
                        }}>{String(v)}</td>
                      ))}</tr>
                    ))}
                  </tbody>
                </table>
              </div>
            ) : (
              <SimpleBarChart rows={result.rows} cols={result.cols} />
            )}
          </HW2Card>
        )}

        {!result && !running && (
          <div style={{
            padding: "32px", textAlign: "center",
            background: "#fff", border: `1px dashed ${HW2_COLOR.rule2}`, borderRadius: 12,
            color: HW2_COLOR.muted, font: "400 13px 'DM Sans'",
          }}>
            Run the query to see results.
            <div style={{ font: "400 11px 'DM Sans'", color: HW2_COLOR.faint, marginTop: 6 }}>
              Click columns on the left to insert them at your cursor.
            </div>
          </div>
        )}
      </section>
    </div>
  );
}

function QueryTableNode({ schema, table, onInsert }) {
  const [open, setOpen] = React.useState(false);
  return (
    <div style={{ marginBottom: 1 }}>
      <div style={{ display: "flex", alignItems: "center", gap: 4 }}>
        <button onClick={() => setOpen(v => !v)} style={{
          appearance: "none", background: "transparent", border: "none", cursor: "pointer",
          width: 14, color: HW2_COLOR.faint, font: "500 10px 'DM Mono'", padding: 0,
        }}>{open ? "▾" : "▸"}</button>
        <button onClick={() => onInsert(`${schema}.${table.name}`)} style={{
          appearance: "none", background: "transparent", border: "none", cursor: "pointer",
          padding: "3px 4px", textAlign: "left",
          font: "500 12px 'DM Mono'", color: HW2_COLOR.ink2,
          flex: 1, minWidth: 0, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap",
        }}>{table.name}</button>
      </div>
      {open && (
        <div style={{ paddingLeft: 22, paddingBottom: 4, display: "grid", gap: 1 }}>
          {(window.HW2.catalogColumns[`${schema}.${table.name}`] || []).map(c => (
            <button key={c.name} onClick={() => onInsert(c.name)} style={{
              appearance: "none", background: "transparent", border: "none", cursor: "pointer",
              padding: "2px 4px", textAlign: "left",
              font: "400 11px 'DM Mono'", color: HW2_COLOR.muted,
            }}>{c.name}</button>
          ))}
          {!window.HW2.catalogColumns[`${schema}.${table.name}`] && (
            <div style={{ padding: "2px 4px", font: "400 11px 'DM Sans'", color: HW2_COLOR.faint }}>
              (no column metadata in demo)
            </div>
          )}
        </div>
      )}
    </div>
  );
}

function SimpleBarChart({ rows, cols }) {
  if (rows.length === 0 || cols.length < 2) {
    return <div style={{ padding: 20, color: HW2_COLOR.faint, font: "400 13px 'DM Sans'", textAlign: "center" }}>
      Pick two columns to see a chart.
    </div>;
  }
  const labelIdx = 0;
  const valIdx = cols.findIndex((c, i) => i > 0 && typeof rows[0][i] === "number");
  if (valIdx === -1) {
    return <div style={{ padding: 20, color: HW2_COLOR.faint, font: "400 13px 'DM Sans'", textAlign: "center" }}>
      No numeric column to chart.
    </div>;
  }
  const max = Math.max(...rows.map(r => r[valIdx]));
  return (
    <div style={{ padding: "16px 18px", display: "grid", gap: 6 }}>
      {rows.slice(0, 12).map((r, i) => (
        <div key={i} style={{ display: "flex", alignItems: "center", gap: 12 }}>
          <span style={{ width: 110, font: "500 12px 'DM Mono'", color: HW2_COLOR.ink2, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
            {r[labelIdx]}
          </span>
          <div style={{ flex: 1, position: "relative", height: 18, background: HW2_COLOR.chip, borderRadius: 4 }}>
            <div style={{ position: "absolute", left: 0, top: 0, height: "100%", width: `${(r[valIdx] / max) * 100}%`, background: HW2_COLOR.blue, borderRadius: 4 }} />
          </div>
          <span style={{ width: 64, textAlign: "right", font: "500 12px 'DM Mono'", color: HW2_COLOR.ink }}>
            {r[valIdx]}
          </span>
        </div>
      ))}
    </div>
  );
}

// ─── Helpers ────────────────────────────────────────────────────────────────
const kbdStyle = {
  display: "inline-block",
  padding: "1px 5px", borderRadius: 4,
  background: "#fff", border: `1px solid ${HW2_COLOR.rule2}`,
  font: "500 10px 'DM Mono'", color: HW2_COLOR.muted,
};

function platformLabel(kind) {
  return { Postgres: "PostgreSQL syntax", CSV: "DuckDB engine", DuckDB: "DuckDB engine" }[kind] || "DuckDB engine";
}

function defaultSQL() {
  return `-- Multi-table query example. Cmd+Enter to run.
SELECT  c.patient_type,
        COUNT(*)                  AS visits,
        AVG(c.total_wait_time)    AS avg_wait_min
FROM    clinical.cases c
JOIN    clinical.events e ON e.case_id = c.case_id
WHERE   e.activity = 'Recepcion'
GROUP   BY 1
ORDER   BY visits DESC
LIMIT   10;`;
}

function mockResultFor(sql, sampleRows) {
  const lower = sql.toLowerCase();
  if (lower.includes("patient_type")) {
    return {
      cols: ["patient_type", "visits", "avg_wait_min"],
      rows: [["A", 1842, 21.4], ["S", 489, 14.2], ["H", 612, 28.1], ["D", 250, 19.6]],
      tookMs: 412,
    };
  }
  if (lower.includes("activity")) {
    return {
      cols: ["activity", "occurrences", "avg_step_min"],
      rows: [["FrontOffice", 3193, 12.1], ["Recepcion", 3193, 7.4], ["BackOffice", 2810, 6.2], ["AsignacionSala", 3140, 3.1]],
      tookMs: 318,
    };
  }
  if (lower.includes("modality")) {
    return {
      cols: ["modality", "exams", "avg_scan_min"],
      rows: [["MRI", 1142, 32.1], ["CT", 1308, 12.4], ["US", 612, 18.9], ["X-ray", 445, 4.1]],
      tookMs: 256,
    };
  }
  // Default — show first table's sample
  const first = Object.values(sampleRows)[0] || [];
  if (first.length === 0) return { cols: [], rows: [], tookMs: 0 };
  return {
    cols: Object.keys(first[0]),
    rows: first.map(r => Object.values(r)),
    tookMs: 142,
  };
}

Object.assign(window, { HW2Query });
